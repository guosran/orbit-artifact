#map = affine_map<(d0, d1) -> (d1)>
"builtin.module"() ({
  "func.func"() <{function_type = (f32, f32) -> f32, sym_name = "__mulsf3", sym_visibility = "private"}> ({
  }) {llvm.readnone, orbit.scalar_f32_builtin = "compiler-rt; same target scalar f32 operation; no vector approximation", passthrough = ["noinline", "nounwind"]} : () -> ()
  "func.func"() <{function_type = (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> (), sym_name = "gemm_scale"}> ({
  ^bb0(%arg0: memref<17x129xf32>, %arg1: memref<129x80xf32>, %arg2: memref<17x80xf32>, %arg3: memref<17x80xf32>):
    %0 = "arith.constant"() <{value = 1 : index}> : () -> index
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg382: index, %arg383: index, %arg384: index, %arg385: index, %arg386: memref<17x129xf32>, %arg387: memref<129x80xf32>, %arg388: memref<17x80xf32>, %arg389: memref<17x80xf32>):
      "air.segment"(%arg386, %arg387, %arg388, %arg389) ({
      ^bb0(%arg390: memref<17x129xf32>, %arg391: memref<129x80xf32>, %arg392: memref<17x80xf32>, %arg393: memref<17x80xf32>):
        %1706 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1707 = "air.herd"(%1706, %1706, %arg390, %arg391, %arg392, %arg393) ({
        ^bb0(%arg394: index, %arg395: index, %arg396: index, %arg397: index, %arg398: memref<17x129xf32>, %arg399: memref<129x80xf32>, %arg400: memref<17x80xf32>, %arg401: memref<17x80xf32>):
          %1708 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.32.1"} : () -> memref<8xf32, 2 : i32>
          %1709 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.32.32"} : () -> memref<256xf32, 2 : i32>
          %1710 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.8.32.1"} : () -> memref<32xf32, 2 : i32>
          %1711 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.8.32.32"} : () -> memref<1024xf32, 2 : i32>
          %1712 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<256xf32, 2 : i32>
          %1713 = "air.wait_all"() : () -> !air.async.token
          %1714 = "memref.reinterpret_cast"(%1712) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 9 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
          %1715 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1716 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1717 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1718 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1716, %1717, %1718) ({
          ^bb0(%arg410: index):
            %1844 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1845 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1846 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1844, %1845, %1846) ({
            ^bb0(%arg411: index):
              "memref.store"(%1715, %1714, %arg410, %arg411) <{nontemporal = false}> : (f32, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1719 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1720 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1721 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1722 = "scf.for"(%1719, %1720, %1721, %1713) ({
          ^bb0(%arg405: index, %arg406: !air.async.token):
            %1780 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1781 = "arith.muli"(%arg405, %1780) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1782 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1783 = "arith.muli"(%arg405, %1782) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1784 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1785 = "arith.muli"(%arg405, %1784) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1786 = "memref.reinterpret_cast"(%1709) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 9 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1787 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1788 = "arith.addi"(%1787, %1783) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1789 = "air.dma_memcpy_nd"(%arg406, %1786, %arg398, %1788) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 9 : i64, orbit.source_copies = array<i64: 0>, orbit.storage = "A", orbit.target_copies = array<i64: 30>, orbit.transfer = "host_to_l1", orbit.transfer_event = 0 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 0, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1790 = "memref.reinterpret_cast"(%1711) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 9 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %1791 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1792 = "arith.addi"(%1791, %1785) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1793 = "air.dma_memcpy_nd"(%arg406, %1790, %arg399, %1792) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 9 : i64, orbit.source_copies = array<i64: 15>, orbit.storage = "B", orbit.target_copies = array<i64: 31>, orbit.transfer = "host_to_l1", orbit.transfer_event = 1 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 0>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1789, %1793) {orbit.computation_event = 3 : i64, orbit.phase = 9 : i64, orbit.phase_dependencies = array<i64: 8>, orbit.read_copies = array<i64: 30, 31, 32>, orbit.task = "gemm", orbit.write_copies = array<i64: 33>} : (!air.async.token, !air.async.token) -> ()
            %1794 = "memref.cast"(%1786) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1795 = "memref.cast"(%1790) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %1796 = "memref.cast"(%1714) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1797 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1798 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1799 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1800 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1798, %1799, %1800) ({
            ^bb0(%arg407: index):
              %1802 = "arith.constant"() <{value = 0 : index}> : () -> index
              %1803 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1804 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1802, %1803, %1804) ({
              ^bb0(%arg408: index):
                %1805 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1806 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1807 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1805, %1806, %1807) ({
                ^bb0(%arg409: index):
                  %1808 = "arith.addi"(%arg409, %1781) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1809 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1810 = "arith.subi"(%1808, %1783) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1811 = "memref.load"(%1794, %arg407, %1810) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1812 = "vector.broadcast"(%1811) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1813 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1814 = "arith.subi"(%1808, %1785) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1815 = "vector.transfer_read"(%1795, %1814, %arg408, %1813) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1816 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1817 = "vector.transfer_read"(%1796, %arg407, %arg408, %1816) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1818 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1819 = "vector.extract"(%1815) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1820 = "func.call"(%1811, %1819) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1821 = "vector.insert"(%1820, %1818) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1822 = "vector.extract"(%1815) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1823 = "func.call"(%1811, %1822) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1824 = "vector.insert"(%1823, %1821) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1825 = "vector.extract"(%1815) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1826 = "func.call"(%1811, %1825) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1827 = "vector.insert"(%1826, %1824) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1828 = "vector.extract"(%1815) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1829 = "func.call"(%1811, %1828) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1830 = "vector.insert"(%1829, %1827) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1831 = "vector.extract"(%1815) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1832 = "func.call"(%1811, %1831) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1833 = "vector.insert"(%1832, %1830) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1834 = "vector.extract"(%1815) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1835 = "func.call"(%1811, %1834) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1836 = "vector.insert"(%1835, %1833) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1837 = "vector.extract"(%1815) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1838 = "func.call"(%1811, %1837) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1839 = "vector.insert"(%1838, %1836) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1840 = "vector.extract"(%1815) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1841 = "func.call"(%1811, %1840) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1842 = "vector.insert"(%1841, %1839) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1843 = "arith.addf"(%1817, %1842) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  "vector.transfer_write"(%1843, %1796, %arg407, %arg408) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1801 = "air.wait_all"(%arg406) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1801) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1723 = "memref.reinterpret_cast"(%1708) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 13 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1724 = "air.dma_memcpy_nd"(%1722, %1723, %arg398) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 13 : i64, orbit.source_copies = array<i64: 4>, orbit.storage = "A", orbit.target_copies = array<i64: 43>, orbit.transfer = "host_to_l1", orbit.transfer_event = 13 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 0, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1725 = "memref.reinterpret_cast"(%1710) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 13 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %1726 = "air.dma_memcpy_nd"(%1722, %1725, %arg399) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 13 : i64, orbit.source_copies = array<i64: 27>, orbit.storage = "B", orbit.target_copies = array<i64: 44>, orbit.transfer = "host_to_l1", orbit.transfer_event = 14 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1724, %1726) {orbit.computation_event = 15 : i64, orbit.phase = 13 : i64, orbit.phase_dependencies = array<i64: 12>, orbit.read_copies = array<i64: 43, 44, 42>, orbit.task = "gemm", orbit.write_copies = array<i64: 45>} : (!air.async.token, !air.async.token) -> ()
          %1727 = "memref.cast"(%1723) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1728 = "memref.cast"(%1725) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %1729 = "memref.cast"(%1714) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
          %1730 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1731 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1732 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1733 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1731, %1732, %1733) ({
          ^bb0(%arg402: index):
            %1737 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1738 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1739 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1737, %1738, %1739) ({
            ^bb0(%arg403: index):
              %1740 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1741 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1742 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1740, %1741, %1742) ({
              ^bb0(%arg404: index):
                %1743 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1744 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1745 = "arith.subi"(%arg404, %1744) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1746 = "memref.load"(%1727, %arg402, %1745) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1747 = "vector.broadcast"(%1746) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1748 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1749 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1750 = "arith.subi"(%arg404, %1749) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1751 = "vector.transfer_read"(%1728, %1750, %arg403, %1748) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1752 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1753 = "vector.transfer_read"(%1729, %arg402, %arg403, %1752) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1754 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1755 = "vector.extract"(%1751) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1756 = "func.call"(%1746, %1755) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1757 = "vector.insert"(%1756, %1754) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1758 = "vector.extract"(%1751) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1759 = "func.call"(%1746, %1758) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1760 = "vector.insert"(%1759, %1757) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1761 = "vector.extract"(%1751) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1762 = "func.call"(%1746, %1761) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1763 = "vector.insert"(%1762, %1760) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1764 = "vector.extract"(%1751) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1765 = "func.call"(%1746, %1764) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1766 = "vector.insert"(%1765, %1763) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1767 = "vector.extract"(%1751) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1768 = "func.call"(%1746, %1767) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1769 = "vector.insert"(%1768, %1766) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1770 = "vector.extract"(%1751) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1771 = "func.call"(%1746, %1770) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1772 = "vector.insert"(%1771, %1769) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1773 = "vector.extract"(%1751) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1774 = "func.call"(%1746, %1773) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1775 = "vector.insert"(%1774, %1772) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1776 = "vector.extract"(%1751) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1777 = "func.call"(%1746, %1776) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1778 = "vector.insert"(%1777, %1775) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1779 = "arith.addf"(%1753, %1778) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                "vector.transfer_write"(%1779, %1729, %arg402, %arg403) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1734 = "air.wait_all"(%1722) : (!air.async.token) -> !air.async.token
          %1735 = "air.dma_memcpy_nd"(%1734, %arg401, %1714) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 13 : i64, orbit.retained_begin = 9 : i64, orbit.retained_end = 14 : i64, orbit.source_copies = array<i64: 45>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 46>, orbit.transfer = "l1_to_host", orbit.transfer_event = 16 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %1736 = "air.wait_all"(%1735) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1736) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1707) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg352: index, %arg353: index, %arg354: index, %arg355: index, %arg356: memref<17x129xf32>, %arg357: memref<129x80xf32>, %arg358: memref<17x80xf32>, %arg359: memref<17x80xf32>):
      "air.segment"(%arg356, %arg357, %arg358, %arg359) ({
      ^bb0(%arg360: memref<17x129xf32>, %arg361: memref<129x80xf32>, %arg362: memref<17x80xf32>, %arg363: memref<17x80xf32>):
        %1551 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1552 = "air.herd"(%1551, %1551, %arg360, %arg361, %arg362, %arg363) ({
        ^bb0(%arg364: index, %arg365: index, %arg366: index, %arg367: index, %arg368: memref<17x129xf32>, %arg369: memref<129x80xf32>, %arg370: memref<17x80xf32>, %arg371: memref<17x80xf32>):
          %1553 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.32.1"} : () -> memref<8xf32, 2 : i32>
          %1554 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.32.32"} : () -> memref<256xf32, 2 : i32>
          %1555 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.8.32.1"} : () -> memref<32xf32, 2 : i32>
          %1556 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.8.32.32"} : () -> memref<1024xf32, 2 : i32>
          %1557 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<256xf32, 2 : i32>
          %1558 = "air.wait_all"() : () -> !air.async.token
          %1559 = "memref.reinterpret_cast"(%1557) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 14 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
          %1560 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1561 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1562 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1563 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1561, %1562, %1563) ({
          ^bb0(%arg380: index):
            %1701 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1702 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1703 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1701, %1702, %1703) ({
            ^bb0(%arg381: index):
              %1704 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1705 = "arith.subi"(%arg381, %1704) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%1560, %1559, %arg380, %1705) <{nontemporal = false}> : (f32, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1564 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1565 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1566 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1567 = "scf.for"(%1564, %1565, %1566, %1558) ({
          ^bb0(%arg375: index, %arg376: !air.async.token):
            %1631 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1632 = "arith.muli"(%arg375, %1631) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1633 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1634 = "arith.muli"(%arg375, %1633) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1635 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1636 = "arith.muli"(%arg375, %1635) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1637 = "memref.reinterpret_cast"(%1554) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 14 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1638 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1639 = "arith.addi"(%1638, %1634) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1640 = "air.dma_memcpy_nd"(%arg376, %1637, %arg368, %1639) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 14 : i64, orbit.source_copies = array<i64: 0>, orbit.storage = "A", orbit.target_copies = array<i64: 47>, orbit.transfer = "host_to_l1", orbit.transfer_event = 17 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 0, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1641 = "memref.reinterpret_cast"(%1556) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 14 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %1642 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1643 = "arith.addi"(%1642, %1636) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1644 = "air.dma_memcpy_nd"(%arg376, %1641, %arg369, %1643) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 14 : i64, orbit.source_copies = array<i64: 16>, orbit.storage = "B", orbit.target_copies = array<i64: 48>, orbit.transfer = "host_to_l1", orbit.transfer_event = 18 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 32>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1640, %1644) {orbit.computation_event = 20 : i64, orbit.phase = 14 : i64, orbit.phase_dependencies = array<i64: 13>, orbit.read_copies = array<i64: 47, 48, 49>, orbit.task = "gemm", orbit.write_copies = array<i64: 50>} : (!air.async.token, !air.async.token) -> ()
            %1645 = "memref.cast"(%1637) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1646 = "memref.cast"(%1641) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %1647 = "memref.cast"(%1559) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1648 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1649 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1650 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1651 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1649, %1650, %1651) ({
            ^bb0(%arg377: index):
              %1653 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1654 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1655 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1653, %1654, %1655) ({
              ^bb0(%arg378: index):
                %1656 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1657 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1658 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1656, %1657, %1658) ({
                ^bb0(%arg379: index):
                  %1659 = "arith.addi"(%arg379, %1632) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1660 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1661 = "arith.subi"(%1659, %1634) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1662 = "memref.load"(%1645, %arg377, %1661) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1663 = "vector.broadcast"(%1662) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1664 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1665 = "arith.subi"(%1659, %1636) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1666 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1667 = "arith.subi"(%arg378, %1666) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1668 = "vector.transfer_read"(%1646, %1665, %1667, %1664) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1669 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1670 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1671 = "arith.subi"(%arg378, %1670) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1672 = "vector.transfer_read"(%1647, %arg377, %1671, %1669) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1673 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1674 = "vector.extract"(%1668) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1675 = "func.call"(%1662, %1674) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1676 = "vector.insert"(%1675, %1673) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1677 = "vector.extract"(%1668) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1678 = "func.call"(%1662, %1677) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1679 = "vector.insert"(%1678, %1676) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1680 = "vector.extract"(%1668) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1681 = "func.call"(%1662, %1680) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1682 = "vector.insert"(%1681, %1679) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1683 = "vector.extract"(%1668) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1684 = "func.call"(%1662, %1683) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1685 = "vector.insert"(%1684, %1682) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1686 = "vector.extract"(%1668) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1687 = "func.call"(%1662, %1686) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1688 = "vector.insert"(%1687, %1685) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1689 = "vector.extract"(%1668) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1690 = "func.call"(%1662, %1689) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1691 = "vector.insert"(%1690, %1688) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1692 = "vector.extract"(%1668) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1693 = "func.call"(%1662, %1692) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1694 = "vector.insert"(%1693, %1691) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1695 = "vector.extract"(%1668) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1696 = "func.call"(%1662, %1695) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1697 = "vector.insert"(%1696, %1694) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1698 = "arith.addf"(%1672, %1697) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1699 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1700 = "arith.subi"(%arg378, %1699) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1698, %1647, %arg377, %1700) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1652 = "air.wait_all"(%arg376) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1652) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1568 = "memref.reinterpret_cast"(%1553) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 18 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1569 = "air.dma_memcpy_nd"(%1567, %1568, %arg368) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 18 : i64, orbit.source_copies = array<i64: 4>, orbit.storage = "A", orbit.target_copies = array<i64: 60>, orbit.transfer = "host_to_l1", orbit.transfer_event = 30 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 0, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1570 = "memref.reinterpret_cast"(%1555) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 18 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %1571 = "air.dma_memcpy_nd"(%1567, %1570, %arg369) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 18 : i64, orbit.source_copies = array<i64: 28>, orbit.storage = "B", orbit.target_copies = array<i64: 61>, orbit.transfer = "host_to_l1", orbit.transfer_event = 31 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 32>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1569, %1571) {orbit.computation_event = 32 : i64, orbit.phase = 18 : i64, orbit.phase_dependencies = array<i64: 17>, orbit.read_copies = array<i64: 60, 61, 59>, orbit.task = "gemm", orbit.write_copies = array<i64: 62>} : (!air.async.token, !air.async.token) -> ()
          %1572 = "memref.cast"(%1568) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1573 = "memref.cast"(%1570) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %1574 = "memref.cast"(%1559) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
          %1575 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1576 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1577 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1578 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1576, %1577, %1578) ({
          ^bb0(%arg372: index):
            %1582 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1583 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1584 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1582, %1583, %1584) ({
            ^bb0(%arg373: index):
              %1585 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1586 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1587 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1585, %1586, %1587) ({
              ^bb0(%arg374: index):
                %1588 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1589 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1590 = "arith.subi"(%arg374, %1589) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1591 = "memref.load"(%1572, %arg372, %1590) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1592 = "vector.broadcast"(%1591) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1593 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1594 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1595 = "arith.subi"(%arg374, %1594) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1596 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1597 = "arith.subi"(%arg373, %1596) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1598 = "vector.transfer_read"(%1573, %1595, %1597, %1593) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1599 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1600 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1601 = "arith.subi"(%arg373, %1600) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1602 = "vector.transfer_read"(%1574, %arg372, %1601, %1599) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1603 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1604 = "vector.extract"(%1598) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1605 = "func.call"(%1591, %1604) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1606 = "vector.insert"(%1605, %1603) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1607 = "vector.extract"(%1598) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1608 = "func.call"(%1591, %1607) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1609 = "vector.insert"(%1608, %1606) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1610 = "vector.extract"(%1598) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1611 = "func.call"(%1591, %1610) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1612 = "vector.insert"(%1611, %1609) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1613 = "vector.extract"(%1598) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1614 = "func.call"(%1591, %1613) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1615 = "vector.insert"(%1614, %1612) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1616 = "vector.extract"(%1598) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1617 = "func.call"(%1591, %1616) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1618 = "vector.insert"(%1617, %1615) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1619 = "vector.extract"(%1598) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1620 = "func.call"(%1591, %1619) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1621 = "vector.insert"(%1620, %1618) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1622 = "vector.extract"(%1598) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1623 = "func.call"(%1591, %1622) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1624 = "vector.insert"(%1623, %1621) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1625 = "vector.extract"(%1598) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1626 = "func.call"(%1591, %1625) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1627 = "vector.insert"(%1626, %1624) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1628 = "arith.addf"(%1602, %1627) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %1629 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1630 = "arith.subi"(%arg373, %1629) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%1628, %1574, %arg372, %1630) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1579 = "air.wait_all"(%1567) : (!air.async.token) -> !air.async.token
          %1580 = "air.dma_memcpy_nd"(%1579, %arg371, %1559) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 18 : i64, orbit.retained_begin = 14 : i64, orbit.retained_end = 19 : i64, orbit.source_copies = array<i64: 62>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 63>, orbit.transfer = "l1_to_host", orbit.transfer_event = 33 : i64, static_dst_offsets = array<i64: 0, 32>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %1581 = "air.wait_all"(%1580) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1581) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_14"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1552) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_14"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_14"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg322: index, %arg323: index, %arg324: index, %arg325: index, %arg326: memref<17x129xf32>, %arg327: memref<129x80xf32>, %arg328: memref<17x80xf32>, %arg329: memref<17x80xf32>):
      "air.segment"(%arg326, %arg327, %arg328, %arg329) ({
      ^bb0(%arg330: memref<17x129xf32>, %arg331: memref<129x80xf32>, %arg332: memref<17x80xf32>, %arg333: memref<17x80xf32>):
        %1396 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1397 = "air.herd"(%1396, %1396, %arg330, %arg331, %arg332, %arg333) ({
        ^bb0(%arg334: index, %arg335: index, %arg336: index, %arg337: index, %arg338: memref<17x129xf32>, %arg339: memref<129x80xf32>, %arg340: memref<17x80xf32>, %arg341: memref<17x80xf32>):
          %1398 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.16.1"} : () -> memref<8xf32, 2 : i32>
          %1399 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.16.32"} : () -> memref<256xf32, 2 : i32>
          %1400 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.16.loops.8.16.1"} : () -> memref<16xf32, 2 : i32>
          %1401 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.16.loops.8.16.32"} : () -> memref<512xf32, 2 : i32>
          %1402 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<128xf32, 2 : i32>
          %1403 = "air.wait_all"() : () -> !air.async.token
          %1404 = "memref.reinterpret_cast"(%1402) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 19 : i64, orbit.storage = "intermediate"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %1405 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1406 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1407 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1408 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1406, %1407, %1408) ({
          ^bb0(%arg350: index):
            %1546 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1547 = "arith.constant"() <{value = 80 : index}> : () -> index
            %1548 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1546, %1547, %1548) ({
            ^bb0(%arg351: index):
              %1549 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1550 = "arith.subi"(%arg351, %1549) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%1405, %1404, %arg350, %1550) <{nontemporal = false}> : (f32, memref<8x16xf32, strided<[16, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1409 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1410 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1411 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1412 = "scf.for"(%1409, %1410, %1411, %1403) ({
          ^bb0(%arg345: index, %arg346: !air.async.token):
            %1476 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1477 = "arith.muli"(%arg345, %1476) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1478 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1479 = "arith.muli"(%arg345, %1478) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1480 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1481 = "arith.muli"(%arg345, %1480) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1482 = "memref.reinterpret_cast"(%1399) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 19 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1483 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1484 = "arith.addi"(%1483, %1479) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1485 = "air.dma_memcpy_nd"(%arg346, %1482, %arg338, %1484) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 19 : i64, orbit.source_copies = array<i64: 0>, orbit.storage = "A", orbit.target_copies = array<i64: 64>, orbit.transfer = "host_to_l1", orbit.transfer_event = 34 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 0, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1486 = "memref.reinterpret_cast"(%1401) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 19 : i64, orbit.storage = "B"} : (memref<512xf32, 2 : i32>) -> memref<32x16xf32, strided<[16, 1]>, 2 : i32>
            %1487 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1488 = "arith.addi"(%1487, %1481) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1489 = "air.dma_memcpy_nd"(%arg346, %1486, %arg339, %1488) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 19 : i64, orbit.source_copies = array<i64: 17>, orbit.storage = "B", orbit.target_copies = array<i64: 65>, orbit.transfer = "host_to_l1", orbit.transfer_event = 35 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: -9223372036854775808, 64>, static_src_sizes = array<i64: 32, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1485, %1489) {orbit.computation_event = 37 : i64, orbit.phase = 19 : i64, orbit.phase_dependencies = array<i64: 18>, orbit.read_copies = array<i64: 64, 65, 66>, orbit.task = "gemm", orbit.write_copies = array<i64: 67>} : (!air.async.token, !air.async.token) -> ()
            %1490 = "memref.cast"(%1482) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1491 = "memref.cast"(%1486) : (memref<32x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<32x16xf32, 2 : i32>
            %1492 = "memref.cast"(%1404) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
            %1493 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1494 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1495 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1496 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1494, %1495, %1496) ({
            ^bb0(%arg347: index):
              %1498 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1499 = "arith.constant"() <{value = 80 : index}> : () -> index
              %1500 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1498, %1499, %1500) ({
              ^bb0(%arg348: index):
                %1501 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1502 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1503 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1501, %1502, %1503) ({
                ^bb0(%arg349: index):
                  %1504 = "arith.addi"(%arg349, %1477) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1505 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1506 = "arith.subi"(%1504, %1479) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1507 = "memref.load"(%1490, %arg347, %1506) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1508 = "vector.broadcast"(%1507) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1509 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1510 = "arith.subi"(%1504, %1481) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1511 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1512 = "arith.subi"(%arg348, %1511) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1513 = "vector.transfer_read"(%1491, %1510, %1512, %1509) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1514 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1515 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1516 = "arith.subi"(%arg348, %1515) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1517 = "vector.transfer_read"(%1492, %arg347, %1516, %1514) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1518 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1519 = "vector.extract"(%1513) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1520 = "func.call"(%1507, %1519) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1521 = "vector.insert"(%1520, %1518) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1522 = "vector.extract"(%1513) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1523 = "func.call"(%1507, %1522) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1524 = "vector.insert"(%1523, %1521) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1525 = "vector.extract"(%1513) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1526 = "func.call"(%1507, %1525) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1527 = "vector.insert"(%1526, %1524) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1528 = "vector.extract"(%1513) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1529 = "func.call"(%1507, %1528) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1530 = "vector.insert"(%1529, %1527) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1531 = "vector.extract"(%1513) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1532 = "func.call"(%1507, %1531) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1533 = "vector.insert"(%1532, %1530) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1534 = "vector.extract"(%1513) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1535 = "func.call"(%1507, %1534) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1536 = "vector.insert"(%1535, %1533) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1537 = "vector.extract"(%1513) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1538 = "func.call"(%1507, %1537) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1539 = "vector.insert"(%1538, %1536) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1540 = "vector.extract"(%1513) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1541 = "func.call"(%1507, %1540) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1542 = "vector.insert"(%1541, %1539) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1543 = "arith.addf"(%1517, %1542) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1544 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1545 = "arith.subi"(%arg348, %1544) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1543, %1492, %arg347, %1545) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1497 = "air.wait_all"(%arg346) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1497) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1413 = "memref.reinterpret_cast"(%1398) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 23 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1414 = "air.dma_memcpy_nd"(%1412, %1413, %arg338) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 23 : i64, orbit.source_copies = array<i64: 4>, orbit.storage = "A", orbit.target_copies = array<i64: 77>, orbit.transfer = "host_to_l1", orbit.transfer_event = 47 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 0, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1415 = "memref.reinterpret_cast"(%1400) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 23 : i64, orbit.storage = "B"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %1416 = "air.dma_memcpy_nd"(%1412, %1415, %arg339) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 23 : i64, orbit.source_copies = array<i64: 29>, orbit.storage = "B", orbit.target_copies = array<i64: 78>, orbit.transfer = "host_to_l1", orbit.transfer_event = 48 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 128, 64>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1414, %1416) {orbit.computation_event = 49 : i64, orbit.phase = 23 : i64, orbit.phase_dependencies = array<i64: 22>, orbit.read_copies = array<i64: 77, 78, 76>, orbit.task = "gemm", orbit.write_copies = array<i64: 79>} : (!air.async.token, !air.async.token) -> ()
          %1417 = "memref.cast"(%1413) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1418 = "memref.cast"(%1415) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %1419 = "memref.cast"(%1404) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %1420 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1421 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1422 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1423 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1421, %1422, %1423) ({
          ^bb0(%arg342: index):
            %1427 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1428 = "arith.constant"() <{value = 80 : index}> : () -> index
            %1429 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1427, %1428, %1429) ({
            ^bb0(%arg343: index):
              %1430 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1431 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1432 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1430, %1431, %1432) ({
              ^bb0(%arg344: index):
                %1433 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1434 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1435 = "arith.subi"(%arg344, %1434) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1436 = "memref.load"(%1417, %arg342, %1435) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1437 = "vector.broadcast"(%1436) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1438 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1439 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1440 = "arith.subi"(%arg344, %1439) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1441 = "arith.constant"() <{value = 64 : index}> : () -> index
                %1442 = "arith.subi"(%arg343, %1441) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1443 = "vector.transfer_read"(%1418, %1440, %1442, %1438) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1444 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1445 = "arith.constant"() <{value = 64 : index}> : () -> index
                %1446 = "arith.subi"(%arg343, %1445) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1447 = "vector.transfer_read"(%1419, %arg342, %1446, %1444) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1448 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1449 = "vector.extract"(%1443) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1450 = "func.call"(%1436, %1449) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1451 = "vector.insert"(%1450, %1448) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1452 = "vector.extract"(%1443) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1453 = "func.call"(%1436, %1452) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1454 = "vector.insert"(%1453, %1451) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1455 = "vector.extract"(%1443) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1456 = "func.call"(%1436, %1455) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1457 = "vector.insert"(%1456, %1454) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1458 = "vector.extract"(%1443) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1459 = "func.call"(%1436, %1458) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1460 = "vector.insert"(%1459, %1457) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1461 = "vector.extract"(%1443) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1462 = "func.call"(%1436, %1461) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1463 = "vector.insert"(%1462, %1460) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1464 = "vector.extract"(%1443) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1465 = "func.call"(%1436, %1464) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1466 = "vector.insert"(%1465, %1463) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1467 = "vector.extract"(%1443) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1468 = "func.call"(%1436, %1467) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1469 = "vector.insert"(%1468, %1466) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1470 = "vector.extract"(%1443) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1471 = "func.call"(%1436, %1470) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1472 = "vector.insert"(%1471, %1469) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1473 = "arith.addf"(%1447, %1472) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %1474 = "arith.constant"() <{value = 64 : index}> : () -> index
                %1475 = "arith.subi"(%arg343, %1474) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%1473, %1419, %arg342, %1475) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1424 = "air.wait_all"(%1412) : (!air.async.token) -> !air.async.token
          %1425 = "air.dma_memcpy_nd"(%1424, %arg341, %1404) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 23 : i64, orbit.retained_begin = 19 : i64, orbit.retained_end = 24 : i64, orbit.source_copies = array<i64: 79>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 80>, orbit.transfer = "l1_to_host", orbit.transfer_event = 50 : i64, static_dst_offsets = array<i64: 0, 64>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %1426 = "air.wait_all"(%1425) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1426) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_19"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1397) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_19"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_19"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg292: index, %arg293: index, %arg294: index, %arg295: index, %arg296: memref<17x129xf32>, %arg297: memref<129x80xf32>, %arg298: memref<17x80xf32>, %arg299: memref<17x80xf32>):
      "air.segment"(%arg296, %arg297, %arg298, %arg299) ({
      ^bb0(%arg300: memref<17x129xf32>, %arg301: memref<129x80xf32>, %arg302: memref<17x80xf32>, %arg303: memref<17x80xf32>):
        %1241 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1242 = "air.herd"(%1241, %1241, %arg300, %arg301, %arg302, %arg303) ({
        ^bb0(%arg304: index, %arg305: index, %arg306: index, %arg307: index, %arg308: memref<17x129xf32>, %arg309: memref<129x80xf32>, %arg310: memref<17x80xf32>, %arg311: memref<17x80xf32>):
          %1243 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.32.1"} : () -> memref<8xf32, 2 : i32>
          %1244 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.32.32"} : () -> memref<256xf32, 2 : i32>
          %1245 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.8.32.1"} : () -> memref<32xf32, 2 : i32>
          %1246 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.8.32.32"} : () -> memref<1024xf32, 2 : i32>
          %1247 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<256xf32, 2 : i32>
          %1248 = "air.wait_all"() : () -> !air.async.token
          %1249 = "memref.reinterpret_cast"(%1247) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 24 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
          %1250 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1251 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1252 = "arith.constant"() <{value = 16 : index}> : () -> index
          %1253 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1251, %1252, %1253) ({
          ^bb0(%arg320: index):
            %1391 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1392 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1393 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1391, %1392, %1393) ({
            ^bb0(%arg321: index):
              %1394 = "arith.constant"() <{value = 8 : index}> : () -> index
              %1395 = "arith.subi"(%arg320, %1394) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%1250, %1249, %1395, %arg321) <{nontemporal = false}> : (f32, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1254 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1255 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1256 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1257 = "scf.for"(%1254, %1255, %1256, %1248) ({
          ^bb0(%arg315: index, %arg316: !air.async.token):
            %1321 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1322 = "arith.muli"(%arg315, %1321) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1323 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1324 = "arith.muli"(%arg315, %1323) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1325 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1326 = "arith.muli"(%arg315, %1325) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1327 = "memref.reinterpret_cast"(%1244) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 24 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1328 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1329 = "arith.addi"(%1328, %1324) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1330 = "air.dma_memcpy_nd"(%arg316, %1327, %arg308, %1329) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 24 : i64, orbit.source_copies = array<i64: 5>, orbit.storage = "A", orbit.target_copies = array<i64: 81>, orbit.transfer = "host_to_l1", orbit.transfer_event = 51 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 8, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1331 = "memref.reinterpret_cast"(%1246) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 24 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %1332 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1333 = "arith.addi"(%1332, %1326) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1334 = "air.dma_memcpy_nd"(%arg316, %1331, %arg309, %1333) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 24 : i64, orbit.source_copies = array<i64: 15>, orbit.storage = "B", orbit.target_copies = array<i64: 82>, orbit.transfer = "host_to_l1", orbit.transfer_event = 52 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 0>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1330, %1334) {orbit.computation_event = 54 : i64, orbit.phase = 24 : i64, orbit.phase_dependencies = array<i64: 23>, orbit.read_copies = array<i64: 81, 82, 83>, orbit.task = "gemm", orbit.write_copies = array<i64: 84>} : (!air.async.token, !air.async.token) -> ()
            %1335 = "memref.cast"(%1327) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1336 = "memref.cast"(%1331) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %1337 = "memref.cast"(%1249) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1338 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1339 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1340 = "arith.constant"() <{value = 16 : index}> : () -> index
            %1341 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1339, %1340, %1341) ({
            ^bb0(%arg317: index):
              %1343 = "arith.constant"() <{value = 0 : index}> : () -> index
              %1344 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1345 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1343, %1344, %1345) ({
              ^bb0(%arg318: index):
                %1346 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1347 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1348 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1346, %1347, %1348) ({
                ^bb0(%arg319: index):
                  %1349 = "arith.addi"(%arg319, %1322) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1350 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1351 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1352 = "arith.subi"(%arg317, %1351) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1353 = "arith.subi"(%1349, %1324) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1354 = "memref.load"(%1335, %1352, %1353) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1355 = "vector.broadcast"(%1354) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1356 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1357 = "arith.subi"(%1349, %1326) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1358 = "vector.transfer_read"(%1336, %1357, %arg318, %1356) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1359 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1360 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1361 = "arith.subi"(%arg317, %1360) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1362 = "vector.transfer_read"(%1337, %1361, %arg318, %1359) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1363 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1364 = "vector.extract"(%1358) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1365 = "func.call"(%1354, %1364) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1366 = "vector.insert"(%1365, %1363) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1367 = "vector.extract"(%1358) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1368 = "func.call"(%1354, %1367) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1369 = "vector.insert"(%1368, %1366) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1370 = "vector.extract"(%1358) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1371 = "func.call"(%1354, %1370) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1372 = "vector.insert"(%1371, %1369) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1373 = "vector.extract"(%1358) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1374 = "func.call"(%1354, %1373) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1375 = "vector.insert"(%1374, %1372) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1376 = "vector.extract"(%1358) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1377 = "func.call"(%1354, %1376) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1378 = "vector.insert"(%1377, %1375) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1379 = "vector.extract"(%1358) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1380 = "func.call"(%1354, %1379) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1381 = "vector.insert"(%1380, %1378) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1382 = "vector.extract"(%1358) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1383 = "func.call"(%1354, %1382) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1384 = "vector.insert"(%1383, %1381) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1385 = "vector.extract"(%1358) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1386 = "func.call"(%1354, %1385) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1387 = "vector.insert"(%1386, %1384) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1388 = "arith.addf"(%1362, %1387) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1389 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1390 = "arith.subi"(%arg317, %1389) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1388, %1337, %1390, %arg318) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1342 = "air.wait_all"(%arg316) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1342) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1258 = "memref.reinterpret_cast"(%1243) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 28 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1259 = "air.dma_memcpy_nd"(%1257, %1258, %arg308) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 28 : i64, orbit.source_copies = array<i64: 9>, orbit.storage = "A", orbit.target_copies = array<i64: 94>, orbit.transfer = "host_to_l1", orbit.transfer_event = 64 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 8, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1260 = "memref.reinterpret_cast"(%1245) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 28 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %1261 = "air.dma_memcpy_nd"(%1257, %1260, %arg309) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 28 : i64, orbit.source_copies = array<i64: 27>, orbit.storage = "B", orbit.target_copies = array<i64: 95>, orbit.transfer = "host_to_l1", orbit.transfer_event = 65 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1259, %1261) {orbit.computation_event = 66 : i64, orbit.phase = 28 : i64, orbit.phase_dependencies = array<i64: 27>, orbit.read_copies = array<i64: 94, 95, 93>, orbit.task = "gemm", orbit.write_copies = array<i64: 96>} : (!air.async.token, !air.async.token) -> ()
          %1262 = "memref.cast"(%1258) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1263 = "memref.cast"(%1260) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %1264 = "memref.cast"(%1249) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
          %1265 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1266 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1267 = "arith.constant"() <{value = 16 : index}> : () -> index
          %1268 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1266, %1267, %1268) ({
          ^bb0(%arg312: index):
            %1272 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1273 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1274 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1272, %1273, %1274) ({
            ^bb0(%arg313: index):
              %1275 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1276 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1277 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1275, %1276, %1277) ({
              ^bb0(%arg314: index):
                %1278 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1279 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1280 = "arith.subi"(%arg312, %1279) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1281 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1282 = "arith.subi"(%arg314, %1281) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1283 = "memref.load"(%1262, %1280, %1282) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1284 = "vector.broadcast"(%1283) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1285 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1286 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1287 = "arith.subi"(%arg314, %1286) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1288 = "vector.transfer_read"(%1263, %1287, %arg313, %1285) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1289 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1290 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1291 = "arith.subi"(%arg312, %1290) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1292 = "vector.transfer_read"(%1264, %1291, %arg313, %1289) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1293 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1294 = "vector.extract"(%1288) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1295 = "func.call"(%1283, %1294) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1296 = "vector.insert"(%1295, %1293) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1297 = "vector.extract"(%1288) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1298 = "func.call"(%1283, %1297) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1299 = "vector.insert"(%1298, %1296) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1300 = "vector.extract"(%1288) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1301 = "func.call"(%1283, %1300) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1302 = "vector.insert"(%1301, %1299) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1303 = "vector.extract"(%1288) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1304 = "func.call"(%1283, %1303) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1305 = "vector.insert"(%1304, %1302) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1306 = "vector.extract"(%1288) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1307 = "func.call"(%1283, %1306) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1308 = "vector.insert"(%1307, %1305) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1309 = "vector.extract"(%1288) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1310 = "func.call"(%1283, %1309) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1311 = "vector.insert"(%1310, %1308) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1312 = "vector.extract"(%1288) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1313 = "func.call"(%1283, %1312) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1314 = "vector.insert"(%1313, %1311) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1315 = "vector.extract"(%1288) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1316 = "func.call"(%1283, %1315) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1317 = "vector.insert"(%1316, %1314) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1318 = "arith.addf"(%1292, %1317) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %1319 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1320 = "arith.subi"(%arg312, %1319) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%1318, %1264, %1320, %arg313) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1269 = "air.wait_all"(%1257) : (!air.async.token) -> !air.async.token
          %1270 = "air.dma_memcpy_nd"(%1269, %arg311, %1249) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 28 : i64, orbit.retained_begin = 24 : i64, orbit.retained_end = 29 : i64, orbit.source_copies = array<i64: 96>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 97>, orbit.transfer = "l1_to_host", orbit.transfer_event = 67 : i64, static_dst_offsets = array<i64: 8, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %1271 = "air.wait_all"(%1270) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1271) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_24"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1242) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_24"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_24"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg262: index, %arg263: index, %arg264: index, %arg265: index, %arg266: memref<17x129xf32>, %arg267: memref<129x80xf32>, %arg268: memref<17x80xf32>, %arg269: memref<17x80xf32>):
      "air.segment"(%arg266, %arg267, %arg268, %arg269) ({
      ^bb0(%arg270: memref<17x129xf32>, %arg271: memref<129x80xf32>, %arg272: memref<17x80xf32>, %arg273: memref<17x80xf32>):
        %1072 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1073 = "air.herd"(%1072, %1072, %arg270, %arg271, %arg272, %arg273) ({
        ^bb0(%arg274: index, %arg275: index, %arg276: index, %arg277: index, %arg278: memref<17x129xf32>, %arg279: memref<129x80xf32>, %arg280: memref<17x80xf32>, %arg281: memref<17x80xf32>):
          %1074 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.32.1"} : () -> memref<8xf32, 2 : i32>
          %1075 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.32.32"} : () -> memref<256xf32, 2 : i32>
          %1076 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.8.32.1"} : () -> memref<32xf32, 2 : i32>
          %1077 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.8.32.32"} : () -> memref<1024xf32, 2 : i32>
          %1078 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<256xf32, 2 : i32>
          %1079 = "air.wait_all"() : () -> !air.async.token
          %1080 = "memref.reinterpret_cast"(%1078) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 29 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
          %1081 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1082 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1083 = "arith.constant"() <{value = 16 : index}> : () -> index
          %1084 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1082, %1083, %1084) ({
          ^bb0(%arg290: index):
            %1234 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1235 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1236 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1234, %1235, %1236) ({
            ^bb0(%arg291: index):
              %1237 = "arith.constant"() <{value = 8 : index}> : () -> index
              %1238 = "arith.subi"(%arg290, %1237) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %1239 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1240 = "arith.subi"(%arg291, %1239) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%1081, %1080, %1238, %1240) <{nontemporal = false}> : (f32, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1085 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1086 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1087 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1088 = "scf.for"(%1085, %1086, %1087, %1079) ({
          ^bb0(%arg285: index, %arg286: !air.async.token):
            %1158 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1159 = "arith.muli"(%arg285, %1158) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1160 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1161 = "arith.muli"(%arg285, %1160) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1162 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1163 = "arith.muli"(%arg285, %1162) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1164 = "memref.reinterpret_cast"(%1075) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 29 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1165 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1166 = "arith.addi"(%1165, %1161) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1167 = "air.dma_memcpy_nd"(%arg286, %1164, %arg278, %1166) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 29 : i64, orbit.source_copies = array<i64: 5>, orbit.storage = "A", orbit.target_copies = array<i64: 98>, orbit.transfer = "host_to_l1", orbit.transfer_event = 68 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 8, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1168 = "memref.reinterpret_cast"(%1077) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 29 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %1169 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1170 = "arith.addi"(%1169, %1163) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1171 = "air.dma_memcpy_nd"(%arg286, %1168, %arg279, %1170) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 29 : i64, orbit.source_copies = array<i64: 16>, orbit.storage = "B", orbit.target_copies = array<i64: 99>, orbit.transfer = "host_to_l1", orbit.transfer_event = 69 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 32>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1167, %1171) {orbit.computation_event = 71 : i64, orbit.phase = 29 : i64, orbit.phase_dependencies = array<i64: 28>, orbit.read_copies = array<i64: 98, 99, 100>, orbit.task = "gemm", orbit.write_copies = array<i64: 101>} : (!air.async.token, !air.async.token) -> ()
            %1172 = "memref.cast"(%1164) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1173 = "memref.cast"(%1168) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %1174 = "memref.cast"(%1080) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1175 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1176 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1177 = "arith.constant"() <{value = 16 : index}> : () -> index
            %1178 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1176, %1177, %1178) ({
            ^bb0(%arg287: index):
              %1180 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1181 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1182 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1180, %1181, %1182) ({
              ^bb0(%arg288: index):
                %1183 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1184 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1185 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1183, %1184, %1185) ({
                ^bb0(%arg289: index):
                  %1186 = "arith.addi"(%arg289, %1159) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1187 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1188 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1189 = "arith.subi"(%arg287, %1188) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1190 = "arith.subi"(%1186, %1161) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1191 = "memref.load"(%1172, %1189, %1190) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1192 = "vector.broadcast"(%1191) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1193 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1194 = "arith.subi"(%1186, %1163) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1195 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1196 = "arith.subi"(%arg288, %1195) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1197 = "vector.transfer_read"(%1173, %1194, %1196, %1193) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1198 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1199 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1200 = "arith.subi"(%arg287, %1199) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1201 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1202 = "arith.subi"(%arg288, %1201) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1203 = "vector.transfer_read"(%1174, %1200, %1202, %1198) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1204 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1205 = "vector.extract"(%1197) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1206 = "func.call"(%1191, %1205) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1207 = "vector.insert"(%1206, %1204) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1208 = "vector.extract"(%1197) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1209 = "func.call"(%1191, %1208) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1210 = "vector.insert"(%1209, %1207) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1211 = "vector.extract"(%1197) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1212 = "func.call"(%1191, %1211) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1213 = "vector.insert"(%1212, %1210) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1214 = "vector.extract"(%1197) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1215 = "func.call"(%1191, %1214) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1216 = "vector.insert"(%1215, %1213) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1217 = "vector.extract"(%1197) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1218 = "func.call"(%1191, %1217) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1219 = "vector.insert"(%1218, %1216) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1220 = "vector.extract"(%1197) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1221 = "func.call"(%1191, %1220) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1222 = "vector.insert"(%1221, %1219) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1223 = "vector.extract"(%1197) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1224 = "func.call"(%1191, %1223) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1225 = "vector.insert"(%1224, %1222) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1226 = "vector.extract"(%1197) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1227 = "func.call"(%1191, %1226) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1228 = "vector.insert"(%1227, %1225) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1229 = "arith.addf"(%1203, %1228) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1230 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1231 = "arith.subi"(%arg287, %1230) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1232 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1233 = "arith.subi"(%arg288, %1232) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1229, %1174, %1231, %1233) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1179 = "air.wait_all"(%arg286) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1179) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1089 = "memref.reinterpret_cast"(%1074) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 33 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1090 = "air.dma_memcpy_nd"(%1088, %1089, %arg278) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 33 : i64, orbit.source_copies = array<i64: 9>, orbit.storage = "A", orbit.target_copies = array<i64: 111>, orbit.transfer = "host_to_l1", orbit.transfer_event = 81 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 8, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1091 = "memref.reinterpret_cast"(%1076) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 33 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %1092 = "air.dma_memcpy_nd"(%1088, %1091, %arg279) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 33 : i64, orbit.source_copies = array<i64: 28>, orbit.storage = "B", orbit.target_copies = array<i64: 112>, orbit.transfer = "host_to_l1", orbit.transfer_event = 82 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 32>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1090, %1092) {orbit.computation_event = 83 : i64, orbit.phase = 33 : i64, orbit.phase_dependencies = array<i64: 32>, orbit.read_copies = array<i64: 111, 112, 110>, orbit.task = "gemm", orbit.write_copies = array<i64: 113>} : (!air.async.token, !air.async.token) -> ()
          %1093 = "memref.cast"(%1089) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1094 = "memref.cast"(%1091) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %1095 = "memref.cast"(%1080) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
          %1096 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1097 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1098 = "arith.constant"() <{value = 16 : index}> : () -> index
          %1099 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1097, %1098, %1099) ({
          ^bb0(%arg282: index):
            %1103 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1104 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1105 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1103, %1104, %1105) ({
            ^bb0(%arg283: index):
              %1106 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1107 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1108 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1106, %1107, %1108) ({
              ^bb0(%arg284: index):
                %1109 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1110 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1111 = "arith.subi"(%arg282, %1110) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1112 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1113 = "arith.subi"(%arg284, %1112) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1114 = "memref.load"(%1093, %1111, %1113) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1115 = "vector.broadcast"(%1114) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1116 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1117 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1118 = "arith.subi"(%arg284, %1117) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1119 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1120 = "arith.subi"(%arg283, %1119) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1121 = "vector.transfer_read"(%1094, %1118, %1120, %1116) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1122 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1123 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1124 = "arith.subi"(%arg282, %1123) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1125 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1126 = "arith.subi"(%arg283, %1125) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1127 = "vector.transfer_read"(%1095, %1124, %1126, %1122) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1128 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1129 = "vector.extract"(%1121) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1130 = "func.call"(%1114, %1129) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1131 = "vector.insert"(%1130, %1128) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1132 = "vector.extract"(%1121) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1133 = "func.call"(%1114, %1132) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1134 = "vector.insert"(%1133, %1131) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1135 = "vector.extract"(%1121) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1136 = "func.call"(%1114, %1135) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1137 = "vector.insert"(%1136, %1134) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1138 = "vector.extract"(%1121) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1139 = "func.call"(%1114, %1138) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1140 = "vector.insert"(%1139, %1137) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1141 = "vector.extract"(%1121) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1142 = "func.call"(%1114, %1141) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1143 = "vector.insert"(%1142, %1140) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1144 = "vector.extract"(%1121) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1145 = "func.call"(%1114, %1144) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1146 = "vector.insert"(%1145, %1143) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1147 = "vector.extract"(%1121) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1148 = "func.call"(%1114, %1147) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1149 = "vector.insert"(%1148, %1146) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1150 = "vector.extract"(%1121) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1151 = "func.call"(%1114, %1150) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1152 = "vector.insert"(%1151, %1149) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1153 = "arith.addf"(%1127, %1152) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %1154 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1155 = "arith.subi"(%arg282, %1154) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1156 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1157 = "arith.subi"(%arg283, %1156) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%1153, %1095, %1155, %1157) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1100 = "air.wait_all"(%1088) : (!air.async.token) -> !air.async.token
          %1101 = "air.dma_memcpy_nd"(%1100, %arg281, %1080) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 33 : i64, orbit.retained_begin = 29 : i64, orbit.retained_end = 34 : i64, orbit.source_copies = array<i64: 113>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 114>, orbit.transfer = "l1_to_host", orbit.transfer_event = 84 : i64, static_dst_offsets = array<i64: 8, 32>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %1102 = "air.wait_all"(%1101) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1102) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_29"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1073) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_29"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_29"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg232: index, %arg233: index, %arg234: index, %arg235: index, %arg236: memref<17x129xf32>, %arg237: memref<129x80xf32>, %arg238: memref<17x80xf32>, %arg239: memref<17x80xf32>):
      "air.segment"(%arg236, %arg237, %arg238, %arg239) ({
      ^bb0(%arg240: memref<17x129xf32>, %arg241: memref<129x80xf32>, %arg242: memref<17x80xf32>, %arg243: memref<17x80xf32>):
        %903 = "arith.constant"() <{value = 1 : index}> : () -> index
        %904 = "air.herd"(%903, %903, %arg240, %arg241, %arg242, %arg243) ({
        ^bb0(%arg244: index, %arg245: index, %arg246: index, %arg247: index, %arg248: memref<17x129xf32>, %arg249: memref<129x80xf32>, %arg250: memref<17x80xf32>, %arg251: memref<17x80xf32>):
          %905 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.16.1"} : () -> memref<8xf32, 2 : i32>
          %906 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.16.32"} : () -> memref<256xf32, 2 : i32>
          %907 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.16.loops.8.16.1"} : () -> memref<16xf32, 2 : i32>
          %908 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.16.loops.8.16.32"} : () -> memref<512xf32, 2 : i32>
          %909 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<128xf32, 2 : i32>
          %910 = "air.wait_all"() : () -> !air.async.token
          %911 = "memref.reinterpret_cast"(%909) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 34 : i64, orbit.storage = "intermediate"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %912 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %913 = "arith.constant"() <{value = 8 : index}> : () -> index
          %914 = "arith.constant"() <{value = 16 : index}> : () -> index
          %915 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%913, %914, %915) ({
          ^bb0(%arg260: index):
            %1065 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1066 = "arith.constant"() <{value = 80 : index}> : () -> index
            %1067 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1065, %1066, %1067) ({
            ^bb0(%arg261: index):
              %1068 = "arith.constant"() <{value = 8 : index}> : () -> index
              %1069 = "arith.subi"(%arg260, %1068) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %1070 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1071 = "arith.subi"(%arg261, %1070) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%912, %911, %1069, %1071) <{nontemporal = false}> : (f32, memref<8x16xf32, strided<[16, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %916 = "arith.constant"() <{value = 0 : index}> : () -> index
          %917 = "arith.constant"() <{value = 4 : index}> : () -> index
          %918 = "arith.constant"() <{value = 1 : index}> : () -> index
          %919 = "scf.for"(%916, %917, %918, %910) ({
          ^bb0(%arg255: index, %arg256: !air.async.token):
            %989 = "arith.constant"() <{value = 32 : index}> : () -> index
            %990 = "arith.muli"(%arg255, %989) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %991 = "arith.constant"() <{value = 32 : index}> : () -> index
            %992 = "arith.muli"(%arg255, %991) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %993 = "arith.constant"() <{value = 32 : index}> : () -> index
            %994 = "arith.muli"(%arg255, %993) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %995 = "memref.reinterpret_cast"(%906) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 34 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %996 = "arith.constant"() <{value = 0 : index}> : () -> index
            %997 = "arith.addi"(%996, %992) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %998 = "air.dma_memcpy_nd"(%arg256, %995, %arg248, %997) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 34 : i64, orbit.source_copies = array<i64: 5>, orbit.storage = "A", orbit.target_copies = array<i64: 115>, orbit.transfer = "host_to_l1", orbit.transfer_event = 85 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 8, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %999 = "memref.reinterpret_cast"(%908) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 34 : i64, orbit.storage = "B"} : (memref<512xf32, 2 : i32>) -> memref<32x16xf32, strided<[16, 1]>, 2 : i32>
            %1000 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1001 = "arith.addi"(%1000, %994) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1002 = "air.dma_memcpy_nd"(%arg256, %999, %arg249, %1001) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 34 : i64, orbit.source_copies = array<i64: 17>, orbit.storage = "B", orbit.target_copies = array<i64: 116>, orbit.transfer = "host_to_l1", orbit.transfer_event = 86 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: -9223372036854775808, 64>, static_src_sizes = array<i64: 32, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%998, %1002) {orbit.computation_event = 88 : i64, orbit.phase = 34 : i64, orbit.phase_dependencies = array<i64: 33>, orbit.read_copies = array<i64: 115, 116, 117>, orbit.task = "gemm", orbit.write_copies = array<i64: 118>} : (!air.async.token, !air.async.token) -> ()
            %1003 = "memref.cast"(%995) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1004 = "memref.cast"(%999) : (memref<32x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<32x16xf32, 2 : i32>
            %1005 = "memref.cast"(%911) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
            %1006 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1007 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1008 = "arith.constant"() <{value = 16 : index}> : () -> index
            %1009 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1007, %1008, %1009) ({
            ^bb0(%arg257: index):
              %1011 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1012 = "arith.constant"() <{value = 80 : index}> : () -> index
              %1013 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1011, %1012, %1013) ({
              ^bb0(%arg258: index):
                %1014 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1015 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1016 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1014, %1015, %1016) ({
                ^bb0(%arg259: index):
                  %1017 = "arith.addi"(%arg259, %990) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1018 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1019 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1020 = "arith.subi"(%arg257, %1019) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1021 = "arith.subi"(%1017, %992) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1022 = "memref.load"(%1003, %1020, %1021) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1023 = "vector.broadcast"(%1022) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1024 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1025 = "arith.subi"(%1017, %994) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1026 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1027 = "arith.subi"(%arg258, %1026) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1028 = "vector.transfer_read"(%1004, %1025, %1027, %1024) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1029 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1030 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1031 = "arith.subi"(%arg257, %1030) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1032 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1033 = "arith.subi"(%arg258, %1032) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1034 = "vector.transfer_read"(%1005, %1031, %1033, %1029) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1035 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1036 = "vector.extract"(%1028) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1037 = "func.call"(%1022, %1036) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1038 = "vector.insert"(%1037, %1035) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1039 = "vector.extract"(%1028) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1040 = "func.call"(%1022, %1039) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1041 = "vector.insert"(%1040, %1038) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1042 = "vector.extract"(%1028) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1043 = "func.call"(%1022, %1042) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1044 = "vector.insert"(%1043, %1041) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1045 = "vector.extract"(%1028) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1046 = "func.call"(%1022, %1045) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1047 = "vector.insert"(%1046, %1044) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1048 = "vector.extract"(%1028) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1049 = "func.call"(%1022, %1048) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1050 = "vector.insert"(%1049, %1047) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1051 = "vector.extract"(%1028) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1052 = "func.call"(%1022, %1051) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1053 = "vector.insert"(%1052, %1050) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1054 = "vector.extract"(%1028) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1055 = "func.call"(%1022, %1054) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1056 = "vector.insert"(%1055, %1053) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1057 = "vector.extract"(%1028) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1058 = "func.call"(%1022, %1057) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1059 = "vector.insert"(%1058, %1056) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1060 = "arith.addf"(%1034, %1059) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1061 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1062 = "arith.subi"(%arg257, %1061) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1063 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1064 = "arith.subi"(%arg258, %1063) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1060, %1005, %1062, %1064) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1010 = "air.wait_all"(%arg256) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1010) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %920 = "memref.reinterpret_cast"(%905) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 38 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %921 = "air.dma_memcpy_nd"(%919, %920, %arg248) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 38 : i64, orbit.source_copies = array<i64: 9>, orbit.storage = "A", orbit.target_copies = array<i64: 128>, orbit.transfer = "host_to_l1", orbit.transfer_event = 98 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 8, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %922 = "memref.reinterpret_cast"(%907) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 38 : i64, orbit.storage = "B"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %923 = "air.dma_memcpy_nd"(%919, %922, %arg249) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 38 : i64, orbit.source_copies = array<i64: 29>, orbit.storage = "B", orbit.target_copies = array<i64: 129>, orbit.transfer = "host_to_l1", orbit.transfer_event = 99 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 128, 64>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%921, %923) {orbit.computation_event = 100 : i64, orbit.phase = 38 : i64, orbit.phase_dependencies = array<i64: 37>, orbit.read_copies = array<i64: 128, 129, 127>, orbit.task = "gemm", orbit.write_copies = array<i64: 130>} : (!air.async.token, !air.async.token) -> ()
          %924 = "memref.cast"(%920) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %925 = "memref.cast"(%922) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %926 = "memref.cast"(%911) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %927 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %928 = "arith.constant"() <{value = 8 : index}> : () -> index
          %929 = "arith.constant"() <{value = 16 : index}> : () -> index
          %930 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%928, %929, %930) ({
          ^bb0(%arg252: index):
            %934 = "arith.constant"() <{value = 64 : index}> : () -> index
            %935 = "arith.constant"() <{value = 80 : index}> : () -> index
            %936 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%934, %935, %936) ({
            ^bb0(%arg253: index):
              %937 = "arith.constant"() <{value = 128 : index}> : () -> index
              %938 = "arith.constant"() <{value = 129 : index}> : () -> index
              %939 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%937, %938, %939) ({
              ^bb0(%arg254: index):
                %940 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %941 = "arith.constant"() <{value = 8 : index}> : () -> index
                %942 = "arith.subi"(%arg252, %941) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %943 = "arith.constant"() <{value = 128 : index}> : () -> index
                %944 = "arith.subi"(%arg254, %943) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %945 = "memref.load"(%924, %942, %944) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %946 = "vector.broadcast"(%945) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %947 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %948 = "arith.constant"() <{value = 128 : index}> : () -> index
                %949 = "arith.subi"(%arg254, %948) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %950 = "arith.constant"() <{value = 64 : index}> : () -> index
                %951 = "arith.subi"(%arg253, %950) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %952 = "vector.transfer_read"(%925, %949, %951, %947) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %953 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %954 = "arith.constant"() <{value = 8 : index}> : () -> index
                %955 = "arith.subi"(%arg252, %954) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %956 = "arith.constant"() <{value = 64 : index}> : () -> index
                %957 = "arith.subi"(%arg253, %956) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %958 = "vector.transfer_read"(%926, %955, %957, %953) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %959 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %960 = "vector.extract"(%952) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %961 = "func.call"(%945, %960) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %962 = "vector.insert"(%961, %959) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %963 = "vector.extract"(%952) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %964 = "func.call"(%945, %963) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %965 = "vector.insert"(%964, %962) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %966 = "vector.extract"(%952) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %967 = "func.call"(%945, %966) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %968 = "vector.insert"(%967, %965) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %969 = "vector.extract"(%952) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %970 = "func.call"(%945, %969) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %971 = "vector.insert"(%970, %968) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %972 = "vector.extract"(%952) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %973 = "func.call"(%945, %972) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %974 = "vector.insert"(%973, %971) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %975 = "vector.extract"(%952) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %976 = "func.call"(%945, %975) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %977 = "vector.insert"(%976, %974) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %978 = "vector.extract"(%952) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %979 = "func.call"(%945, %978) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %980 = "vector.insert"(%979, %977) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %981 = "vector.extract"(%952) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %982 = "func.call"(%945, %981) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %983 = "vector.insert"(%982, %980) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %984 = "arith.addf"(%958, %983) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %985 = "arith.constant"() <{value = 8 : index}> : () -> index
                %986 = "arith.subi"(%arg252, %985) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %987 = "arith.constant"() <{value = 64 : index}> : () -> index
                %988 = "arith.subi"(%arg253, %987) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%984, %926, %986, %988) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %931 = "air.wait_all"(%919) : (!air.async.token) -> !air.async.token
          %932 = "air.dma_memcpy_nd"(%931, %arg251, %911) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 38 : i64, orbit.retained_begin = 34 : i64, orbit.retained_end = 39 : i64, orbit.source_copies = array<i64: 130>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 131>, orbit.transfer = "l1_to_host", orbit.transfer_event = 101 : i64, static_dst_offsets = array<i64: 8, 64>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %933 = "air.wait_all"(%932) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%933) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_34"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%904) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_34"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_34"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg202: index, %arg203: index, %arg204: index, %arg205: index, %arg206: memref<17x129xf32>, %arg207: memref<129x80xf32>, %arg208: memref<17x80xf32>, %arg209: memref<17x80xf32>):
      "air.segment"(%arg206, %arg207, %arg208, %arg209) ({
      ^bb0(%arg210: memref<17x129xf32>, %arg211: memref<129x80xf32>, %arg212: memref<17x80xf32>, %arg213: memref<17x80xf32>):
        %748 = "arith.constant"() <{value = 1 : index}> : () -> index
        %749 = "air.herd"(%748, %748, %arg210, %arg211, %arg212, %arg213) ({
        ^bb0(%arg214: index, %arg215: index, %arg216: index, %arg217: index, %arg218: memref<17x129xf32>, %arg219: memref<129x80xf32>, %arg220: memref<17x80xf32>, %arg221: memref<17x80xf32>):
          %750 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.1.loops.1.32.1"} : () -> memref<1xf32, 2 : i32>
          %751 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.32.loops.1.32.32"} : () -> memref<32xf32, 2 : i32>
          %752 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.1.32.1"} : () -> memref<32xf32, 2 : i32>
          %753 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.1.32.32"} : () -> memref<1024xf32, 2 : i32>
          %754 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<32xf32, 2 : i32>
          %755 = "air.wait_all"() : () -> !air.async.token
          %756 = "memref.reinterpret_cast"(%754) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 39 : i64, orbit.storage = "intermediate"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %757 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %758 = "arith.constant"() <{value = 16 : index}> : () -> index
          %759 = "arith.constant"() <{value = 17 : index}> : () -> index
          %760 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%758, %759, %760) ({
          ^bb0(%arg230: index):
            %898 = "arith.constant"() <{value = 0 : index}> : () -> index
            %899 = "arith.constant"() <{value = 32 : index}> : () -> index
            %900 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%898, %899, %900) ({
            ^bb0(%arg231: index):
              %901 = "arith.constant"() <{value = 16 : index}> : () -> index
              %902 = "arith.subi"(%arg230, %901) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%757, %756, %902, %arg231) <{nontemporal = false}> : (f32, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %761 = "arith.constant"() <{value = 0 : index}> : () -> index
          %762 = "arith.constant"() <{value = 4 : index}> : () -> index
          %763 = "arith.constant"() <{value = 1 : index}> : () -> index
          %764 = "scf.for"(%761, %762, %763, %755) ({
          ^bb0(%arg225: index, %arg226: !air.async.token):
            %828 = "arith.constant"() <{value = 32 : index}> : () -> index
            %829 = "arith.muli"(%arg225, %828) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %830 = "arith.constant"() <{value = 32 : index}> : () -> index
            %831 = "arith.muli"(%arg225, %830) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %832 = "arith.constant"() <{value = 32 : index}> : () -> index
            %833 = "arith.muli"(%arg225, %832) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %834 = "memref.reinterpret_cast"(%751) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 39 : i64, orbit.storage = "A"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %835 = "arith.constant"() <{value = 0 : index}> : () -> index
            %836 = "arith.addi"(%835, %831) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %837 = "air.dma_memcpy_nd"(%arg226, %834, %arg218, %836) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 39 : i64, orbit.source_copies = array<i64: 10>, orbit.storage = "A", orbit.target_copies = array<i64: 132>, orbit.transfer = "host_to_l1", orbit.transfer_event = 102 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 16, -9223372036854775808>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %838 = "memref.reinterpret_cast"(%753) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 39 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %839 = "arith.constant"() <{value = 0 : index}> : () -> index
            %840 = "arith.addi"(%839, %833) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %841 = "air.dma_memcpy_nd"(%arg226, %838, %arg219, %840) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 39 : i64, orbit.source_copies = array<i64: 15>, orbit.storage = "B", orbit.target_copies = array<i64: 133>, orbit.transfer = "host_to_l1", orbit.transfer_event = 103 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 0>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%837, %841) {orbit.computation_event = 105 : i64, orbit.phase = 39 : i64, orbit.phase_dependencies = array<i64: 38>, orbit.read_copies = array<i64: 132, 133, 134>, orbit.task = "gemm", orbit.write_copies = array<i64: 135>} : (!air.async.token, !air.async.token) -> ()
            %842 = "memref.cast"(%834) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %843 = "memref.cast"(%838) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %844 = "memref.cast"(%756) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %845 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %846 = "arith.constant"() <{value = 16 : index}> : () -> index
            %847 = "arith.constant"() <{value = 17 : index}> : () -> index
            %848 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%846, %847, %848) ({
            ^bb0(%arg227: index):
              %850 = "arith.constant"() <{value = 0 : index}> : () -> index
              %851 = "arith.constant"() <{value = 32 : index}> : () -> index
              %852 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%850, %851, %852) ({
              ^bb0(%arg228: index):
                %853 = "arith.constant"() <{value = 0 : index}> : () -> index
                %854 = "arith.constant"() <{value = 32 : index}> : () -> index
                %855 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%853, %854, %855) ({
                ^bb0(%arg229: index):
                  %856 = "arith.addi"(%arg229, %829) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %857 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %858 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %859 = "arith.subi"(%arg227, %858) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %860 = "arith.subi"(%856, %831) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %861 = "memref.load"(%842, %859, %860) <{nontemporal = false}> : (memref<1x32xf32, 2 : i32>, index, index) -> f32
                  %862 = "vector.broadcast"(%861) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %863 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %864 = "arith.subi"(%856, %833) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %865 = "vector.transfer_read"(%843, %864, %arg228, %863) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %866 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %867 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %868 = "arith.subi"(%arg227, %867) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %869 = "vector.transfer_read"(%844, %868, %arg228, %866) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %870 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %871 = "vector.extract"(%865) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %872 = "func.call"(%861, %871) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %873 = "vector.insert"(%872, %870) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %874 = "vector.extract"(%865) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %875 = "func.call"(%861, %874) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %876 = "vector.insert"(%875, %873) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %877 = "vector.extract"(%865) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %878 = "func.call"(%861, %877) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %879 = "vector.insert"(%878, %876) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %880 = "vector.extract"(%865) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %881 = "func.call"(%861, %880) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %882 = "vector.insert"(%881, %879) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %883 = "vector.extract"(%865) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %884 = "func.call"(%861, %883) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %885 = "vector.insert"(%884, %882) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %886 = "vector.extract"(%865) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %887 = "func.call"(%861, %886) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %888 = "vector.insert"(%887, %885) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %889 = "vector.extract"(%865) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %890 = "func.call"(%861, %889) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %891 = "vector.insert"(%890, %888) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %892 = "vector.extract"(%865) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %893 = "func.call"(%861, %892) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %894 = "vector.insert"(%893, %891) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %895 = "arith.addf"(%869, %894) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %896 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %897 = "arith.subi"(%arg227, %896) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%895, %844, %897, %arg228) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %849 = "air.wait_all"(%arg226) : (!air.async.token) -> !air.async.token
            "scf.yield"(%849) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %765 = "memref.reinterpret_cast"(%750) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 43 : i64, orbit.storage = "A"} : (memref<1xf32, 2 : i32>) -> memref<1x1xf32, strided<[1, 1]>, 2 : i32>
          %766 = "air.dma_memcpy_nd"(%764, %765, %arg218) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 43 : i64, orbit.source_copies = array<i64: 14>, orbit.storage = "A", orbit.target_copies = array<i64: 145>, orbit.transfer = "host_to_l1", orbit.transfer_event = 115 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 16, 128>, static_src_sizes = array<i64: 1, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %767 = "memref.reinterpret_cast"(%752) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 43 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %768 = "air.dma_memcpy_nd"(%764, %767, %arg219) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 43 : i64, orbit.source_copies = array<i64: 27>, orbit.storage = "B", orbit.target_copies = array<i64: 146>, orbit.transfer = "host_to_l1", orbit.transfer_event = 116 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%766, %768) {orbit.computation_event = 117 : i64, orbit.phase = 43 : i64, orbit.phase_dependencies = array<i64: 42>, orbit.read_copies = array<i64: 145, 146, 144>, orbit.task = "gemm", orbit.write_copies = array<i64: 147>} : (!air.async.token, !air.async.token) -> ()
          %769 = "memref.cast"(%765) : (memref<1x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<1x1xf32, 2 : i32>
          %770 = "memref.cast"(%767) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %771 = "memref.cast"(%756) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %772 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %773 = "arith.constant"() <{value = 16 : index}> : () -> index
          %774 = "arith.constant"() <{value = 17 : index}> : () -> index
          %775 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%773, %774, %775) ({
          ^bb0(%arg222: index):
            %779 = "arith.constant"() <{value = 0 : index}> : () -> index
            %780 = "arith.constant"() <{value = 32 : index}> : () -> index
            %781 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%779, %780, %781) ({
            ^bb0(%arg223: index):
              %782 = "arith.constant"() <{value = 128 : index}> : () -> index
              %783 = "arith.constant"() <{value = 129 : index}> : () -> index
              %784 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%782, %783, %784) ({
              ^bb0(%arg224: index):
                %785 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %786 = "arith.constant"() <{value = 16 : index}> : () -> index
                %787 = "arith.subi"(%arg222, %786) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %788 = "arith.constant"() <{value = 128 : index}> : () -> index
                %789 = "arith.subi"(%arg224, %788) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %790 = "memref.load"(%769, %787, %789) <{nontemporal = false}> : (memref<1x1xf32, 2 : i32>, index, index) -> f32
                %791 = "vector.broadcast"(%790) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %792 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %793 = "arith.constant"() <{value = 128 : index}> : () -> index
                %794 = "arith.subi"(%arg224, %793) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %795 = "vector.transfer_read"(%770, %794, %arg223, %792) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %796 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %797 = "arith.constant"() <{value = 16 : index}> : () -> index
                %798 = "arith.subi"(%arg222, %797) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %799 = "vector.transfer_read"(%771, %798, %arg223, %796) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %800 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %801 = "vector.extract"(%795) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %802 = "func.call"(%790, %801) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %803 = "vector.insert"(%802, %800) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %804 = "vector.extract"(%795) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %805 = "func.call"(%790, %804) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %806 = "vector.insert"(%805, %803) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %807 = "vector.extract"(%795) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %808 = "func.call"(%790, %807) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %809 = "vector.insert"(%808, %806) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %810 = "vector.extract"(%795) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %811 = "func.call"(%790, %810) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %812 = "vector.insert"(%811, %809) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %813 = "vector.extract"(%795) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %814 = "func.call"(%790, %813) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %815 = "vector.insert"(%814, %812) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %816 = "vector.extract"(%795) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %817 = "func.call"(%790, %816) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %818 = "vector.insert"(%817, %815) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %819 = "vector.extract"(%795) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %820 = "func.call"(%790, %819) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %821 = "vector.insert"(%820, %818) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %822 = "vector.extract"(%795) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %823 = "func.call"(%790, %822) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %824 = "vector.insert"(%823, %821) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %825 = "arith.addf"(%799, %824) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %826 = "arith.constant"() <{value = 16 : index}> : () -> index
                %827 = "arith.subi"(%arg222, %826) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%825, %771, %827, %arg223) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %776 = "air.wait_all"(%764) : (!air.async.token) -> !air.async.token
          %777 = "air.dma_memcpy_nd"(%776, %arg221, %756) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 43 : i64, orbit.retained_begin = 39 : i64, orbit.retained_end = 44 : i64, orbit.source_copies = array<i64: 147>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 148>, orbit.transfer = "l1_to_host", orbit.transfer_event = 118 : i64, static_dst_offsets = array<i64: 16, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %778 = "air.wait_all"(%777) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%778) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_39"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%749) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_39"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_39"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg172: index, %arg173: index, %arg174: index, %arg175: index, %arg176: memref<17x129xf32>, %arg177: memref<129x80xf32>, %arg178: memref<17x80xf32>, %arg179: memref<17x80xf32>):
      "air.segment"(%arg176, %arg177, %arg178, %arg179) ({
      ^bb0(%arg180: memref<17x129xf32>, %arg181: memref<129x80xf32>, %arg182: memref<17x80xf32>, %arg183: memref<17x80xf32>):
        %579 = "arith.constant"() <{value = 1 : index}> : () -> index
        %580 = "air.herd"(%579, %579, %arg180, %arg181, %arg182, %arg183) ({
        ^bb0(%arg184: index, %arg185: index, %arg186: index, %arg187: index, %arg188: memref<17x129xf32>, %arg189: memref<129x80xf32>, %arg190: memref<17x80xf32>, %arg191: memref<17x80xf32>):
          %581 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.1.loops.1.32.1"} : () -> memref<1xf32, 2 : i32>
          %582 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.32.loops.1.32.32"} : () -> memref<32xf32, 2 : i32>
          %583 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.1.32.1"} : () -> memref<32xf32, 2 : i32>
          %584 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.1.32.32"} : () -> memref<1024xf32, 2 : i32>
          %585 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<32xf32, 2 : i32>
          %586 = "air.wait_all"() : () -> !air.async.token
          %587 = "memref.reinterpret_cast"(%585) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 44 : i64, orbit.storage = "intermediate"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %588 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %589 = "arith.constant"() <{value = 16 : index}> : () -> index
          %590 = "arith.constant"() <{value = 17 : index}> : () -> index
          %591 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%589, %590, %591) ({
          ^bb0(%arg200: index):
            %741 = "arith.constant"() <{value = 32 : index}> : () -> index
            %742 = "arith.constant"() <{value = 64 : index}> : () -> index
            %743 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%741, %742, %743) ({
            ^bb0(%arg201: index):
              %744 = "arith.constant"() <{value = 16 : index}> : () -> index
              %745 = "arith.subi"(%arg200, %744) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %746 = "arith.constant"() <{value = 32 : index}> : () -> index
              %747 = "arith.subi"(%arg201, %746) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%588, %587, %745, %747) <{nontemporal = false}> : (f32, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %592 = "arith.constant"() <{value = 0 : index}> : () -> index
          %593 = "arith.constant"() <{value = 4 : index}> : () -> index
          %594 = "arith.constant"() <{value = 1 : index}> : () -> index
          %595 = "scf.for"(%592, %593, %594, %586) ({
          ^bb0(%arg195: index, %arg196: !air.async.token):
            %665 = "arith.constant"() <{value = 32 : index}> : () -> index
            %666 = "arith.muli"(%arg195, %665) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %667 = "arith.constant"() <{value = 32 : index}> : () -> index
            %668 = "arith.muli"(%arg195, %667) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %669 = "arith.constant"() <{value = 32 : index}> : () -> index
            %670 = "arith.muli"(%arg195, %669) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %671 = "memref.reinterpret_cast"(%582) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 44 : i64, orbit.storage = "A"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %672 = "arith.constant"() <{value = 0 : index}> : () -> index
            %673 = "arith.addi"(%672, %668) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %674 = "air.dma_memcpy_nd"(%arg196, %671, %arg188, %673) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 44 : i64, orbit.source_copies = array<i64: 10>, orbit.storage = "A", orbit.target_copies = array<i64: 149>, orbit.transfer = "host_to_l1", orbit.transfer_event = 119 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 16, -9223372036854775808>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %675 = "memref.reinterpret_cast"(%584) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 44 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %676 = "arith.constant"() <{value = 0 : index}> : () -> index
            %677 = "arith.addi"(%676, %670) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %678 = "air.dma_memcpy_nd"(%arg196, %675, %arg189, %677) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 44 : i64, orbit.source_copies = array<i64: 16>, orbit.storage = "B", orbit.target_copies = array<i64: 150>, orbit.transfer = "host_to_l1", orbit.transfer_event = 120 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 32>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%674, %678) {orbit.computation_event = 122 : i64, orbit.phase = 44 : i64, orbit.phase_dependencies = array<i64: 43>, orbit.read_copies = array<i64: 149, 150, 151>, orbit.task = "gemm", orbit.write_copies = array<i64: 152>} : (!air.async.token, !air.async.token) -> ()
            %679 = "memref.cast"(%671) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %680 = "memref.cast"(%675) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %681 = "memref.cast"(%587) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %682 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %683 = "arith.constant"() <{value = 16 : index}> : () -> index
            %684 = "arith.constant"() <{value = 17 : index}> : () -> index
            %685 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%683, %684, %685) ({
            ^bb0(%arg197: index):
              %687 = "arith.constant"() <{value = 32 : index}> : () -> index
              %688 = "arith.constant"() <{value = 64 : index}> : () -> index
              %689 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%687, %688, %689) ({
              ^bb0(%arg198: index):
                %690 = "arith.constant"() <{value = 0 : index}> : () -> index
                %691 = "arith.constant"() <{value = 32 : index}> : () -> index
                %692 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%690, %691, %692) ({
                ^bb0(%arg199: index):
                  %693 = "arith.addi"(%arg199, %666) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %694 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %695 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %696 = "arith.subi"(%arg197, %695) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %697 = "arith.subi"(%693, %668) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %698 = "memref.load"(%679, %696, %697) <{nontemporal = false}> : (memref<1x32xf32, 2 : i32>, index, index) -> f32
                  %699 = "vector.broadcast"(%698) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %700 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %701 = "arith.subi"(%693, %670) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %702 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %703 = "arith.subi"(%arg198, %702) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %704 = "vector.transfer_read"(%680, %701, %703, %700) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %705 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %706 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %707 = "arith.subi"(%arg197, %706) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %708 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %709 = "arith.subi"(%arg198, %708) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %710 = "vector.transfer_read"(%681, %707, %709, %705) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %711 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %712 = "vector.extract"(%704) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %713 = "func.call"(%698, %712) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %714 = "vector.insert"(%713, %711) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %715 = "vector.extract"(%704) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %716 = "func.call"(%698, %715) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %717 = "vector.insert"(%716, %714) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %718 = "vector.extract"(%704) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %719 = "func.call"(%698, %718) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %720 = "vector.insert"(%719, %717) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %721 = "vector.extract"(%704) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %722 = "func.call"(%698, %721) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %723 = "vector.insert"(%722, %720) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %724 = "vector.extract"(%704) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %725 = "func.call"(%698, %724) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %726 = "vector.insert"(%725, %723) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %727 = "vector.extract"(%704) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %728 = "func.call"(%698, %727) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %729 = "vector.insert"(%728, %726) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %730 = "vector.extract"(%704) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %731 = "func.call"(%698, %730) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %732 = "vector.insert"(%731, %729) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %733 = "vector.extract"(%704) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %734 = "func.call"(%698, %733) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %735 = "vector.insert"(%734, %732) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %736 = "arith.addf"(%710, %735) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %737 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %738 = "arith.subi"(%arg197, %737) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %739 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %740 = "arith.subi"(%arg198, %739) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%736, %681, %738, %740) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %686 = "air.wait_all"(%arg196) : (!air.async.token) -> !air.async.token
            "scf.yield"(%686) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %596 = "memref.reinterpret_cast"(%581) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 48 : i64, orbit.storage = "A"} : (memref<1xf32, 2 : i32>) -> memref<1x1xf32, strided<[1, 1]>, 2 : i32>
          %597 = "air.dma_memcpy_nd"(%595, %596, %arg188) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 48 : i64, orbit.source_copies = array<i64: 14>, orbit.storage = "A", orbit.target_copies = array<i64: 162>, orbit.transfer = "host_to_l1", orbit.transfer_event = 132 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 16, 128>, static_src_sizes = array<i64: 1, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %598 = "memref.reinterpret_cast"(%583) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 48 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %599 = "air.dma_memcpy_nd"(%595, %598, %arg189) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 48 : i64, orbit.source_copies = array<i64: 28>, orbit.storage = "B", orbit.target_copies = array<i64: 163>, orbit.transfer = "host_to_l1", orbit.transfer_event = 133 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 32>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%597, %599) {orbit.computation_event = 134 : i64, orbit.phase = 48 : i64, orbit.phase_dependencies = array<i64: 47>, orbit.read_copies = array<i64: 162, 163, 161>, orbit.task = "gemm", orbit.write_copies = array<i64: 164>} : (!air.async.token, !air.async.token) -> ()
          %600 = "memref.cast"(%596) : (memref<1x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<1x1xf32, 2 : i32>
          %601 = "memref.cast"(%598) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %602 = "memref.cast"(%587) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %603 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %604 = "arith.constant"() <{value = 16 : index}> : () -> index
          %605 = "arith.constant"() <{value = 17 : index}> : () -> index
          %606 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%604, %605, %606) ({
          ^bb0(%arg192: index):
            %610 = "arith.constant"() <{value = 32 : index}> : () -> index
            %611 = "arith.constant"() <{value = 64 : index}> : () -> index
            %612 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%610, %611, %612) ({
            ^bb0(%arg193: index):
              %613 = "arith.constant"() <{value = 128 : index}> : () -> index
              %614 = "arith.constant"() <{value = 129 : index}> : () -> index
              %615 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%613, %614, %615) ({
              ^bb0(%arg194: index):
                %616 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %617 = "arith.constant"() <{value = 16 : index}> : () -> index
                %618 = "arith.subi"(%arg192, %617) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %619 = "arith.constant"() <{value = 128 : index}> : () -> index
                %620 = "arith.subi"(%arg194, %619) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %621 = "memref.load"(%600, %618, %620) <{nontemporal = false}> : (memref<1x1xf32, 2 : i32>, index, index) -> f32
                %622 = "vector.broadcast"(%621) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %623 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %624 = "arith.constant"() <{value = 128 : index}> : () -> index
                %625 = "arith.subi"(%arg194, %624) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %626 = "arith.constant"() <{value = 32 : index}> : () -> index
                %627 = "arith.subi"(%arg193, %626) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %628 = "vector.transfer_read"(%601, %625, %627, %623) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %629 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %630 = "arith.constant"() <{value = 16 : index}> : () -> index
                %631 = "arith.subi"(%arg192, %630) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %632 = "arith.constant"() <{value = 32 : index}> : () -> index
                %633 = "arith.subi"(%arg193, %632) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %634 = "vector.transfer_read"(%602, %631, %633, %629) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %635 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %636 = "vector.extract"(%628) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %637 = "func.call"(%621, %636) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %638 = "vector.insert"(%637, %635) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %639 = "vector.extract"(%628) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %640 = "func.call"(%621, %639) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %641 = "vector.insert"(%640, %638) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %642 = "vector.extract"(%628) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %643 = "func.call"(%621, %642) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %644 = "vector.insert"(%643, %641) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %645 = "vector.extract"(%628) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %646 = "func.call"(%621, %645) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %647 = "vector.insert"(%646, %644) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %648 = "vector.extract"(%628) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %649 = "func.call"(%621, %648) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %650 = "vector.insert"(%649, %647) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %651 = "vector.extract"(%628) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %652 = "func.call"(%621, %651) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %653 = "vector.insert"(%652, %650) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %654 = "vector.extract"(%628) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %655 = "func.call"(%621, %654) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %656 = "vector.insert"(%655, %653) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %657 = "vector.extract"(%628) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %658 = "func.call"(%621, %657) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %659 = "vector.insert"(%658, %656) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %660 = "arith.addf"(%634, %659) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %661 = "arith.constant"() <{value = 16 : index}> : () -> index
                %662 = "arith.subi"(%arg192, %661) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %663 = "arith.constant"() <{value = 32 : index}> : () -> index
                %664 = "arith.subi"(%arg193, %663) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%660, %602, %662, %664) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %607 = "air.wait_all"(%595) : (!air.async.token) -> !air.async.token
          %608 = "air.dma_memcpy_nd"(%607, %arg191, %587) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 48 : i64, orbit.retained_begin = 44 : i64, orbit.retained_end = 49 : i64, orbit.source_copies = array<i64: 164>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 165>, orbit.transfer = "l1_to_host", orbit.transfer_event = 135 : i64, static_dst_offsets = array<i64: 16, 32>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %609 = "air.wait_all"(%608) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%609) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_44"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%580) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_44"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_44"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg142: index, %arg143: index, %arg144: index, %arg145: index, %arg146: memref<17x129xf32>, %arg147: memref<129x80xf32>, %arg148: memref<17x80xf32>, %arg149: memref<17x80xf32>):
      "air.segment"(%arg146, %arg147, %arg148, %arg149) ({
      ^bb0(%arg150: memref<17x129xf32>, %arg151: memref<129x80xf32>, %arg152: memref<17x80xf32>, %arg153: memref<17x80xf32>):
        %410 = "arith.constant"() <{value = 1 : index}> : () -> index
        %411 = "air.herd"(%410, %410, %arg150, %arg151, %arg152, %arg153) ({
        ^bb0(%arg154: index, %arg155: index, %arg156: index, %arg157: index, %arg158: memref<17x129xf32>, %arg159: memref<129x80xf32>, %arg160: memref<17x80xf32>, %arg161: memref<17x80xf32>):
          %412 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.1.loops.1.16.1"} : () -> memref<1xf32, 2 : i32>
          %413 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.32.loops.1.16.32"} : () -> memref<32xf32, 2 : i32>
          %414 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.16.loops.1.16.1"} : () -> memref<16xf32, 2 : i32>
          %415 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.16.loops.1.16.32"} : () -> memref<512xf32, 2 : i32>
          %416 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<16xf32, 2 : i32>
          %417 = "air.wait_all"() : () -> !air.async.token
          %418 = "memref.reinterpret_cast"(%416) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 49 : i64, orbit.storage = "intermediate"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %419 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %420 = "arith.constant"() <{value = 16 : index}> : () -> index
          %421 = "arith.constant"() <{value = 17 : index}> : () -> index
          %422 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%420, %421, %422) ({
          ^bb0(%arg170: index):
            %572 = "arith.constant"() <{value = 64 : index}> : () -> index
            %573 = "arith.constant"() <{value = 80 : index}> : () -> index
            %574 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%572, %573, %574) ({
            ^bb0(%arg171: index):
              %575 = "arith.constant"() <{value = 16 : index}> : () -> index
              %576 = "arith.subi"(%arg170, %575) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %577 = "arith.constant"() <{value = 64 : index}> : () -> index
              %578 = "arith.subi"(%arg171, %577) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%419, %418, %576, %578) <{nontemporal = false}> : (f32, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %423 = "arith.constant"() <{value = 0 : index}> : () -> index
          %424 = "arith.constant"() <{value = 4 : index}> : () -> index
          %425 = "arith.constant"() <{value = 1 : index}> : () -> index
          %426 = "scf.for"(%423, %424, %425, %417) ({
          ^bb0(%arg165: index, %arg166: !air.async.token):
            %496 = "arith.constant"() <{value = 32 : index}> : () -> index
            %497 = "arith.muli"(%arg165, %496) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %498 = "arith.constant"() <{value = 32 : index}> : () -> index
            %499 = "arith.muli"(%arg165, %498) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %500 = "arith.constant"() <{value = 32 : index}> : () -> index
            %501 = "arith.muli"(%arg165, %500) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %502 = "memref.reinterpret_cast"(%413) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 49 : i64, orbit.storage = "A"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %503 = "arith.constant"() <{value = 0 : index}> : () -> index
            %504 = "arith.addi"(%503, %499) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %505 = "air.dma_memcpy_nd"(%arg166, %502, %arg158, %504) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 49 : i64, orbit.source_copies = array<i64: 10>, orbit.storage = "A", orbit.target_copies = array<i64: 166>, orbit.transfer = "host_to_l1", orbit.transfer_event = 136 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 16, -9223372036854775808>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %506 = "memref.reinterpret_cast"(%415) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 49 : i64, orbit.storage = "B"} : (memref<512xf32, 2 : i32>) -> memref<32x16xf32, strided<[16, 1]>, 2 : i32>
            %507 = "arith.constant"() <{value = 0 : index}> : () -> index
            %508 = "arith.addi"(%507, %501) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %509 = "air.dma_memcpy_nd"(%arg166, %506, %arg159, %508) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 49 : i64, orbit.source_copies = array<i64: 17>, orbit.storage = "B", orbit.target_copies = array<i64: 167>, orbit.transfer = "host_to_l1", orbit.transfer_event = 137 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: -9223372036854775808, 64>, static_src_sizes = array<i64: 32, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%505, %509) {orbit.computation_event = 139 : i64, orbit.phase = 49 : i64, orbit.phase_dependencies = array<i64: 48>, orbit.read_copies = array<i64: 166, 167, 168>, orbit.task = "gemm", orbit.write_copies = array<i64: 169>} : (!air.async.token, !air.async.token) -> ()
            %510 = "memref.cast"(%502) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %511 = "memref.cast"(%506) : (memref<32x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<32x16xf32, 2 : i32>
            %512 = "memref.cast"(%418) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
            %513 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %514 = "arith.constant"() <{value = 16 : index}> : () -> index
            %515 = "arith.constant"() <{value = 17 : index}> : () -> index
            %516 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%514, %515, %516) ({
            ^bb0(%arg167: index):
              %518 = "arith.constant"() <{value = 64 : index}> : () -> index
              %519 = "arith.constant"() <{value = 80 : index}> : () -> index
              %520 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%518, %519, %520) ({
              ^bb0(%arg168: index):
                %521 = "arith.constant"() <{value = 0 : index}> : () -> index
                %522 = "arith.constant"() <{value = 32 : index}> : () -> index
                %523 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%521, %522, %523) ({
                ^bb0(%arg169: index):
                  %524 = "arith.addi"(%arg169, %497) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %525 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %526 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %527 = "arith.subi"(%arg167, %526) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %528 = "arith.subi"(%524, %499) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %529 = "memref.load"(%510, %527, %528) <{nontemporal = false}> : (memref<1x32xf32, 2 : i32>, index, index) -> f32
                  %530 = "vector.broadcast"(%529) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %531 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %532 = "arith.subi"(%524, %501) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %533 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %534 = "arith.subi"(%arg168, %533) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %535 = "vector.transfer_read"(%511, %532, %534, %531) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %536 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %537 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %538 = "arith.subi"(%arg167, %537) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %539 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %540 = "arith.subi"(%arg168, %539) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %541 = "vector.transfer_read"(%512, %538, %540, %536) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %542 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %543 = "vector.extract"(%535) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %544 = "func.call"(%529, %543) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %545 = "vector.insert"(%544, %542) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %546 = "vector.extract"(%535) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %547 = "func.call"(%529, %546) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %548 = "vector.insert"(%547, %545) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %549 = "vector.extract"(%535) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %550 = "func.call"(%529, %549) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %551 = "vector.insert"(%550, %548) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %552 = "vector.extract"(%535) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %553 = "func.call"(%529, %552) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %554 = "vector.insert"(%553, %551) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %555 = "vector.extract"(%535) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %556 = "func.call"(%529, %555) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %557 = "vector.insert"(%556, %554) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %558 = "vector.extract"(%535) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %559 = "func.call"(%529, %558) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %560 = "vector.insert"(%559, %557) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %561 = "vector.extract"(%535) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %562 = "func.call"(%529, %561) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %563 = "vector.insert"(%562, %560) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %564 = "vector.extract"(%535) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %565 = "func.call"(%529, %564) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %566 = "vector.insert"(%565, %563) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %567 = "arith.addf"(%541, %566) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %568 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %569 = "arith.subi"(%arg167, %568) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %570 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %571 = "arith.subi"(%arg168, %570) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%567, %512, %569, %571) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x16xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %517 = "air.wait_all"(%arg166) : (!air.async.token) -> !air.async.token
            "scf.yield"(%517) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %427 = "memref.reinterpret_cast"(%412) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 53 : i64, orbit.storage = "A"} : (memref<1xf32, 2 : i32>) -> memref<1x1xf32, strided<[1, 1]>, 2 : i32>
          %428 = "air.dma_memcpy_nd"(%426, %427, %arg158) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 53 : i64, orbit.source_copies = array<i64: 14>, orbit.storage = "A", orbit.target_copies = array<i64: 179>, orbit.transfer = "host_to_l1", orbit.transfer_event = 149 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 16, 128>, static_src_sizes = array<i64: 1, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %429 = "memref.reinterpret_cast"(%414) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 53 : i64, orbit.storage = "B"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %430 = "air.dma_memcpy_nd"(%426, %429, %arg159) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 53 : i64, orbit.source_copies = array<i64: 29>, orbit.storage = "B", orbit.target_copies = array<i64: 180>, orbit.transfer = "host_to_l1", orbit.transfer_event = 150 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 128, 64>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%428, %430) {orbit.computation_event = 151 : i64, orbit.phase = 53 : i64, orbit.phase_dependencies = array<i64: 52>, orbit.read_copies = array<i64: 179, 180, 178>, orbit.task = "gemm", orbit.write_copies = array<i64: 181>} : (!air.async.token, !air.async.token) -> ()
          %431 = "memref.cast"(%427) : (memref<1x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<1x1xf32, 2 : i32>
          %432 = "memref.cast"(%429) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %433 = "memref.cast"(%418) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %434 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %435 = "arith.constant"() <{value = 16 : index}> : () -> index
          %436 = "arith.constant"() <{value = 17 : index}> : () -> index
          %437 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%435, %436, %437) ({
          ^bb0(%arg162: index):
            %441 = "arith.constant"() <{value = 64 : index}> : () -> index
            %442 = "arith.constant"() <{value = 80 : index}> : () -> index
            %443 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%441, %442, %443) ({
            ^bb0(%arg163: index):
              %444 = "arith.constant"() <{value = 128 : index}> : () -> index
              %445 = "arith.constant"() <{value = 129 : index}> : () -> index
              %446 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%444, %445, %446) ({
              ^bb0(%arg164: index):
                %447 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %448 = "arith.constant"() <{value = 16 : index}> : () -> index
                %449 = "arith.subi"(%arg162, %448) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %450 = "arith.constant"() <{value = 128 : index}> : () -> index
                %451 = "arith.subi"(%arg164, %450) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %452 = "memref.load"(%431, %449, %451) <{nontemporal = false}> : (memref<1x1xf32, 2 : i32>, index, index) -> f32
                %453 = "vector.broadcast"(%452) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %454 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %455 = "arith.constant"() <{value = 128 : index}> : () -> index
                %456 = "arith.subi"(%arg164, %455) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %457 = "arith.constant"() <{value = 64 : index}> : () -> index
                %458 = "arith.subi"(%arg163, %457) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %459 = "vector.transfer_read"(%432, %456, %458, %454) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %460 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %461 = "arith.constant"() <{value = 16 : index}> : () -> index
                %462 = "arith.subi"(%arg162, %461) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %463 = "arith.constant"() <{value = 64 : index}> : () -> index
                %464 = "arith.subi"(%arg163, %463) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %465 = "vector.transfer_read"(%433, %462, %464, %460) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %466 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %467 = "vector.extract"(%459) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %468 = "func.call"(%452, %467) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %469 = "vector.insert"(%468, %466) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %470 = "vector.extract"(%459) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %471 = "func.call"(%452, %470) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %472 = "vector.insert"(%471, %469) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %473 = "vector.extract"(%459) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %474 = "func.call"(%452, %473) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %475 = "vector.insert"(%474, %472) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %476 = "vector.extract"(%459) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %477 = "func.call"(%452, %476) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %478 = "vector.insert"(%477, %475) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %479 = "vector.extract"(%459) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %480 = "func.call"(%452, %479) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %481 = "vector.insert"(%480, %478) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %482 = "vector.extract"(%459) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %483 = "func.call"(%452, %482) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %484 = "vector.insert"(%483, %481) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %485 = "vector.extract"(%459) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %486 = "func.call"(%452, %485) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %487 = "vector.insert"(%486, %484) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %488 = "vector.extract"(%459) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %489 = "func.call"(%452, %488) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %490 = "vector.insert"(%489, %487) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %491 = "arith.addf"(%465, %490) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %492 = "arith.constant"() <{value = 16 : index}> : () -> index
                %493 = "arith.subi"(%arg162, %492) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %494 = "arith.constant"() <{value = 64 : index}> : () -> index
                %495 = "arith.subi"(%arg163, %494) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%491, %433, %493, %495) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x16xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %438 = "air.wait_all"(%426) : (!air.async.token) -> !air.async.token
          %439 = "air.dma_memcpy_nd"(%438, %arg161, %418) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 53 : i64, orbit.retained_begin = 49 : i64, orbit.retained_end = 54 : i64, orbit.source_copies = array<i64: 181>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 182>, orbit.transfer = "l1_to_host", orbit.transfer_event = 152 : i64, static_dst_offsets = array<i64: 16, 64>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %440 = "air.wait_all"(%439) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%440) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_49"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%411) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_49"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_49"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg118: index, %arg119: index, %arg120: index, %arg121: index, %arg122: memref<17x129xf32>, %arg123: memref<129x80xf32>, %arg124: memref<17x80xf32>, %arg125: memref<17x80xf32>):
      "air.segment"(%arg122, %arg123, %arg124, %arg125) ({
      ^bb0(%arg126: memref<17x129xf32>, %arg127: memref<129x80xf32>, %arg128: memref<17x80xf32>, %arg129: memref<17x80xf32>):
        %338 = "arith.constant"() <{value = 1 : index}> : () -> index
        %339 = "air.herd"(%338, %338, %arg126, %arg127, %arg128, %arg129) ({
        ^bb0(%arg130: index, %arg131: index, %arg132: index, %arg133: index, %arg134: memref<17x129xf32>, %arg135: memref<129x80xf32>, %arg136: memref<17x80xf32>, %arg137: memref<17x80xf32>):
          %340 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<256xf32, 2 : i32>
          %341 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.8.32.loops.8.32"} : () -> memref<256xf32, 2 : i32>
          %342 = "air.wait_all"() : () -> !air.async.token
          %343 = "arith.constant"() <{value = 0 : index}> : () -> index
          %344 = "arith.constant"() <{value = 2 : index}> : () -> index
          %345 = "arith.constant"() <{value = 1 : index}> : () -> index
          %346 = "scf.for"(%343, %344, %345, %342) ({
          ^bb0(%arg138: index, %arg139: !air.async.token):
            %347 = "arith.constant"() <{value = 32 : index}> : () -> index
            %348 = "arith.muli"(%arg138, %347) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %349 = "arith.constant"() <{value = 32 : index}> : () -> index
            %350 = "arith.muli"(%arg138, %349) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %351 = "arith.constant"() <{value = 32 : index}> : () -> index
            %352 = "arith.muli"(%arg138, %351) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %353 = "memref.reinterpret_cast"(%340) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 54 : i64, orbit.storage = "Y"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %354 = "memref.reinterpret_cast"(%341) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 54 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %355 = "arith.constant"() <{value = 0 : index}> : () -> index
            %356 = "arith.addi"(%355, %352) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %357 = "air.dma_memcpy_nd"(%arg139, %354, %arg137, %356) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 54 : i64, orbit.source_copies = array<i64: 46>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 183>, orbit.transfer = "host_to_l1", orbit.transfer_event = 153 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 0, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x80xf32>, index) -> !air.async.token
            "air.wait_all"(%357) {orbit.computation_event = 154 : i64, orbit.phase = 54 : i64, orbit.phase_dependencies = array<i64: 53>, orbit.read_copies = array<i64: 183>, orbit.task = "scale", orbit.write_copies = array<i64: 184>} : (!air.async.token) -> ()
            %358 = "memref.cast"(%353) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %359 = "memref.cast"(%354) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %360 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
            %361 = "arith.constant"() <{value = 0 : index}> : () -> index
            %362 = "arith.constant"() <{value = 8 : index}> : () -> index
            %363 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%361, %362, %363) ({
            ^bb0(%arg140: index):
              %368 = "arith.constant"() <{value = 0 : index}> : () -> index
              %369 = "arith.constant"() <{value = 32 : index}> : () -> index
              %370 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%368, %369, %370) ({
              ^bb0(%arg141: index):
                %371 = "arith.addi"(%arg141, %348) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %372 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
                %373 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %374 = "arith.subi"(%371, %352) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %375 = "vector.transfer_read"(%359, %arg140, %374, %373) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %376 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %377 = "vector.extract"(%375) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %378 = "vector.extract"(%372) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %379 = "func.call"(%377, %378) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %380 = "vector.insert"(%379, %376) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %381 = "vector.extract"(%375) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %382 = "vector.extract"(%372) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %383 = "func.call"(%381, %382) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %384 = "vector.insert"(%383, %380) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %385 = "vector.extract"(%375) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %386 = "vector.extract"(%372) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %387 = "func.call"(%385, %386) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %388 = "vector.insert"(%387, %384) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %389 = "vector.extract"(%375) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %390 = "vector.extract"(%372) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %391 = "func.call"(%389, %390) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %392 = "vector.insert"(%391, %388) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %393 = "vector.extract"(%375) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %394 = "vector.extract"(%372) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %395 = "func.call"(%393, %394) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %396 = "vector.insert"(%395, %392) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %397 = "vector.extract"(%375) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %398 = "vector.extract"(%372) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %399 = "func.call"(%397, %398) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %400 = "vector.insert"(%399, %396) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %401 = "vector.extract"(%375) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %402 = "vector.extract"(%372) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %403 = "func.call"(%401, %402) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %404 = "vector.insert"(%403, %400) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %405 = "vector.extract"(%375) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %406 = "vector.extract"(%372) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %407 = "func.call"(%405, %406) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %408 = "vector.insert"(%407, %404) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %409 = "arith.subi"(%371, %350) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%408, %358, %arg140, %409) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %364 = "arith.constant"() <{value = 0 : index}> : () -> index
            %365 = "arith.addi"(%364, %350) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %366 = "air.dma_memcpy_nd"(%arg139, %arg136, %365, %353) {operandSegmentSizes = array<i32: 1, 1, 1, 0, 0, 1, 0, 0, 0>, orbit.phase = 54 : i64, orbit.source_copies = array<i64: 184>, orbit.storage = "Y", orbit.target_copies = array<i64: 185>, orbit.transfer = "l1_to_host", orbit.transfer_event = 155 : i64, static_dst_offsets = array<i64: 0, -9223372036854775808>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, index, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
            %367 = "air.wait_all"(%366) : (!air.async.token) -> !air.async.token
            "scf.yield"(%367) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 2 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          "air.wait_all"(%346) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_54"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%339) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_54"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_54"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg96: index, %arg97: index, %arg98: index, %arg99: index, %arg100: memref<17x129xf32>, %arg101: memref<129x80xf32>, %arg102: memref<17x80xf32>, %arg103: memref<17x80xf32>):
      "air.segment"(%arg100, %arg101, %arg102, %arg103) ({
      ^bb0(%arg104: memref<17x129xf32>, %arg105: memref<129x80xf32>, %arg106: memref<17x80xf32>, %arg107: memref<17x80xf32>):
        %279 = "arith.constant"() <{value = 1 : index}> : () -> index
        %280 = "air.herd"(%279, %279, %arg104, %arg105, %arg106, %arg107) ({
        ^bb0(%arg108: index, %arg109: index, %arg110: index, %arg111: index, %arg112: memref<17x129xf32>, %arg113: memref<129x80xf32>, %arg114: memref<17x80xf32>, %arg115: memref<17x80xf32>):
          %281 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<128xf32, 2 : i32>
          %282 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.8.16.loops.8.16"} : () -> memref<128xf32, 2 : i32>
          %283 = "air.wait_all"() : () -> !air.async.token
          %284 = "memref.reinterpret_cast"(%281) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 56 : i64, orbit.storage = "Y"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %285 = "memref.reinterpret_cast"(%282) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 56 : i64, orbit.storage = "intermediate"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %286 = "air.dma_memcpy_nd"(%283, %285, %arg115) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 56 : i64, orbit.source_copies = array<i64: 80>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 189>, orbit.transfer = "host_to_l1", orbit.transfer_event = 159 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 0, 64>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<8x16xf32, strided<[16, 1]>, 2 : i32>, memref<17x80xf32>) -> !air.async.token
          "air.wait_all"(%286) {orbit.computation_event = 160 : i64, orbit.phase = 56 : i64, orbit.phase_dependencies = array<i64: 55>, orbit.read_copies = array<i64: 189>, orbit.task = "scale", orbit.write_copies = array<i64: 190>} : (!air.async.token) -> ()
          %287 = "memref.cast"(%284) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %288 = "memref.cast"(%285) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %289 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
          %290 = "arith.constant"() <{value = 0 : index}> : () -> index
          %291 = "arith.constant"() <{value = 8 : index}> : () -> index
          %292 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%290, %291, %292) ({
          ^bb0(%arg116: index):
            %295 = "arith.constant"() <{value = 64 : index}> : () -> index
            %296 = "arith.constant"() <{value = 80 : index}> : () -> index
            %297 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%295, %296, %297) ({
            ^bb0(%arg117: index):
              %298 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
              %299 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
              %300 = "arith.constant"() <{value = 64 : index}> : () -> index
              %301 = "arith.subi"(%arg117, %300) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %302 = "vector.transfer_read"(%288, %arg116, %301, %299) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
              %303 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
              %304 = "vector.extract"(%302) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %305 = "vector.extract"(%298) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %306 = "func.call"(%304, %305) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %307 = "vector.insert"(%306, %303) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %308 = "vector.extract"(%302) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %309 = "vector.extract"(%298) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %310 = "func.call"(%308, %309) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %311 = "vector.insert"(%310, %307) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %312 = "vector.extract"(%302) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %313 = "vector.extract"(%298) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %314 = "func.call"(%312, %313) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %315 = "vector.insert"(%314, %311) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %316 = "vector.extract"(%302) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %317 = "vector.extract"(%298) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %318 = "func.call"(%316, %317) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %319 = "vector.insert"(%318, %315) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %320 = "vector.extract"(%302) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %321 = "vector.extract"(%298) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %322 = "func.call"(%320, %321) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %323 = "vector.insert"(%322, %319) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %324 = "vector.extract"(%302) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %325 = "vector.extract"(%298) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %326 = "func.call"(%324, %325) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %327 = "vector.insert"(%326, %323) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %328 = "vector.extract"(%302) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %329 = "vector.extract"(%298) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %330 = "func.call"(%328, %329) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %331 = "vector.insert"(%330, %327) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %332 = "vector.extract"(%302) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %333 = "vector.extract"(%298) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %334 = "func.call"(%332, %333) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %335 = "vector.insert"(%334, %331) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %336 = "arith.constant"() <{value = 64 : index}> : () -> index
              %337 = "arith.subi"(%arg117, %336) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "vector.transfer_write"(%335, %287, %arg116, %337) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %293 = "air.dma_memcpy_nd"(%283, %arg114, %284) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 56 : i64, orbit.source_copies = array<i64: 190>, orbit.storage = "Y", orbit.target_copies = array<i64: 191>, orbit.transfer = "l1_to_host", orbit.transfer_event = 161 : i64, static_dst_offsets = array<i64: 0, 64>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %294 = "air.wait_all"(%293) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%294) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_56"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%280) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_56"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_56"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg72: index, %arg73: index, %arg74: index, %arg75: index, %arg76: memref<17x129xf32>, %arg77: memref<129x80xf32>, %arg78: memref<17x80xf32>, %arg79: memref<17x80xf32>):
      "air.segment"(%arg76, %arg77, %arg78, %arg79) ({
      ^bb0(%arg80: memref<17x129xf32>, %arg81: memref<129x80xf32>, %arg82: memref<17x80xf32>, %arg83: memref<17x80xf32>):
        %203 = "arith.constant"() <{value = 1 : index}> : () -> index
        %204 = "air.herd"(%203, %203, %arg80, %arg81, %arg82, %arg83) ({
        ^bb0(%arg84: index, %arg85: index, %arg86: index, %arg87: index, %arg88: memref<17x129xf32>, %arg89: memref<129x80xf32>, %arg90: memref<17x80xf32>, %arg91: memref<17x80xf32>):
          %205 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<256xf32, 2 : i32>
          %206 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.8.32.loops.8.32"} : () -> memref<256xf32, 2 : i32>
          %207 = "air.wait_all"() : () -> !air.async.token
          %208 = "arith.constant"() <{value = 0 : index}> : () -> index
          %209 = "arith.constant"() <{value = 2 : index}> : () -> index
          %210 = "arith.constant"() <{value = 1 : index}> : () -> index
          %211 = "scf.for"(%208, %209, %210, %207) ({
          ^bb0(%arg92: index, %arg93: !air.async.token):
            %212 = "arith.constant"() <{value = 32 : index}> : () -> index
            %213 = "arith.muli"(%arg92, %212) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %214 = "arith.constant"() <{value = 32 : index}> : () -> index
            %215 = "arith.muli"(%arg92, %214) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %216 = "arith.constant"() <{value = 32 : index}> : () -> index
            %217 = "arith.muli"(%arg92, %216) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %218 = "memref.reinterpret_cast"(%205) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 57 : i64, orbit.storage = "Y"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %219 = "memref.reinterpret_cast"(%206) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 57 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %220 = "arith.constant"() <{value = 0 : index}> : () -> index
            %221 = "arith.addi"(%220, %217) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %222 = "air.dma_memcpy_nd"(%arg93, %219, %arg91, %221) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 57 : i64, orbit.source_copies = array<i64: 97>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 192>, orbit.transfer = "host_to_l1", orbit.transfer_event = 162 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 8, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x80xf32>, index) -> !air.async.token
            "air.wait_all"(%222) {orbit.computation_event = 163 : i64, orbit.phase = 57 : i64, orbit.phase_dependencies = array<i64: 56>, orbit.read_copies = array<i64: 192>, orbit.task = "scale", orbit.write_copies = array<i64: 193>} : (!air.async.token) -> ()
            %223 = "memref.cast"(%218) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %224 = "memref.cast"(%219) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %225 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
            %226 = "arith.constant"() <{value = 8 : index}> : () -> index
            %227 = "arith.constant"() <{value = 16 : index}> : () -> index
            %228 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%226, %227, %228) ({
            ^bb0(%arg94: index):
              %233 = "arith.constant"() <{value = 0 : index}> : () -> index
              %234 = "arith.constant"() <{value = 32 : index}> : () -> index
              %235 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%233, %234, %235) ({
              ^bb0(%arg95: index):
                %236 = "arith.addi"(%arg95, %213) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %237 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
                %238 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %239 = "arith.constant"() <{value = 8 : index}> : () -> index
                %240 = "arith.subi"(%arg94, %239) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %241 = "arith.subi"(%236, %217) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %242 = "vector.transfer_read"(%224, %240, %241, %238) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %243 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %244 = "vector.extract"(%242) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %245 = "vector.extract"(%237) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %246 = "func.call"(%244, %245) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %247 = "vector.insert"(%246, %243) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %248 = "vector.extract"(%242) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %249 = "vector.extract"(%237) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %250 = "func.call"(%248, %249) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %251 = "vector.insert"(%250, %247) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %252 = "vector.extract"(%242) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %253 = "vector.extract"(%237) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %254 = "func.call"(%252, %253) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %255 = "vector.insert"(%254, %251) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %256 = "vector.extract"(%242) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %257 = "vector.extract"(%237) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %258 = "func.call"(%256, %257) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %259 = "vector.insert"(%258, %255) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %260 = "vector.extract"(%242) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %261 = "vector.extract"(%237) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %262 = "func.call"(%260, %261) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %263 = "vector.insert"(%262, %259) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %264 = "vector.extract"(%242) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %265 = "vector.extract"(%237) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %266 = "func.call"(%264, %265) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %267 = "vector.insert"(%266, %263) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %268 = "vector.extract"(%242) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %269 = "vector.extract"(%237) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %270 = "func.call"(%268, %269) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %271 = "vector.insert"(%270, %267) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %272 = "vector.extract"(%242) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %273 = "vector.extract"(%237) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %274 = "func.call"(%272, %273) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %275 = "vector.insert"(%274, %271) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %276 = "arith.constant"() <{value = 8 : index}> : () -> index
                %277 = "arith.subi"(%arg94, %276) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %278 = "arith.subi"(%236, %215) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%275, %223, %277, %278) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %229 = "arith.constant"() <{value = 0 : index}> : () -> index
            %230 = "arith.addi"(%229, %215) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %231 = "air.dma_memcpy_nd"(%arg93, %arg90, %230, %218) {operandSegmentSizes = array<i32: 1, 1, 1, 0, 0, 1, 0, 0, 0>, orbit.phase = 57 : i64, orbit.source_copies = array<i64: 193>, orbit.storage = "Y", orbit.target_copies = array<i64: 194>, orbit.transfer = "l1_to_host", orbit.transfer_event = 164 : i64, static_dst_offsets = array<i64: 8, -9223372036854775808>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, index, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
            %232 = "air.wait_all"(%231) : (!air.async.token) -> !air.async.token
            "scf.yield"(%232) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 2 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          "air.wait_all"(%211) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_57"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%204) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_57"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_57"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg50: index, %arg51: index, %arg52: index, %arg53: index, %arg54: memref<17x129xf32>, %arg55: memref<129x80xf32>, %arg56: memref<17x80xf32>, %arg57: memref<17x80xf32>):
      "air.segment"(%arg54, %arg55, %arg56, %arg57) ({
      ^bb0(%arg58: memref<17x129xf32>, %arg59: memref<129x80xf32>, %arg60: memref<17x80xf32>, %arg61: memref<17x80xf32>):
        %140 = "arith.constant"() <{value = 1 : index}> : () -> index
        %141 = "air.herd"(%140, %140, %arg58, %arg59, %arg60, %arg61) ({
        ^bb0(%arg62: index, %arg63: index, %arg64: index, %arg65: index, %arg66: memref<17x129xf32>, %arg67: memref<129x80xf32>, %arg68: memref<17x80xf32>, %arg69: memref<17x80xf32>):
          %142 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<128xf32, 2 : i32>
          %143 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.8.16.loops.8.16"} : () -> memref<128xf32, 2 : i32>
          %144 = "air.wait_all"() : () -> !air.async.token
          %145 = "memref.reinterpret_cast"(%142) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 59 : i64, orbit.storage = "Y"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %146 = "memref.reinterpret_cast"(%143) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 59 : i64, orbit.storage = "intermediate"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %147 = "air.dma_memcpy_nd"(%144, %146, %arg69) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 59 : i64, orbit.source_copies = array<i64: 131>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 198>, orbit.transfer = "host_to_l1", orbit.transfer_event = 168 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 8, 64>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<8x16xf32, strided<[16, 1]>, 2 : i32>, memref<17x80xf32>) -> !air.async.token
          "air.wait_all"(%147) {orbit.computation_event = 169 : i64, orbit.phase = 59 : i64, orbit.phase_dependencies = array<i64: 58>, orbit.read_copies = array<i64: 198>, orbit.task = "scale", orbit.write_copies = array<i64: 199>} : (!air.async.token) -> ()
          %148 = "memref.cast"(%145) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %149 = "memref.cast"(%146) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %150 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
          %151 = "arith.constant"() <{value = 8 : index}> : () -> index
          %152 = "arith.constant"() <{value = 16 : index}> : () -> index
          %153 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%151, %152, %153) ({
          ^bb0(%arg70: index):
            %156 = "arith.constant"() <{value = 64 : index}> : () -> index
            %157 = "arith.constant"() <{value = 80 : index}> : () -> index
            %158 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%156, %157, %158) ({
            ^bb0(%arg71: index):
              %159 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
              %160 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
              %161 = "arith.constant"() <{value = 8 : index}> : () -> index
              %162 = "arith.subi"(%arg70, %161) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %163 = "arith.constant"() <{value = 64 : index}> : () -> index
              %164 = "arith.subi"(%arg71, %163) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %165 = "vector.transfer_read"(%149, %162, %164, %160) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
              %166 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
              %167 = "vector.extract"(%165) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %168 = "vector.extract"(%159) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %169 = "func.call"(%167, %168) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %170 = "vector.insert"(%169, %166) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %171 = "vector.extract"(%165) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %172 = "vector.extract"(%159) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %173 = "func.call"(%171, %172) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %174 = "vector.insert"(%173, %170) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %175 = "vector.extract"(%165) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %176 = "vector.extract"(%159) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %177 = "func.call"(%175, %176) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %178 = "vector.insert"(%177, %174) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %179 = "vector.extract"(%165) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %180 = "vector.extract"(%159) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %181 = "func.call"(%179, %180) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %182 = "vector.insert"(%181, %178) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %183 = "vector.extract"(%165) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %184 = "vector.extract"(%159) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %185 = "func.call"(%183, %184) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %186 = "vector.insert"(%185, %182) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %187 = "vector.extract"(%165) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %188 = "vector.extract"(%159) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %189 = "func.call"(%187, %188) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %190 = "vector.insert"(%189, %186) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %191 = "vector.extract"(%165) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %192 = "vector.extract"(%159) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %193 = "func.call"(%191, %192) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %194 = "vector.insert"(%193, %190) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %195 = "vector.extract"(%165) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %196 = "vector.extract"(%159) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %197 = "func.call"(%195, %196) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %198 = "vector.insert"(%197, %194) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %199 = "arith.constant"() <{value = 8 : index}> : () -> index
              %200 = "arith.subi"(%arg70, %199) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %201 = "arith.constant"() <{value = 64 : index}> : () -> index
              %202 = "arith.subi"(%arg71, %201) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "vector.transfer_write"(%198, %148, %200, %202) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %154 = "air.dma_memcpy_nd"(%144, %arg68, %145) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 59 : i64, orbit.source_copies = array<i64: 199>, orbit.storage = "Y", orbit.target_copies = array<i64: 200>, orbit.transfer = "l1_to_host", orbit.transfer_event = 170 : i64, static_dst_offsets = array<i64: 8, 64>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %155 = "air.wait_all"(%154) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%155) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_59"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%141) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_59"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_59"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg26: index, %arg27: index, %arg28: index, %arg29: index, %arg30: memref<17x129xf32>, %arg31: memref<129x80xf32>, %arg32: memref<17x80xf32>, %arg33: memref<17x80xf32>):
      "air.segment"(%arg30, %arg31, %arg32, %arg33) ({
      ^bb0(%arg34: memref<17x129xf32>, %arg35: memref<129x80xf32>, %arg36: memref<17x80xf32>, %arg37: memref<17x80xf32>):
        %64 = "arith.constant"() <{value = 1 : index}> : () -> index
        %65 = "air.herd"(%64, %64, %arg34, %arg35, %arg36, %arg37) ({
        ^bb0(%arg38: index, %arg39: index, %arg40: index, %arg41: index, %arg42: memref<17x129xf32>, %arg43: memref<129x80xf32>, %arg44: memref<17x80xf32>, %arg45: memref<17x80xf32>):
          %66 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<32xf32, 2 : i32>
          %67 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.1.32.loops.1.32"} : () -> memref<32xf32, 2 : i32>
          %68 = "air.wait_all"() : () -> !air.async.token
          %69 = "arith.constant"() <{value = 0 : index}> : () -> index
          %70 = "arith.constant"() <{value = 2 : index}> : () -> index
          %71 = "arith.constant"() <{value = 1 : index}> : () -> index
          %72 = "scf.for"(%69, %70, %71, %68) ({
          ^bb0(%arg46: index, %arg47: !air.async.token):
            %73 = "arith.constant"() <{value = 32 : index}> : () -> index
            %74 = "arith.muli"(%arg46, %73) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %75 = "arith.constant"() <{value = 32 : index}> : () -> index
            %76 = "arith.muli"(%arg46, %75) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %77 = "arith.constant"() <{value = 32 : index}> : () -> index
            %78 = "arith.muli"(%arg46, %77) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %79 = "memref.reinterpret_cast"(%66) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 60 : i64, orbit.storage = "Y"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %80 = "memref.reinterpret_cast"(%67) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 60 : i64, orbit.storage = "intermediate"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %81 = "arith.constant"() <{value = 0 : index}> : () -> index
            %82 = "arith.addi"(%81, %78) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %83 = "air.dma_memcpy_nd"(%arg47, %80, %arg45, %82) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 60 : i64, orbit.source_copies = array<i64: 148>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 201>, orbit.transfer = "host_to_l1", orbit.transfer_event = 171 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 16, -9223372036854775808>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x80xf32>, index) -> !air.async.token
            "air.wait_all"(%83) {orbit.computation_event = 172 : i64, orbit.phase = 60 : i64, orbit.phase_dependencies = array<i64: 59>, orbit.read_copies = array<i64: 201>, orbit.task = "scale", orbit.write_copies = array<i64: 202>} : (!air.async.token) -> ()
            %84 = "memref.cast"(%79) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %85 = "memref.cast"(%80) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %86 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
            %87 = "arith.constant"() <{value = 16 : index}> : () -> index
            %88 = "arith.constant"() <{value = 17 : index}> : () -> index
            %89 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%87, %88, %89) ({
            ^bb0(%arg48: index):
              %94 = "arith.constant"() <{value = 0 : index}> : () -> index
              %95 = "arith.constant"() <{value = 32 : index}> : () -> index
              %96 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%94, %95, %96) ({
              ^bb0(%arg49: index):
                %97 = "arith.addi"(%arg49, %74) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %98 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
                %99 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %100 = "arith.constant"() <{value = 16 : index}> : () -> index
                %101 = "arith.subi"(%arg48, %100) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %102 = "arith.subi"(%97, %78) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %103 = "vector.transfer_read"(%85, %101, %102, %99) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %104 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %105 = "vector.extract"(%103) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %106 = "vector.extract"(%98) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %107 = "func.call"(%105, %106) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %108 = "vector.insert"(%107, %104) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %109 = "vector.extract"(%103) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %110 = "vector.extract"(%98) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %111 = "func.call"(%109, %110) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %112 = "vector.insert"(%111, %108) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %113 = "vector.extract"(%103) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %114 = "vector.extract"(%98) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %115 = "func.call"(%113, %114) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %116 = "vector.insert"(%115, %112) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %117 = "vector.extract"(%103) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %118 = "vector.extract"(%98) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %119 = "func.call"(%117, %118) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %120 = "vector.insert"(%119, %116) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %121 = "vector.extract"(%103) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %122 = "vector.extract"(%98) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %123 = "func.call"(%121, %122) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %124 = "vector.insert"(%123, %120) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %125 = "vector.extract"(%103) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %126 = "vector.extract"(%98) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %127 = "func.call"(%125, %126) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %128 = "vector.insert"(%127, %124) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %129 = "vector.extract"(%103) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %130 = "vector.extract"(%98) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %131 = "func.call"(%129, %130) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %132 = "vector.insert"(%131, %128) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %133 = "vector.extract"(%103) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %134 = "vector.extract"(%98) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %135 = "func.call"(%133, %134) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %136 = "vector.insert"(%135, %132) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %137 = "arith.constant"() <{value = 16 : index}> : () -> index
                %138 = "arith.subi"(%arg48, %137) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %139 = "arith.subi"(%97, %76) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%136, %84, %138, %139) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %90 = "arith.constant"() <{value = 0 : index}> : () -> index
            %91 = "arith.addi"(%90, %76) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %92 = "air.dma_memcpy_nd"(%arg47, %arg44, %91, %79) {operandSegmentSizes = array<i32: 1, 1, 1, 0, 0, 1, 0, 0, 0>, orbit.phase = 60 : i64, orbit.source_copies = array<i64: 202>, orbit.storage = "Y", orbit.target_copies = array<i64: 203>, orbit.transfer = "l1_to_host", orbit.transfer_event = 173 : i64, static_dst_offsets = array<i64: 16, -9223372036854775808>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, index, memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
            %93 = "air.wait_all"(%92) : (!air.async.token) -> !air.async.token
            "scf.yield"(%93) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 2 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          "air.wait_all"(%72) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_60"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%65) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_60"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_60"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: memref<17x129xf32>, %arg9: memref<129x80xf32>, %arg10: memref<17x80xf32>, %arg11: memref<17x80xf32>):
      "air.segment"(%arg8, %arg9, %arg10, %arg11) ({
      ^bb0(%arg12: memref<17x129xf32>, %arg13: memref<129x80xf32>, %arg14: memref<17x80xf32>, %arg15: memref<17x80xf32>):
        %1 = "arith.constant"() <{value = 1 : index}> : () -> index
        %2 = "air.herd"(%1, %1, %arg12, %arg13, %arg14, %arg15) ({
        ^bb0(%arg16: index, %arg17: index, %arg18: index, %arg19: index, %arg20: memref<17x129xf32>, %arg21: memref<129x80xf32>, %arg22: memref<17x80xf32>, %arg23: memref<17x80xf32>):
          %3 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<16xf32, 2 : i32>
          %4 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.1.16.loops.1.16"} : () -> memref<16xf32, 2 : i32>
          %5 = "air.wait_all"() : () -> !air.async.token
          %6 = "memref.reinterpret_cast"(%3) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 62 : i64, orbit.storage = "Y"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %7 = "memref.reinterpret_cast"(%4) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 62 : i64, orbit.storage = "intermediate"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %8 = "air.dma_memcpy_nd"(%5, %7, %arg23) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 62 : i64, orbit.source_copies = array<i64: 182>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 207>, orbit.transfer = "host_to_l1", orbit.transfer_event = 177 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 16, 64>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, memref<17x80xf32>) -> !air.async.token
          "air.wait_all"(%8) {orbit.computation_event = 178 : i64, orbit.phase = 62 : i64, orbit.phase_dependencies = array<i64: 61>, orbit.read_copies = array<i64: 207>, orbit.task = "scale", orbit.write_copies = array<i64: 208>} : (!air.async.token) -> ()
          %9 = "memref.cast"(%6) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %10 = "memref.cast"(%7) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %11 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
          %12 = "arith.constant"() <{value = 16 : index}> : () -> index
          %13 = "arith.constant"() <{value = 17 : index}> : () -> index
          %14 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%12, %13, %14) ({
          ^bb0(%arg24: index):
            %17 = "arith.constant"() <{value = 64 : index}> : () -> index
            %18 = "arith.constant"() <{value = 80 : index}> : () -> index
            %19 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%17, %18, %19) ({
            ^bb0(%arg25: index):
              %20 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
              %21 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
              %22 = "arith.constant"() <{value = 16 : index}> : () -> index
              %23 = "arith.subi"(%arg24, %22) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %24 = "arith.constant"() <{value = 64 : index}> : () -> index
              %25 = "arith.subi"(%arg25, %24) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %26 = "vector.transfer_read"(%10, %23, %25, %21) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
              %27 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
              %28 = "vector.extract"(%26) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %29 = "vector.extract"(%20) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %30 = "func.call"(%28, %29) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %31 = "vector.insert"(%30, %27) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %32 = "vector.extract"(%26) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %33 = "vector.extract"(%20) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %34 = "func.call"(%32, %33) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %35 = "vector.insert"(%34, %31) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %36 = "vector.extract"(%26) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %37 = "vector.extract"(%20) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %38 = "func.call"(%36, %37) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %39 = "vector.insert"(%38, %35) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %40 = "vector.extract"(%26) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %41 = "vector.extract"(%20) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %42 = "func.call"(%40, %41) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %43 = "vector.insert"(%42, %39) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %44 = "vector.extract"(%26) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %45 = "vector.extract"(%20) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %46 = "func.call"(%44, %45) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %47 = "vector.insert"(%46, %43) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %48 = "vector.extract"(%26) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %49 = "vector.extract"(%20) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %50 = "func.call"(%48, %49) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %51 = "vector.insert"(%50, %47) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %52 = "vector.extract"(%26) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %53 = "vector.extract"(%20) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %54 = "func.call"(%52, %53) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %55 = "vector.insert"(%54, %51) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %56 = "vector.extract"(%26) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %57 = "vector.extract"(%20) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %58 = "func.call"(%56, %57) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %59 = "vector.insert"(%58, %55) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %60 = "arith.constant"() <{value = 16 : index}> : () -> index
              %61 = "arith.subi"(%arg24, %60) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %62 = "arith.constant"() <{value = 64 : index}> : () -> index
              %63 = "arith.subi"(%arg25, %62) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "vector.transfer_write"(%59, %9, %61, %63) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x16xf32, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %15 = "air.dma_memcpy_nd"(%5, %arg22, %6) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 62 : i64, orbit.source_copies = array<i64: 208>, orbit.storage = "Y", orbit.target_copies = array<i64: 209>, orbit.transfer = "l1_to_host", orbit.transfer_event = 179 : i64, static_dst_offsets = array<i64: 16, 64>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %16 = "air.wait_all"(%15) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%16) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_62"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%2) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_62"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_62"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "func.return"() : () -> ()
  }) : () -> ()
}) {orbit.async_herd_scope = "module", orbit.channel_conversion_scope = "module", orbit.cost_status = "uncalibrated-direct-air", orbit.data_organization = "phase-local", orbit.data_organization_scope = "phase-local input copies; source output/reduction lifetime preserved", orbit.f32_lane_legalization = "scalar-product-vector-add-f32; scalar compiler-rt mul/div; source-ordered vector add/sub; no FMA/BF16", orbit.local_release_scope = "static-hardware-stage", orbit.mapping_plan = "b2fac988bd30bacd29b0bb139ebc7aec8ffeda478b40e1fcb3637512c890e51d", orbit.source_fingerprint = "912511a293a64cce8e0d6c281bea7fa9b2ada1f653348173aee833f4c600a053"} : () -> ()

