#map = affine_map<(d0, d1) -> (d1)>
"builtin.module"() ({
  "func.func"() <{function_type = (f32, f32) -> f32, sym_name = "__mulsf3", sym_visibility = "private"}> ({
  }) {llvm.readnone, orbit.scalar_f32_builtin = "compiler-rt; same target scalar f32 operation; no vector approximation", passthrough = ["noinline", "nounwind"]} : () -> ()
  "func.func"() <{function_type = (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> (), sym_name = "gemm_scale"}> ({
  ^bb0(%arg0: memref<17x129xf32>, %arg1: memref<129x80xf32>, %arg2: memref<17x80xf32>, %arg3: memref<17x80xf32>):
    %0 = "arith.constant"() <{value = 1 : index}> : () -> index
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg382: index, %arg383: index, %arg384: index, %arg385: index, %arg386: memref<17x129xf32>, %arg387: memref<129x80xf32>, %arg388: memref<17x80xf32>, %arg389: memref<17x80xf32>):
      "air.segment"(%arg386, %arg387, %arg388, %arg389) ({
      ^bb0(%arg390: memref<17x129xf32>, %arg391: memref<129x80xf32>, %arg392: memref<17x80xf32>, %arg393: memref<17x80xf32>):
        %1700 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1701 = "air.herd"(%1700, %1700, %arg390, %arg391, %arg392, %arg393) ({
        ^bb0(%arg394: index, %arg395: index, %arg396: index, %arg397: index, %arg398: memref<17x129xf32>, %arg399: memref<129x80xf32>, %arg400: memref<17x80xf32>, %arg401: memref<17x80xf32>):
          %1702 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.32.1"} : () -> memref<8xf32, 2 : i32>
          %1703 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.32.32"} : () -> memref<256xf32, 2 : i32>
          %1704 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.8.32.1"} : () -> memref<32xf32, 2 : i32>
          %1705 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.8.32.32"} : () -> memref<1024xf32, 2 : i32>
          %1706 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<256xf32, 2 : i32>
          %1707 = "air.wait_all"() : () -> !air.async.token
          %1708 = "memref.reinterpret_cast"(%1706) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 9 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
          %1709 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1710 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1711 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1712 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1710, %1711, %1712) ({
          ^bb0(%arg410: index):
            %1838 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1839 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1840 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1838, %1839, %1840) ({
            ^bb0(%arg411: index):
              "memref.store"(%1709, %1708, %arg410, %arg411) <{nontemporal = false}> : (f32, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1713 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1714 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1715 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1716 = "scf.for"(%1713, %1714, %1715, %1707) ({
          ^bb0(%arg405: index, %arg406: !air.async.token):
            %1774 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1775 = "arith.muli"(%arg405, %1774) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1776 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1777 = "arith.muli"(%arg405, %1776) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1778 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1779 = "arith.muli"(%arg405, %1778) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1780 = "memref.reinterpret_cast"(%1703) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 9 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1781 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1782 = "arith.addi"(%1781, %1777) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1783 = "air.dma_memcpy_nd"(%arg406, %1780, %arg398, %1782) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 9 : i64, orbit.source_copies = array<i64: 0>, orbit.storage = "A", orbit.target_copies = array<i64: 30>, orbit.transfer = "host_to_l1", orbit.transfer_event = 0 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 0, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1784 = "memref.reinterpret_cast"(%1705) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 9 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %1785 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1786 = "arith.addi"(%1785, %1779) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1787 = "air.dma_memcpy_nd"(%arg406, %1784, %arg399, %1786) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 9 : i64, orbit.source_copies = array<i64: 15>, orbit.storage = "B", orbit.target_copies = array<i64: 31>, orbit.transfer = "host_to_l1", orbit.transfer_event = 1 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 0>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1783, %1787) {orbit.computation_event = 3 : i64, orbit.phase = 9 : i64, orbit.phase_dependencies = array<i64: 8>, orbit.read_copies = array<i64: 30, 31, 32>, orbit.task = "gemm", orbit.write_copies = array<i64: 33>} : (!air.async.token, !air.async.token) -> ()
            %1788 = "memref.cast"(%1780) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1789 = "memref.cast"(%1784) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %1790 = "memref.cast"(%1708) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1791 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1792 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1793 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1794 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1792, %1793, %1794) ({
            ^bb0(%arg407: index):
              %1796 = "arith.constant"() <{value = 0 : index}> : () -> index
              %1797 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1798 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1796, %1797, %1798) ({
              ^bb0(%arg408: index):
                %1799 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1800 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1801 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1799, %1800, %1801) ({
                ^bb0(%arg409: index):
                  %1802 = "arith.addi"(%arg409, %1775) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1803 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1804 = "arith.subi"(%1802, %1777) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1805 = "memref.load"(%1788, %arg407, %1804) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1806 = "vector.broadcast"(%1805) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1807 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1808 = "arith.subi"(%1802, %1779) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1809 = "vector.transfer_read"(%1789, %1808, %arg408, %1807) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1810 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1811 = "vector.transfer_read"(%1790, %arg407, %arg408, %1810) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1812 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1813 = "vector.extract"(%1809) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1814 = "func.call"(%1805, %1813) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1815 = "vector.insert"(%1814, %1812) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1816 = "vector.extract"(%1809) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1817 = "func.call"(%1805, %1816) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1818 = "vector.insert"(%1817, %1815) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1819 = "vector.extract"(%1809) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1820 = "func.call"(%1805, %1819) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1821 = "vector.insert"(%1820, %1818) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1822 = "vector.extract"(%1809) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1823 = "func.call"(%1805, %1822) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1824 = "vector.insert"(%1823, %1821) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1825 = "vector.extract"(%1809) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1826 = "func.call"(%1805, %1825) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1827 = "vector.insert"(%1826, %1824) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1828 = "vector.extract"(%1809) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1829 = "func.call"(%1805, %1828) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1830 = "vector.insert"(%1829, %1827) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1831 = "vector.extract"(%1809) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1832 = "func.call"(%1805, %1831) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1833 = "vector.insert"(%1832, %1830) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1834 = "vector.extract"(%1809) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1835 = "func.call"(%1805, %1834) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1836 = "vector.insert"(%1835, %1833) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1837 = "arith.addf"(%1811, %1836) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  "vector.transfer_write"(%1837, %1790, %arg407, %arg408) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1795 = "air.wait_all"(%arg406) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1795) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1717 = "memref.reinterpret_cast"(%1702) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 13 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1718 = "air.dma_memcpy_nd"(%1716, %1717, %arg398) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 13 : i64, orbit.source_copies = array<i64: 4>, orbit.storage = "A", orbit.target_copies = array<i64: 43>, orbit.transfer = "host_to_l1", orbit.transfer_event = 13 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 0, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1719 = "memref.reinterpret_cast"(%1704) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 13 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %1720 = "air.dma_memcpy_nd"(%1716, %1719, %arg399) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 13 : i64, orbit.source_copies = array<i64: 27>, orbit.storage = "B", orbit.target_copies = array<i64: 44>, orbit.transfer = "host_to_l1", orbit.transfer_event = 14 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1718, %1720) {orbit.computation_event = 15 : i64, orbit.phase = 13 : i64, orbit.phase_dependencies = array<i64: 12>, orbit.read_copies = array<i64: 43, 44, 42>, orbit.task = "gemm", orbit.write_copies = array<i64: 45>} : (!air.async.token, !air.async.token) -> ()
          %1721 = "memref.cast"(%1717) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1722 = "memref.cast"(%1719) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %1723 = "memref.cast"(%1708) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
          %1724 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1725 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1726 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1727 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1725, %1726, %1727) ({
          ^bb0(%arg402: index):
            %1731 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1732 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1733 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1731, %1732, %1733) ({
            ^bb0(%arg403: index):
              %1734 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1735 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1736 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1734, %1735, %1736) ({
              ^bb0(%arg404: index):
                %1737 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1738 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1739 = "arith.subi"(%arg404, %1738) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1740 = "memref.load"(%1721, %arg402, %1739) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1741 = "vector.broadcast"(%1740) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1742 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1743 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1744 = "arith.subi"(%arg404, %1743) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1745 = "vector.transfer_read"(%1722, %1744, %arg403, %1742) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1746 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1747 = "vector.transfer_read"(%1723, %arg402, %arg403, %1746) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1748 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1749 = "vector.extract"(%1745) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1750 = "func.call"(%1740, %1749) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1751 = "vector.insert"(%1750, %1748) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1752 = "vector.extract"(%1745) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1753 = "func.call"(%1740, %1752) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1754 = "vector.insert"(%1753, %1751) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1755 = "vector.extract"(%1745) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1756 = "func.call"(%1740, %1755) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1757 = "vector.insert"(%1756, %1754) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1758 = "vector.extract"(%1745) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1759 = "func.call"(%1740, %1758) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1760 = "vector.insert"(%1759, %1757) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1761 = "vector.extract"(%1745) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1762 = "func.call"(%1740, %1761) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1763 = "vector.insert"(%1762, %1760) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1764 = "vector.extract"(%1745) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1765 = "func.call"(%1740, %1764) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1766 = "vector.insert"(%1765, %1763) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1767 = "vector.extract"(%1745) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1768 = "func.call"(%1740, %1767) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1769 = "vector.insert"(%1768, %1766) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1770 = "vector.extract"(%1745) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1771 = "func.call"(%1740, %1770) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1772 = "vector.insert"(%1771, %1769) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1773 = "arith.addf"(%1747, %1772) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                "vector.transfer_write"(%1773, %1723, %arg402, %arg403) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1728 = "air.wait_all"(%1716) : (!air.async.token) -> !air.async.token
          %1729 = "air.dma_memcpy_nd"(%1728, %arg401, %1708) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 13 : i64, orbit.retained_begin = 9 : i64, orbit.retained_end = 14 : i64, orbit.source_copies = array<i64: 45>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 46>, orbit.transfer = "l1_to_host", orbit.transfer_event = 16 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %1730 = "air.wait_all"(%1729) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1730) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1701) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg352: index, %arg353: index, %arg354: index, %arg355: index, %arg356: memref<17x129xf32>, %arg357: memref<129x80xf32>, %arg358: memref<17x80xf32>, %arg359: memref<17x80xf32>):
      "air.segment"(%arg356, %arg357, %arg358, %arg359) ({
      ^bb0(%arg360: memref<17x129xf32>, %arg361: memref<129x80xf32>, %arg362: memref<17x80xf32>, %arg363: memref<17x80xf32>):
        %1545 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1546 = "air.herd"(%1545, %1545, %arg360, %arg361, %arg362, %arg363) ({
        ^bb0(%arg364: index, %arg365: index, %arg366: index, %arg367: index, %arg368: memref<17x129xf32>, %arg369: memref<129x80xf32>, %arg370: memref<17x80xf32>, %arg371: memref<17x80xf32>):
          %1547 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.32.1"} : () -> memref<8xf32, 2 : i32>
          %1548 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.32.32"} : () -> memref<256xf32, 2 : i32>
          %1549 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.8.32.1"} : () -> memref<32xf32, 2 : i32>
          %1550 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.8.32.32"} : () -> memref<1024xf32, 2 : i32>
          %1551 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<256xf32, 2 : i32>
          %1552 = "air.wait_all"() : () -> !air.async.token
          %1553 = "memref.reinterpret_cast"(%1551) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 14 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
          %1554 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1555 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1556 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1557 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1555, %1556, %1557) ({
          ^bb0(%arg380: index):
            %1695 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1696 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1697 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1695, %1696, %1697) ({
            ^bb0(%arg381: index):
              %1698 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1699 = "arith.subi"(%arg381, %1698) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%1554, %1553, %arg380, %1699) <{nontemporal = false}> : (f32, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1558 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1559 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1560 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1561 = "scf.for"(%1558, %1559, %1560, %1552) ({
          ^bb0(%arg375: index, %arg376: !air.async.token):
            %1625 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1626 = "arith.muli"(%arg375, %1625) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1627 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1628 = "arith.muli"(%arg375, %1627) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1629 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1630 = "arith.muli"(%arg375, %1629) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1631 = "memref.reinterpret_cast"(%1548) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 14 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1632 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1633 = "arith.addi"(%1632, %1628) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1634 = "air.dma_memcpy_nd"(%arg376, %1631, %arg368, %1633) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 14 : i64, orbit.source_copies = array<i64: 0>, orbit.storage = "A", orbit.target_copies = array<i64: 47>, orbit.transfer = "host_to_l1", orbit.transfer_event = 17 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 0, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1635 = "memref.reinterpret_cast"(%1550) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 14 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %1636 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1637 = "arith.addi"(%1636, %1630) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1638 = "air.dma_memcpy_nd"(%arg376, %1635, %arg369, %1637) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 14 : i64, orbit.source_copies = array<i64: 16>, orbit.storage = "B", orbit.target_copies = array<i64: 48>, orbit.transfer = "host_to_l1", orbit.transfer_event = 18 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 32>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1634, %1638) {orbit.computation_event = 20 : i64, orbit.phase = 14 : i64, orbit.phase_dependencies = array<i64: 13>, orbit.read_copies = array<i64: 47, 48, 49>, orbit.task = "gemm", orbit.write_copies = array<i64: 50>} : (!air.async.token, !air.async.token) -> ()
            %1639 = "memref.cast"(%1631) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1640 = "memref.cast"(%1635) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %1641 = "memref.cast"(%1553) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1642 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1643 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1644 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1645 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1643, %1644, %1645) ({
            ^bb0(%arg377: index):
              %1647 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1648 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1649 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1647, %1648, %1649) ({
              ^bb0(%arg378: index):
                %1650 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1651 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1652 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1650, %1651, %1652) ({
                ^bb0(%arg379: index):
                  %1653 = "arith.addi"(%arg379, %1626) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1654 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1655 = "arith.subi"(%1653, %1628) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1656 = "memref.load"(%1639, %arg377, %1655) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1657 = "vector.broadcast"(%1656) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1658 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1659 = "arith.subi"(%1653, %1630) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1660 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1661 = "arith.subi"(%arg378, %1660) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1662 = "vector.transfer_read"(%1640, %1659, %1661, %1658) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1663 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1664 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1665 = "arith.subi"(%arg378, %1664) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1666 = "vector.transfer_read"(%1641, %arg377, %1665, %1663) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1667 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1668 = "vector.extract"(%1662) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1669 = "func.call"(%1656, %1668) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1670 = "vector.insert"(%1669, %1667) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1671 = "vector.extract"(%1662) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1672 = "func.call"(%1656, %1671) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1673 = "vector.insert"(%1672, %1670) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1674 = "vector.extract"(%1662) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1675 = "func.call"(%1656, %1674) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1676 = "vector.insert"(%1675, %1673) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1677 = "vector.extract"(%1662) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1678 = "func.call"(%1656, %1677) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1679 = "vector.insert"(%1678, %1676) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1680 = "vector.extract"(%1662) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1681 = "func.call"(%1656, %1680) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1682 = "vector.insert"(%1681, %1679) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1683 = "vector.extract"(%1662) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1684 = "func.call"(%1656, %1683) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1685 = "vector.insert"(%1684, %1682) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1686 = "vector.extract"(%1662) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1687 = "func.call"(%1656, %1686) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1688 = "vector.insert"(%1687, %1685) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1689 = "vector.extract"(%1662) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1690 = "func.call"(%1656, %1689) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1691 = "vector.insert"(%1690, %1688) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1692 = "arith.addf"(%1666, %1691) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1693 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1694 = "arith.subi"(%arg378, %1693) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1692, %1641, %arg377, %1694) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1646 = "air.wait_all"(%arg376) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1646) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1562 = "memref.reinterpret_cast"(%1547) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 18 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1563 = "air.dma_memcpy_nd"(%1561, %1562, %arg368) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 18 : i64, orbit.source_copies = array<i64: 4>, orbit.storage = "A", orbit.target_copies = array<i64: 60>, orbit.transfer = "host_to_l1", orbit.transfer_event = 30 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 0, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1564 = "memref.reinterpret_cast"(%1549) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 18 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %1565 = "air.dma_memcpy_nd"(%1561, %1564, %arg369) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 18 : i64, orbit.source_copies = array<i64: 28>, orbit.storage = "B", orbit.target_copies = array<i64: 61>, orbit.transfer = "host_to_l1", orbit.transfer_event = 31 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 32>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1563, %1565) {orbit.computation_event = 32 : i64, orbit.phase = 18 : i64, orbit.phase_dependencies = array<i64: 17>, orbit.read_copies = array<i64: 60, 61, 59>, orbit.task = "gemm", orbit.write_copies = array<i64: 62>} : (!air.async.token, !air.async.token) -> ()
          %1566 = "memref.cast"(%1562) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1567 = "memref.cast"(%1564) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %1568 = "memref.cast"(%1553) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
          %1569 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1570 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1571 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1572 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1570, %1571, %1572) ({
          ^bb0(%arg372: index):
            %1576 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1577 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1578 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1576, %1577, %1578) ({
            ^bb0(%arg373: index):
              %1579 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1580 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1581 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1579, %1580, %1581) ({
              ^bb0(%arg374: index):
                %1582 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1583 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1584 = "arith.subi"(%arg374, %1583) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1585 = "memref.load"(%1566, %arg372, %1584) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1586 = "vector.broadcast"(%1585) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1587 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1588 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1589 = "arith.subi"(%arg374, %1588) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1590 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1591 = "arith.subi"(%arg373, %1590) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1592 = "vector.transfer_read"(%1567, %1589, %1591, %1587) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1593 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1594 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1595 = "arith.subi"(%arg373, %1594) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1596 = "vector.transfer_read"(%1568, %arg372, %1595, %1593) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1597 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1598 = "vector.extract"(%1592) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1599 = "func.call"(%1585, %1598) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1600 = "vector.insert"(%1599, %1597) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1601 = "vector.extract"(%1592) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1602 = "func.call"(%1585, %1601) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1603 = "vector.insert"(%1602, %1600) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1604 = "vector.extract"(%1592) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1605 = "func.call"(%1585, %1604) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1606 = "vector.insert"(%1605, %1603) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1607 = "vector.extract"(%1592) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1608 = "func.call"(%1585, %1607) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1609 = "vector.insert"(%1608, %1606) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1610 = "vector.extract"(%1592) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1611 = "func.call"(%1585, %1610) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1612 = "vector.insert"(%1611, %1609) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1613 = "vector.extract"(%1592) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1614 = "func.call"(%1585, %1613) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1615 = "vector.insert"(%1614, %1612) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1616 = "vector.extract"(%1592) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1617 = "func.call"(%1585, %1616) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1618 = "vector.insert"(%1617, %1615) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1619 = "vector.extract"(%1592) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1620 = "func.call"(%1585, %1619) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1621 = "vector.insert"(%1620, %1618) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1622 = "arith.addf"(%1596, %1621) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %1623 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1624 = "arith.subi"(%arg373, %1623) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%1622, %1568, %arg372, %1624) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1573 = "air.wait_all"(%1561) : (!air.async.token) -> !air.async.token
          %1574 = "air.dma_memcpy_nd"(%1573, %arg371, %1553) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 18 : i64, orbit.retained_begin = 14 : i64, orbit.retained_end = 19 : i64, orbit.source_copies = array<i64: 62>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 63>, orbit.transfer = "l1_to_host", orbit.transfer_event = 33 : i64, static_dst_offsets = array<i64: 0, 32>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %1575 = "air.wait_all"(%1574) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1575) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_14"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1546) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_14"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_14"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg322: index, %arg323: index, %arg324: index, %arg325: index, %arg326: memref<17x129xf32>, %arg327: memref<129x80xf32>, %arg328: memref<17x80xf32>, %arg329: memref<17x80xf32>):
      "air.segment"(%arg326, %arg327, %arg328, %arg329) ({
      ^bb0(%arg330: memref<17x129xf32>, %arg331: memref<129x80xf32>, %arg332: memref<17x80xf32>, %arg333: memref<17x80xf32>):
        %1390 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1391 = "air.herd"(%1390, %1390, %arg330, %arg331, %arg332, %arg333) ({
        ^bb0(%arg334: index, %arg335: index, %arg336: index, %arg337: index, %arg338: memref<17x129xf32>, %arg339: memref<129x80xf32>, %arg340: memref<17x80xf32>, %arg341: memref<17x80xf32>):
          %1392 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.16.1"} : () -> memref<8xf32, 2 : i32>
          %1393 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.16.32"} : () -> memref<256xf32, 2 : i32>
          %1394 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.16.loops.8.16.1"} : () -> memref<16xf32, 2 : i32>
          %1395 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.16.loops.8.16.32"} : () -> memref<512xf32, 2 : i32>
          %1396 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<128xf32, 2 : i32>
          %1397 = "air.wait_all"() : () -> !air.async.token
          %1398 = "memref.reinterpret_cast"(%1396) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 19 : i64, orbit.storage = "intermediate"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %1399 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1400 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1401 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1402 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1400, %1401, %1402) ({
          ^bb0(%arg350: index):
            %1540 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1541 = "arith.constant"() <{value = 80 : index}> : () -> index
            %1542 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1540, %1541, %1542) ({
            ^bb0(%arg351: index):
              %1543 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1544 = "arith.subi"(%arg351, %1543) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%1399, %1398, %arg350, %1544) <{nontemporal = false}> : (f32, memref<8x16xf32, strided<[16, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1403 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1404 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1405 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1406 = "scf.for"(%1403, %1404, %1405, %1397) ({
          ^bb0(%arg345: index, %arg346: !air.async.token):
            %1470 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1471 = "arith.muli"(%arg345, %1470) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1472 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1473 = "arith.muli"(%arg345, %1472) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1474 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1475 = "arith.muli"(%arg345, %1474) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1476 = "memref.reinterpret_cast"(%1393) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 19 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1477 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1478 = "arith.addi"(%1477, %1473) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1479 = "air.dma_memcpy_nd"(%arg346, %1476, %arg338, %1478) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 19 : i64, orbit.source_copies = array<i64: 0>, orbit.storage = "A", orbit.target_copies = array<i64: 64>, orbit.transfer = "host_to_l1", orbit.transfer_event = 34 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 0, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1480 = "memref.reinterpret_cast"(%1395) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 19 : i64, orbit.storage = "B"} : (memref<512xf32, 2 : i32>) -> memref<32x16xf32, strided<[16, 1]>, 2 : i32>
            %1481 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1482 = "arith.addi"(%1481, %1475) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1483 = "air.dma_memcpy_nd"(%arg346, %1480, %arg339, %1482) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 19 : i64, orbit.source_copies = array<i64: 17>, orbit.storage = "B", orbit.target_copies = array<i64: 65>, orbit.transfer = "host_to_l1", orbit.transfer_event = 35 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: -9223372036854775808, 64>, static_src_sizes = array<i64: 32, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1479, %1483) {orbit.computation_event = 37 : i64, orbit.phase = 19 : i64, orbit.phase_dependencies = array<i64: 18>, orbit.read_copies = array<i64: 64, 65, 66>, orbit.task = "gemm", orbit.write_copies = array<i64: 67>} : (!air.async.token, !air.async.token) -> ()
            %1484 = "memref.cast"(%1476) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1485 = "memref.cast"(%1480) : (memref<32x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<32x16xf32, 2 : i32>
            %1486 = "memref.cast"(%1398) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
            %1487 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1488 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1489 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1490 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1488, %1489, %1490) ({
            ^bb0(%arg347: index):
              %1492 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1493 = "arith.constant"() <{value = 80 : index}> : () -> index
              %1494 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1492, %1493, %1494) ({
              ^bb0(%arg348: index):
                %1495 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1496 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1497 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1495, %1496, %1497) ({
                ^bb0(%arg349: index):
                  %1498 = "arith.addi"(%arg349, %1471) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1499 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1500 = "arith.subi"(%1498, %1473) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1501 = "memref.load"(%1484, %arg347, %1500) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1502 = "vector.broadcast"(%1501) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1503 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1504 = "arith.subi"(%1498, %1475) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1505 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1506 = "arith.subi"(%arg348, %1505) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1507 = "vector.transfer_read"(%1485, %1504, %1506, %1503) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1508 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1509 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1510 = "arith.subi"(%arg348, %1509) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1511 = "vector.transfer_read"(%1486, %arg347, %1510, %1508) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1512 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1513 = "vector.extract"(%1507) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1514 = "func.call"(%1501, %1513) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1515 = "vector.insert"(%1514, %1512) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1516 = "vector.extract"(%1507) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1517 = "func.call"(%1501, %1516) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1518 = "vector.insert"(%1517, %1515) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1519 = "vector.extract"(%1507) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1520 = "func.call"(%1501, %1519) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1521 = "vector.insert"(%1520, %1518) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1522 = "vector.extract"(%1507) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1523 = "func.call"(%1501, %1522) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1524 = "vector.insert"(%1523, %1521) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1525 = "vector.extract"(%1507) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1526 = "func.call"(%1501, %1525) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1527 = "vector.insert"(%1526, %1524) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1528 = "vector.extract"(%1507) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1529 = "func.call"(%1501, %1528) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1530 = "vector.insert"(%1529, %1527) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1531 = "vector.extract"(%1507) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1532 = "func.call"(%1501, %1531) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1533 = "vector.insert"(%1532, %1530) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1534 = "vector.extract"(%1507) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1535 = "func.call"(%1501, %1534) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1536 = "vector.insert"(%1535, %1533) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1537 = "arith.addf"(%1511, %1536) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1538 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1539 = "arith.subi"(%arg348, %1538) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1537, %1486, %arg347, %1539) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1491 = "air.wait_all"(%arg346) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1491) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1407 = "memref.reinterpret_cast"(%1392) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 23 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1408 = "air.dma_memcpy_nd"(%1406, %1407, %arg338) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 23 : i64, orbit.source_copies = array<i64: 4>, orbit.storage = "A", orbit.target_copies = array<i64: 77>, orbit.transfer = "host_to_l1", orbit.transfer_event = 47 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 0, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1409 = "memref.reinterpret_cast"(%1394) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 23 : i64, orbit.storage = "B"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %1410 = "air.dma_memcpy_nd"(%1406, %1409, %arg339) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 23 : i64, orbit.source_copies = array<i64: 29>, orbit.storage = "B", orbit.target_copies = array<i64: 78>, orbit.transfer = "host_to_l1", orbit.transfer_event = 48 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 128, 64>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1408, %1410) {orbit.computation_event = 49 : i64, orbit.phase = 23 : i64, orbit.phase_dependencies = array<i64: 22>, orbit.read_copies = array<i64: 77, 78, 76>, orbit.task = "gemm", orbit.write_copies = array<i64: 79>} : (!air.async.token, !air.async.token) -> ()
          %1411 = "memref.cast"(%1407) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1412 = "memref.cast"(%1409) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %1413 = "memref.cast"(%1398) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %1414 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1415 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1416 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1417 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1415, %1416, %1417) ({
          ^bb0(%arg342: index):
            %1421 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1422 = "arith.constant"() <{value = 80 : index}> : () -> index
            %1423 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1421, %1422, %1423) ({
            ^bb0(%arg343: index):
              %1424 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1425 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1426 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1424, %1425, %1426) ({
              ^bb0(%arg344: index):
                %1427 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1428 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1429 = "arith.subi"(%arg344, %1428) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1430 = "memref.load"(%1411, %arg342, %1429) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1431 = "vector.broadcast"(%1430) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1432 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1433 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1434 = "arith.subi"(%arg344, %1433) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1435 = "arith.constant"() <{value = 64 : index}> : () -> index
                %1436 = "arith.subi"(%arg343, %1435) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1437 = "vector.transfer_read"(%1412, %1434, %1436, %1432) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1438 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1439 = "arith.constant"() <{value = 64 : index}> : () -> index
                %1440 = "arith.subi"(%arg343, %1439) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1441 = "vector.transfer_read"(%1413, %arg342, %1440, %1438) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1442 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1443 = "vector.extract"(%1437) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1444 = "func.call"(%1430, %1443) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1445 = "vector.insert"(%1444, %1442) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1446 = "vector.extract"(%1437) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1447 = "func.call"(%1430, %1446) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1448 = "vector.insert"(%1447, %1445) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1449 = "vector.extract"(%1437) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1450 = "func.call"(%1430, %1449) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1451 = "vector.insert"(%1450, %1448) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1452 = "vector.extract"(%1437) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1453 = "func.call"(%1430, %1452) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1454 = "vector.insert"(%1453, %1451) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1455 = "vector.extract"(%1437) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1456 = "func.call"(%1430, %1455) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1457 = "vector.insert"(%1456, %1454) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1458 = "vector.extract"(%1437) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1459 = "func.call"(%1430, %1458) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1460 = "vector.insert"(%1459, %1457) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1461 = "vector.extract"(%1437) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1462 = "func.call"(%1430, %1461) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1463 = "vector.insert"(%1462, %1460) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1464 = "vector.extract"(%1437) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1465 = "func.call"(%1430, %1464) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1466 = "vector.insert"(%1465, %1463) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1467 = "arith.addf"(%1441, %1466) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %1468 = "arith.constant"() <{value = 64 : index}> : () -> index
                %1469 = "arith.subi"(%arg343, %1468) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%1467, %1413, %arg342, %1469) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1418 = "air.wait_all"(%1406) : (!air.async.token) -> !air.async.token
          %1419 = "air.dma_memcpy_nd"(%1418, %arg341, %1398) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 23 : i64, orbit.retained_begin = 19 : i64, orbit.retained_end = 24 : i64, orbit.source_copies = array<i64: 79>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 80>, orbit.transfer = "l1_to_host", orbit.transfer_event = 50 : i64, static_dst_offsets = array<i64: 0, 64>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %1420 = "air.wait_all"(%1419) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1420) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_19"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1391) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_19"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_19"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg292: index, %arg293: index, %arg294: index, %arg295: index, %arg296: memref<17x129xf32>, %arg297: memref<129x80xf32>, %arg298: memref<17x80xf32>, %arg299: memref<17x80xf32>):
      "air.segment"(%arg296, %arg297, %arg298, %arg299) ({
      ^bb0(%arg300: memref<17x129xf32>, %arg301: memref<129x80xf32>, %arg302: memref<17x80xf32>, %arg303: memref<17x80xf32>):
        %1235 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1236 = "air.herd"(%1235, %1235, %arg300, %arg301, %arg302, %arg303) ({
        ^bb0(%arg304: index, %arg305: index, %arg306: index, %arg307: index, %arg308: memref<17x129xf32>, %arg309: memref<129x80xf32>, %arg310: memref<17x80xf32>, %arg311: memref<17x80xf32>):
          %1237 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.32.1"} : () -> memref<8xf32, 2 : i32>
          %1238 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.32.32"} : () -> memref<256xf32, 2 : i32>
          %1239 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.8.32.1"} : () -> memref<32xf32, 2 : i32>
          %1240 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.8.32.32"} : () -> memref<1024xf32, 2 : i32>
          %1241 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<256xf32, 2 : i32>
          %1242 = "air.wait_all"() : () -> !air.async.token
          %1243 = "memref.reinterpret_cast"(%1241) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 24 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
          %1244 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1245 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1246 = "arith.constant"() <{value = 16 : index}> : () -> index
          %1247 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1245, %1246, %1247) ({
          ^bb0(%arg320: index):
            %1385 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1386 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1387 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1385, %1386, %1387) ({
            ^bb0(%arg321: index):
              %1388 = "arith.constant"() <{value = 8 : index}> : () -> index
              %1389 = "arith.subi"(%arg320, %1388) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%1244, %1243, %1389, %arg321) <{nontemporal = false}> : (f32, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1248 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1249 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1250 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1251 = "scf.for"(%1248, %1249, %1250, %1242) ({
          ^bb0(%arg315: index, %arg316: !air.async.token):
            %1315 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1316 = "arith.muli"(%arg315, %1315) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1317 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1318 = "arith.muli"(%arg315, %1317) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1319 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1320 = "arith.muli"(%arg315, %1319) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1321 = "memref.reinterpret_cast"(%1238) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 24 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1322 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1323 = "arith.addi"(%1322, %1318) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1324 = "air.dma_memcpy_nd"(%arg316, %1321, %arg308, %1323) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 24 : i64, orbit.source_copies = array<i64: 5>, orbit.storage = "A", orbit.target_copies = array<i64: 81>, orbit.transfer = "host_to_l1", orbit.transfer_event = 51 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 8, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1325 = "memref.reinterpret_cast"(%1240) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 24 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %1326 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1327 = "arith.addi"(%1326, %1320) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1328 = "air.dma_memcpy_nd"(%arg316, %1325, %arg309, %1327) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 24 : i64, orbit.source_copies = array<i64: 15>, orbit.storage = "B", orbit.target_copies = array<i64: 82>, orbit.transfer = "host_to_l1", orbit.transfer_event = 52 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 0>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1324, %1328) {orbit.computation_event = 54 : i64, orbit.phase = 24 : i64, orbit.phase_dependencies = array<i64: 23>, orbit.read_copies = array<i64: 81, 82, 83>, orbit.task = "gemm", orbit.write_copies = array<i64: 84>} : (!air.async.token, !air.async.token) -> ()
            %1329 = "memref.cast"(%1321) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1330 = "memref.cast"(%1325) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %1331 = "memref.cast"(%1243) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1332 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1333 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1334 = "arith.constant"() <{value = 16 : index}> : () -> index
            %1335 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1333, %1334, %1335) ({
            ^bb0(%arg317: index):
              %1337 = "arith.constant"() <{value = 0 : index}> : () -> index
              %1338 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1339 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1337, %1338, %1339) ({
              ^bb0(%arg318: index):
                %1340 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1341 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1342 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1340, %1341, %1342) ({
                ^bb0(%arg319: index):
                  %1343 = "arith.addi"(%arg319, %1316) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1344 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1345 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1346 = "arith.subi"(%arg317, %1345) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1347 = "arith.subi"(%1343, %1318) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1348 = "memref.load"(%1329, %1346, %1347) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1349 = "vector.broadcast"(%1348) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1350 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1351 = "arith.subi"(%1343, %1320) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1352 = "vector.transfer_read"(%1330, %1351, %arg318, %1350) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1353 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1354 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1355 = "arith.subi"(%arg317, %1354) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1356 = "vector.transfer_read"(%1331, %1355, %arg318, %1353) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1357 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1358 = "vector.extract"(%1352) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1359 = "func.call"(%1348, %1358) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1360 = "vector.insert"(%1359, %1357) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1361 = "vector.extract"(%1352) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1362 = "func.call"(%1348, %1361) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1363 = "vector.insert"(%1362, %1360) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1364 = "vector.extract"(%1352) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1365 = "func.call"(%1348, %1364) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1366 = "vector.insert"(%1365, %1363) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1367 = "vector.extract"(%1352) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1368 = "func.call"(%1348, %1367) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1369 = "vector.insert"(%1368, %1366) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1370 = "vector.extract"(%1352) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1371 = "func.call"(%1348, %1370) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1372 = "vector.insert"(%1371, %1369) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1373 = "vector.extract"(%1352) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1374 = "func.call"(%1348, %1373) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1375 = "vector.insert"(%1374, %1372) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1376 = "vector.extract"(%1352) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1377 = "func.call"(%1348, %1376) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1378 = "vector.insert"(%1377, %1375) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1379 = "vector.extract"(%1352) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1380 = "func.call"(%1348, %1379) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1381 = "vector.insert"(%1380, %1378) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1382 = "arith.addf"(%1356, %1381) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1383 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1384 = "arith.subi"(%arg317, %1383) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1382, %1331, %1384, %arg318) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1336 = "air.wait_all"(%arg316) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1336) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1252 = "memref.reinterpret_cast"(%1237) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 28 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1253 = "air.dma_memcpy_nd"(%1251, %1252, %arg308) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 28 : i64, orbit.source_copies = array<i64: 9>, orbit.storage = "A", orbit.target_copies = array<i64: 94>, orbit.transfer = "host_to_l1", orbit.transfer_event = 64 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 8, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1254 = "memref.reinterpret_cast"(%1239) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 28 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %1255 = "air.dma_memcpy_nd"(%1251, %1254, %arg309) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 28 : i64, orbit.source_copies = array<i64: 27>, orbit.storage = "B", orbit.target_copies = array<i64: 95>, orbit.transfer = "host_to_l1", orbit.transfer_event = 65 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1253, %1255) {orbit.computation_event = 66 : i64, orbit.phase = 28 : i64, orbit.phase_dependencies = array<i64: 27>, orbit.read_copies = array<i64: 94, 95, 93>, orbit.task = "gemm", orbit.write_copies = array<i64: 96>} : (!air.async.token, !air.async.token) -> ()
          %1256 = "memref.cast"(%1252) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1257 = "memref.cast"(%1254) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %1258 = "memref.cast"(%1243) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
          %1259 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1260 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1261 = "arith.constant"() <{value = 16 : index}> : () -> index
          %1262 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1260, %1261, %1262) ({
          ^bb0(%arg312: index):
            %1266 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1267 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1268 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1266, %1267, %1268) ({
            ^bb0(%arg313: index):
              %1269 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1270 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1271 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1269, %1270, %1271) ({
              ^bb0(%arg314: index):
                %1272 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1273 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1274 = "arith.subi"(%arg312, %1273) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1275 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1276 = "arith.subi"(%arg314, %1275) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1277 = "memref.load"(%1256, %1274, %1276) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1278 = "vector.broadcast"(%1277) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1279 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1280 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1281 = "arith.subi"(%arg314, %1280) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1282 = "vector.transfer_read"(%1257, %1281, %arg313, %1279) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1283 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1284 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1285 = "arith.subi"(%arg312, %1284) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1286 = "vector.transfer_read"(%1258, %1285, %arg313, %1283) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1287 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1288 = "vector.extract"(%1282) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1289 = "func.call"(%1277, %1288) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1290 = "vector.insert"(%1289, %1287) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1291 = "vector.extract"(%1282) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1292 = "func.call"(%1277, %1291) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1293 = "vector.insert"(%1292, %1290) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1294 = "vector.extract"(%1282) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1295 = "func.call"(%1277, %1294) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1296 = "vector.insert"(%1295, %1293) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1297 = "vector.extract"(%1282) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1298 = "func.call"(%1277, %1297) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1299 = "vector.insert"(%1298, %1296) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1300 = "vector.extract"(%1282) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1301 = "func.call"(%1277, %1300) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1302 = "vector.insert"(%1301, %1299) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1303 = "vector.extract"(%1282) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1304 = "func.call"(%1277, %1303) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1305 = "vector.insert"(%1304, %1302) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1306 = "vector.extract"(%1282) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1307 = "func.call"(%1277, %1306) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1308 = "vector.insert"(%1307, %1305) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1309 = "vector.extract"(%1282) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1310 = "func.call"(%1277, %1309) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1311 = "vector.insert"(%1310, %1308) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1312 = "arith.addf"(%1286, %1311) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %1313 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1314 = "arith.subi"(%arg312, %1313) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%1312, %1258, %1314, %arg313) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1263 = "air.wait_all"(%1251) : (!air.async.token) -> !air.async.token
          %1264 = "air.dma_memcpy_nd"(%1263, %arg311, %1243) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 28 : i64, orbit.retained_begin = 24 : i64, orbit.retained_end = 29 : i64, orbit.source_copies = array<i64: 96>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 97>, orbit.transfer = "l1_to_host", orbit.transfer_event = 67 : i64, static_dst_offsets = array<i64: 8, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %1265 = "air.wait_all"(%1264) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1265) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_24"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1236) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_24"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_24"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg262: index, %arg263: index, %arg264: index, %arg265: index, %arg266: memref<17x129xf32>, %arg267: memref<129x80xf32>, %arg268: memref<17x80xf32>, %arg269: memref<17x80xf32>):
      "air.segment"(%arg266, %arg267, %arg268, %arg269) ({
      ^bb0(%arg270: memref<17x129xf32>, %arg271: memref<129x80xf32>, %arg272: memref<17x80xf32>, %arg273: memref<17x80xf32>):
        %1066 = "arith.constant"() <{value = 1 : index}> : () -> index
        %1067 = "air.herd"(%1066, %1066, %arg270, %arg271, %arg272, %arg273) ({
        ^bb0(%arg274: index, %arg275: index, %arg276: index, %arg277: index, %arg278: memref<17x129xf32>, %arg279: memref<129x80xf32>, %arg280: memref<17x80xf32>, %arg281: memref<17x80xf32>):
          %1068 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.32.1"} : () -> memref<8xf32, 2 : i32>
          %1069 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.32.32"} : () -> memref<256xf32, 2 : i32>
          %1070 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.8.32.1"} : () -> memref<32xf32, 2 : i32>
          %1071 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.8.32.32"} : () -> memref<1024xf32, 2 : i32>
          %1072 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<256xf32, 2 : i32>
          %1073 = "air.wait_all"() : () -> !air.async.token
          %1074 = "memref.reinterpret_cast"(%1072) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 29 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
          %1075 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1076 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1077 = "arith.constant"() <{value = 16 : index}> : () -> index
          %1078 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1076, %1077, %1078) ({
          ^bb0(%arg290: index):
            %1228 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1229 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1230 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1228, %1229, %1230) ({
            ^bb0(%arg291: index):
              %1231 = "arith.constant"() <{value = 8 : index}> : () -> index
              %1232 = "arith.subi"(%arg290, %1231) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %1233 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1234 = "arith.subi"(%arg291, %1233) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%1075, %1074, %1232, %1234) <{nontemporal = false}> : (f32, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1079 = "arith.constant"() <{value = 0 : index}> : () -> index
          %1080 = "arith.constant"() <{value = 4 : index}> : () -> index
          %1081 = "arith.constant"() <{value = 1 : index}> : () -> index
          %1082 = "scf.for"(%1079, %1080, %1081, %1073) ({
          ^bb0(%arg285: index, %arg286: !air.async.token):
            %1152 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1153 = "arith.muli"(%arg285, %1152) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1154 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1155 = "arith.muli"(%arg285, %1154) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1156 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1157 = "arith.muli"(%arg285, %1156) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1158 = "memref.reinterpret_cast"(%1069) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 29 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %1159 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1160 = "arith.addi"(%1159, %1155) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1161 = "air.dma_memcpy_nd"(%arg286, %1158, %arg278, %1160) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 29 : i64, orbit.source_copies = array<i64: 5>, orbit.storage = "A", orbit.target_copies = array<i64: 98>, orbit.transfer = "host_to_l1", orbit.transfer_event = 68 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 8, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %1162 = "memref.reinterpret_cast"(%1071) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 29 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %1163 = "arith.constant"() <{value = 0 : index}> : () -> index
            %1164 = "arith.addi"(%1163, %1157) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %1165 = "air.dma_memcpy_nd"(%arg286, %1162, %arg279, %1164) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 29 : i64, orbit.source_copies = array<i64: 16>, orbit.storage = "B", orbit.target_copies = array<i64: 99>, orbit.transfer = "host_to_l1", orbit.transfer_event = 69 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 32>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%1161, %1165) {orbit.computation_event = 71 : i64, orbit.phase = 29 : i64, orbit.phase_dependencies = array<i64: 28>, orbit.read_copies = array<i64: 98, 99, 100>, orbit.task = "gemm", orbit.write_copies = array<i64: 101>} : (!air.async.token, !air.async.token) -> ()
            %1166 = "memref.cast"(%1158) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1167 = "memref.cast"(%1162) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %1168 = "memref.cast"(%1074) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %1169 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1170 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1171 = "arith.constant"() <{value = 16 : index}> : () -> index
            %1172 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1170, %1171, %1172) ({
            ^bb0(%arg287: index):
              %1174 = "arith.constant"() <{value = 32 : index}> : () -> index
              %1175 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1176 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1174, %1175, %1176) ({
              ^bb0(%arg288: index):
                %1177 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1178 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1179 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1177, %1178, %1179) ({
                ^bb0(%arg289: index):
                  %1180 = "arith.addi"(%arg289, %1153) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1181 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1182 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1183 = "arith.subi"(%arg287, %1182) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1184 = "arith.subi"(%1180, %1155) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1185 = "memref.load"(%1166, %1183, %1184) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1186 = "vector.broadcast"(%1185) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1187 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1188 = "arith.subi"(%1180, %1157) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1189 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1190 = "arith.subi"(%arg288, %1189) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1191 = "vector.transfer_read"(%1167, %1188, %1190, %1187) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1192 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1193 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1194 = "arith.subi"(%arg287, %1193) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1195 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1196 = "arith.subi"(%arg288, %1195) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1197 = "vector.transfer_read"(%1168, %1194, %1196, %1192) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1198 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1199 = "vector.extract"(%1191) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1200 = "func.call"(%1185, %1199) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1201 = "vector.insert"(%1200, %1198) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1202 = "vector.extract"(%1191) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1203 = "func.call"(%1185, %1202) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1204 = "vector.insert"(%1203, %1201) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1205 = "vector.extract"(%1191) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1206 = "func.call"(%1185, %1205) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1207 = "vector.insert"(%1206, %1204) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1208 = "vector.extract"(%1191) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1209 = "func.call"(%1185, %1208) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1210 = "vector.insert"(%1209, %1207) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1211 = "vector.extract"(%1191) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1212 = "func.call"(%1185, %1211) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1213 = "vector.insert"(%1212, %1210) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1214 = "vector.extract"(%1191) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1215 = "func.call"(%1185, %1214) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1216 = "vector.insert"(%1215, %1213) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1217 = "vector.extract"(%1191) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1218 = "func.call"(%1185, %1217) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1219 = "vector.insert"(%1218, %1216) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1220 = "vector.extract"(%1191) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1221 = "func.call"(%1185, %1220) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1222 = "vector.insert"(%1221, %1219) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1223 = "arith.addf"(%1197, %1222) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1224 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1225 = "arith.subi"(%arg287, %1224) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1226 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %1227 = "arith.subi"(%arg288, %1226) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1223, %1168, %1225, %1227) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1173 = "air.wait_all"(%arg286) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1173) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %1083 = "memref.reinterpret_cast"(%1068) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 33 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %1084 = "air.dma_memcpy_nd"(%1082, %1083, %arg278) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 33 : i64, orbit.source_copies = array<i64: 9>, orbit.storage = "A", orbit.target_copies = array<i64: 111>, orbit.transfer = "host_to_l1", orbit.transfer_event = 81 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 8, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %1085 = "memref.reinterpret_cast"(%1070) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 33 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %1086 = "air.dma_memcpy_nd"(%1082, %1085, %arg279) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 33 : i64, orbit.source_copies = array<i64: 28>, orbit.storage = "B", orbit.target_copies = array<i64: 112>, orbit.transfer = "host_to_l1", orbit.transfer_event = 82 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 32>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%1084, %1086) {orbit.computation_event = 83 : i64, orbit.phase = 33 : i64, orbit.phase_dependencies = array<i64: 32>, orbit.read_copies = array<i64: 111, 112, 110>, orbit.task = "gemm", orbit.write_copies = array<i64: 113>} : (!air.async.token, !air.async.token) -> ()
          %1087 = "memref.cast"(%1083) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %1088 = "memref.cast"(%1085) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %1089 = "memref.cast"(%1074) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
          %1090 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %1091 = "arith.constant"() <{value = 8 : index}> : () -> index
          %1092 = "arith.constant"() <{value = 16 : index}> : () -> index
          %1093 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%1091, %1092, %1093) ({
          ^bb0(%arg282: index):
            %1097 = "arith.constant"() <{value = 32 : index}> : () -> index
            %1098 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1099 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%1097, %1098, %1099) ({
            ^bb0(%arg283: index):
              %1100 = "arith.constant"() <{value = 128 : index}> : () -> index
              %1101 = "arith.constant"() <{value = 129 : index}> : () -> index
              %1102 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%1100, %1101, %1102) ({
              ^bb0(%arg284: index):
                %1103 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1104 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1105 = "arith.subi"(%arg282, %1104) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1106 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1107 = "arith.subi"(%arg284, %1106) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1108 = "memref.load"(%1087, %1105, %1107) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %1109 = "vector.broadcast"(%1108) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %1110 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1111 = "arith.constant"() <{value = 128 : index}> : () -> index
                %1112 = "arith.subi"(%arg284, %1111) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1113 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1114 = "arith.subi"(%arg283, %1113) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1115 = "vector.transfer_read"(%1088, %1112, %1114, %1110) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1116 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %1117 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1118 = "arith.subi"(%arg282, %1117) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1119 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1120 = "arith.subi"(%arg283, %1119) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1121 = "vector.transfer_read"(%1089, %1118, %1120, %1116) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %1122 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %1123 = "vector.extract"(%1115) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %1124 = "func.call"(%1108, %1123) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1125 = "vector.insert"(%1124, %1122) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1126 = "vector.extract"(%1115) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %1127 = "func.call"(%1108, %1126) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1128 = "vector.insert"(%1127, %1125) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1129 = "vector.extract"(%1115) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %1130 = "func.call"(%1108, %1129) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1131 = "vector.insert"(%1130, %1128) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1132 = "vector.extract"(%1115) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %1133 = "func.call"(%1108, %1132) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1134 = "vector.insert"(%1133, %1131) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1135 = "vector.extract"(%1115) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %1136 = "func.call"(%1108, %1135) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1137 = "vector.insert"(%1136, %1134) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1138 = "vector.extract"(%1115) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %1139 = "func.call"(%1108, %1138) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1140 = "vector.insert"(%1139, %1137) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1141 = "vector.extract"(%1115) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %1142 = "func.call"(%1108, %1141) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1143 = "vector.insert"(%1142, %1140) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1144 = "vector.extract"(%1115) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %1145 = "func.call"(%1108, %1144) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %1146 = "vector.insert"(%1145, %1143) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %1147 = "arith.addf"(%1121, %1146) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %1148 = "arith.constant"() <{value = 8 : index}> : () -> index
                %1149 = "arith.subi"(%arg282, %1148) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %1150 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1151 = "arith.subi"(%arg283, %1150) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%1147, %1089, %1149, %1151) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %1094 = "air.wait_all"(%1082) : (!air.async.token) -> !air.async.token
          %1095 = "air.dma_memcpy_nd"(%1094, %arg281, %1074) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 33 : i64, orbit.retained_begin = 29 : i64, orbit.retained_end = 34 : i64, orbit.source_copies = array<i64: 113>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 114>, orbit.transfer = "l1_to_host", orbit.transfer_event = 84 : i64, static_dst_offsets = array<i64: 8, 32>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %1096 = "air.wait_all"(%1095) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%1096) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_29"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%1067) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_29"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_29"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg232: index, %arg233: index, %arg234: index, %arg235: index, %arg236: memref<17x129xf32>, %arg237: memref<129x80xf32>, %arg238: memref<17x80xf32>, %arg239: memref<17x80xf32>):
      "air.segment"(%arg236, %arg237, %arg238, %arg239) ({
      ^bb0(%arg240: memref<17x129xf32>, %arg241: memref<129x80xf32>, %arg242: memref<17x80xf32>, %arg243: memref<17x80xf32>):
        %897 = "arith.constant"() <{value = 1 : index}> : () -> index
        %898 = "air.herd"(%897, %897, %arg240, %arg241, %arg242, %arg243) ({
        ^bb0(%arg244: index, %arg245: index, %arg246: index, %arg247: index, %arg248: memref<17x129xf32>, %arg249: memref<129x80xf32>, %arg250: memref<17x80xf32>, %arg251: memref<17x80xf32>):
          %899 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.1.loops.8.16.1"} : () -> memref<8xf32, 2 : i32>
          %900 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.8.32.loops.8.16.32"} : () -> memref<256xf32, 2 : i32>
          %901 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.16.loops.8.16.1"} : () -> memref<16xf32, 2 : i32>
          %902 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.16.loops.8.16.32"} : () -> memref<512xf32, 2 : i32>
          %903 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<128xf32, 2 : i32>
          %904 = "air.wait_all"() : () -> !air.async.token
          %905 = "memref.reinterpret_cast"(%903) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 34 : i64, orbit.storage = "intermediate"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %906 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %907 = "arith.constant"() <{value = 8 : index}> : () -> index
          %908 = "arith.constant"() <{value = 16 : index}> : () -> index
          %909 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%907, %908, %909) ({
          ^bb0(%arg260: index):
            %1059 = "arith.constant"() <{value = 64 : index}> : () -> index
            %1060 = "arith.constant"() <{value = 80 : index}> : () -> index
            %1061 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1059, %1060, %1061) ({
            ^bb0(%arg261: index):
              %1062 = "arith.constant"() <{value = 8 : index}> : () -> index
              %1063 = "arith.subi"(%arg260, %1062) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %1064 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1065 = "arith.subi"(%arg261, %1064) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%906, %905, %1063, %1065) <{nontemporal = false}> : (f32, memref<8x16xf32, strided<[16, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %910 = "arith.constant"() <{value = 0 : index}> : () -> index
          %911 = "arith.constant"() <{value = 4 : index}> : () -> index
          %912 = "arith.constant"() <{value = 1 : index}> : () -> index
          %913 = "scf.for"(%910, %911, %912, %904) ({
          ^bb0(%arg255: index, %arg256: !air.async.token):
            %983 = "arith.constant"() <{value = 32 : index}> : () -> index
            %984 = "arith.muli"(%arg255, %983) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %985 = "arith.constant"() <{value = 32 : index}> : () -> index
            %986 = "arith.muli"(%arg255, %985) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %987 = "arith.constant"() <{value = 32 : index}> : () -> index
            %988 = "arith.muli"(%arg255, %987) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %989 = "memref.reinterpret_cast"(%900) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 34 : i64, orbit.storage = "A"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %990 = "arith.constant"() <{value = 0 : index}> : () -> index
            %991 = "arith.addi"(%990, %986) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %992 = "air.dma_memcpy_nd"(%arg256, %989, %arg248, %991) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 34 : i64, orbit.source_copies = array<i64: 5>, orbit.storage = "A", orbit.target_copies = array<i64: 115>, orbit.transfer = "host_to_l1", orbit.transfer_event = 85 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 8, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %993 = "memref.reinterpret_cast"(%902) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 34 : i64, orbit.storage = "B"} : (memref<512xf32, 2 : i32>) -> memref<32x16xf32, strided<[16, 1]>, 2 : i32>
            %994 = "arith.constant"() <{value = 0 : index}> : () -> index
            %995 = "arith.addi"(%994, %988) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %996 = "air.dma_memcpy_nd"(%arg256, %993, %arg249, %995) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 34 : i64, orbit.source_copies = array<i64: 17>, orbit.storage = "B", orbit.target_copies = array<i64: 116>, orbit.transfer = "host_to_l1", orbit.transfer_event = 86 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: -9223372036854775808, 64>, static_src_sizes = array<i64: 32, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%992, %996) {orbit.computation_event = 88 : i64, orbit.phase = 34 : i64, orbit.phase_dependencies = array<i64: 33>, orbit.read_copies = array<i64: 115, 116, 117>, orbit.task = "gemm", orbit.write_copies = array<i64: 118>} : (!air.async.token, !air.async.token) -> ()
            %997 = "memref.cast"(%989) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %998 = "memref.cast"(%993) : (memref<32x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<32x16xf32, 2 : i32>
            %999 = "memref.cast"(%905) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
            %1000 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %1001 = "arith.constant"() <{value = 8 : index}> : () -> index
            %1002 = "arith.constant"() <{value = 16 : index}> : () -> index
            %1003 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%1001, %1002, %1003) ({
            ^bb0(%arg257: index):
              %1005 = "arith.constant"() <{value = 64 : index}> : () -> index
              %1006 = "arith.constant"() <{value = 80 : index}> : () -> index
              %1007 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%1005, %1006, %1007) ({
              ^bb0(%arg258: index):
                %1008 = "arith.constant"() <{value = 0 : index}> : () -> index
                %1009 = "arith.constant"() <{value = 32 : index}> : () -> index
                %1010 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%1008, %1009, %1010) ({
                ^bb0(%arg259: index):
                  %1011 = "arith.addi"(%arg259, %984) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1012 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1013 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1014 = "arith.subi"(%arg257, %1013) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1015 = "arith.subi"(%1011, %986) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1016 = "memref.load"(%997, %1014, %1015) <{nontemporal = false}> : (memref<8x32xf32, 2 : i32>, index, index) -> f32
                  %1017 = "vector.broadcast"(%1016) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %1018 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1019 = "arith.subi"(%1011, %988) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1020 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1021 = "arith.subi"(%arg258, %1020) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1022 = "vector.transfer_read"(%998, %1019, %1021, %1018) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1023 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %1024 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1025 = "arith.subi"(%arg257, %1024) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1026 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1027 = "arith.subi"(%arg258, %1026) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1028 = "vector.transfer_read"(%999, %1025, %1027, %1023) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %1029 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %1030 = "vector.extract"(%1022) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %1031 = "func.call"(%1016, %1030) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1032 = "vector.insert"(%1031, %1029) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1033 = "vector.extract"(%1022) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %1034 = "func.call"(%1016, %1033) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1035 = "vector.insert"(%1034, %1032) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1036 = "vector.extract"(%1022) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %1037 = "func.call"(%1016, %1036) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1038 = "vector.insert"(%1037, %1035) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1039 = "vector.extract"(%1022) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %1040 = "func.call"(%1016, %1039) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1041 = "vector.insert"(%1040, %1038) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1042 = "vector.extract"(%1022) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %1043 = "func.call"(%1016, %1042) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1044 = "vector.insert"(%1043, %1041) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1045 = "vector.extract"(%1022) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %1046 = "func.call"(%1016, %1045) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1047 = "vector.insert"(%1046, %1044) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1048 = "vector.extract"(%1022) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %1049 = "func.call"(%1016, %1048) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1050 = "vector.insert"(%1049, %1047) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1051 = "vector.extract"(%1022) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %1052 = "func.call"(%1016, %1051) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %1053 = "vector.insert"(%1052, %1050) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %1054 = "arith.addf"(%1028, %1053) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %1055 = "arith.constant"() <{value = 8 : index}> : () -> index
                  %1056 = "arith.subi"(%arg257, %1055) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %1057 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %1058 = "arith.subi"(%arg258, %1057) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%1054, %999, %1056, %1058) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %1004 = "air.wait_all"(%arg256) : (!air.async.token) -> !air.async.token
            "scf.yield"(%1004) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %914 = "memref.reinterpret_cast"(%899) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 38 : i64, orbit.storage = "A"} : (memref<8xf32, 2 : i32>) -> memref<8x1xf32, strided<[1, 1]>, 2 : i32>
          %915 = "air.dma_memcpy_nd"(%913, %914, %arg248) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 38 : i64, orbit.source_copies = array<i64: 9>, orbit.storage = "A", orbit.target_copies = array<i64: 128>, orbit.transfer = "host_to_l1", orbit.transfer_event = 98 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 8, 128>, static_src_sizes = array<i64: 8, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<8x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %916 = "memref.reinterpret_cast"(%901) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 38 : i64, orbit.storage = "B"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %917 = "air.dma_memcpy_nd"(%913, %916, %arg249) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 38 : i64, orbit.source_copies = array<i64: 29>, orbit.storage = "B", orbit.target_copies = array<i64: 129>, orbit.transfer = "host_to_l1", orbit.transfer_event = 99 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 128, 64>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%915, %917) {orbit.computation_event = 100 : i64, orbit.phase = 38 : i64, orbit.phase_dependencies = array<i64: 37>, orbit.read_copies = array<i64: 128, 129, 127>, orbit.task = "gemm", orbit.write_copies = array<i64: 130>} : (!air.async.token, !air.async.token) -> ()
          %918 = "memref.cast"(%914) : (memref<8x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<8x1xf32, 2 : i32>
          %919 = "memref.cast"(%916) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %920 = "memref.cast"(%905) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %921 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %922 = "arith.constant"() <{value = 8 : index}> : () -> index
          %923 = "arith.constant"() <{value = 16 : index}> : () -> index
          %924 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%922, %923, %924) ({
          ^bb0(%arg252: index):
            %928 = "arith.constant"() <{value = 64 : index}> : () -> index
            %929 = "arith.constant"() <{value = 80 : index}> : () -> index
            %930 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%928, %929, %930) ({
            ^bb0(%arg253: index):
              %931 = "arith.constant"() <{value = 128 : index}> : () -> index
              %932 = "arith.constant"() <{value = 129 : index}> : () -> index
              %933 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%931, %932, %933) ({
              ^bb0(%arg254: index):
                %934 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %935 = "arith.constant"() <{value = 8 : index}> : () -> index
                %936 = "arith.subi"(%arg252, %935) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %937 = "arith.constant"() <{value = 128 : index}> : () -> index
                %938 = "arith.subi"(%arg254, %937) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %939 = "memref.load"(%918, %936, %938) <{nontemporal = false}> : (memref<8x1xf32, 2 : i32>, index, index) -> f32
                %940 = "vector.broadcast"(%939) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %941 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %942 = "arith.constant"() <{value = 128 : index}> : () -> index
                %943 = "arith.subi"(%arg254, %942) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %944 = "arith.constant"() <{value = 64 : index}> : () -> index
                %945 = "arith.subi"(%arg253, %944) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %946 = "vector.transfer_read"(%919, %943, %945, %941) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %947 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %948 = "arith.constant"() <{value = 8 : index}> : () -> index
                %949 = "arith.subi"(%arg252, %948) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %950 = "arith.constant"() <{value = 64 : index}> : () -> index
                %951 = "arith.subi"(%arg253, %950) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %952 = "vector.transfer_read"(%920, %949, %951, %947) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %953 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %954 = "vector.extract"(%946) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %955 = "func.call"(%939, %954) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %956 = "vector.insert"(%955, %953) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %957 = "vector.extract"(%946) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %958 = "func.call"(%939, %957) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %959 = "vector.insert"(%958, %956) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %960 = "vector.extract"(%946) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %961 = "func.call"(%939, %960) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %962 = "vector.insert"(%961, %959) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %963 = "vector.extract"(%946) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %964 = "func.call"(%939, %963) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %965 = "vector.insert"(%964, %962) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %966 = "vector.extract"(%946) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %967 = "func.call"(%939, %966) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %968 = "vector.insert"(%967, %965) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %969 = "vector.extract"(%946) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %970 = "func.call"(%939, %969) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %971 = "vector.insert"(%970, %968) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %972 = "vector.extract"(%946) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %973 = "func.call"(%939, %972) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %974 = "vector.insert"(%973, %971) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %975 = "vector.extract"(%946) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %976 = "func.call"(%939, %975) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %977 = "vector.insert"(%976, %974) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %978 = "arith.addf"(%952, %977) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %979 = "arith.constant"() <{value = 8 : index}> : () -> index
                %980 = "arith.subi"(%arg252, %979) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %981 = "arith.constant"() <{value = 64 : index}> : () -> index
                %982 = "arith.subi"(%arg253, %981) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%978, %920, %980, %982) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %925 = "air.wait_all"(%913) : (!air.async.token) -> !air.async.token
          %926 = "air.dma_memcpy_nd"(%925, %arg251, %905) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 38 : i64, orbit.retained_begin = 34 : i64, orbit.retained_end = 39 : i64, orbit.source_copies = array<i64: 130>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 131>, orbit.transfer = "l1_to_host", orbit.transfer_event = 101 : i64, static_dst_offsets = array<i64: 8, 64>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %927 = "air.wait_all"(%926) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%927) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_34"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%898) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_34"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_34"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg202: index, %arg203: index, %arg204: index, %arg205: index, %arg206: memref<17x129xf32>, %arg207: memref<129x80xf32>, %arg208: memref<17x80xf32>, %arg209: memref<17x80xf32>):
      "air.segment"(%arg206, %arg207, %arg208, %arg209) ({
      ^bb0(%arg210: memref<17x129xf32>, %arg211: memref<129x80xf32>, %arg212: memref<17x80xf32>, %arg213: memref<17x80xf32>):
        %742 = "arith.constant"() <{value = 1 : index}> : () -> index
        %743 = "air.herd"(%742, %742, %arg210, %arg211, %arg212, %arg213) ({
        ^bb0(%arg214: index, %arg215: index, %arg216: index, %arg217: index, %arg218: memref<17x129xf32>, %arg219: memref<129x80xf32>, %arg220: memref<17x80xf32>, %arg221: memref<17x80xf32>):
          %744 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.1.loops.1.32.1"} : () -> memref<1xf32, 2 : i32>
          %745 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.32.loops.1.32.32"} : () -> memref<32xf32, 2 : i32>
          %746 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.1.32.1"} : () -> memref<32xf32, 2 : i32>
          %747 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.1.32.32"} : () -> memref<1024xf32, 2 : i32>
          %748 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<32xf32, 2 : i32>
          %749 = "air.wait_all"() : () -> !air.async.token
          %750 = "memref.reinterpret_cast"(%748) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 39 : i64, orbit.storage = "intermediate"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %751 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %752 = "arith.constant"() <{value = 16 : index}> : () -> index
          %753 = "arith.constant"() <{value = 17 : index}> : () -> index
          %754 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%752, %753, %754) ({
          ^bb0(%arg230: index):
            %892 = "arith.constant"() <{value = 0 : index}> : () -> index
            %893 = "arith.constant"() <{value = 32 : index}> : () -> index
            %894 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%892, %893, %894) ({
            ^bb0(%arg231: index):
              %895 = "arith.constant"() <{value = 16 : index}> : () -> index
              %896 = "arith.subi"(%arg230, %895) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%751, %750, %896, %arg231) <{nontemporal = false}> : (f32, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %755 = "arith.constant"() <{value = 0 : index}> : () -> index
          %756 = "arith.constant"() <{value = 4 : index}> : () -> index
          %757 = "arith.constant"() <{value = 1 : index}> : () -> index
          %758 = "scf.for"(%755, %756, %757, %749) ({
          ^bb0(%arg225: index, %arg226: !air.async.token):
            %822 = "arith.constant"() <{value = 32 : index}> : () -> index
            %823 = "arith.muli"(%arg225, %822) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %824 = "arith.constant"() <{value = 32 : index}> : () -> index
            %825 = "arith.muli"(%arg225, %824) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %826 = "arith.constant"() <{value = 32 : index}> : () -> index
            %827 = "arith.muli"(%arg225, %826) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %828 = "memref.reinterpret_cast"(%745) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 39 : i64, orbit.storage = "A"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %829 = "arith.constant"() <{value = 0 : index}> : () -> index
            %830 = "arith.addi"(%829, %825) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %831 = "air.dma_memcpy_nd"(%arg226, %828, %arg218, %830) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 39 : i64, orbit.source_copies = array<i64: 10>, orbit.storage = "A", orbit.target_copies = array<i64: 132>, orbit.transfer = "host_to_l1", orbit.transfer_event = 102 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 16, -9223372036854775808>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %832 = "memref.reinterpret_cast"(%747) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 39 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %833 = "arith.constant"() <{value = 0 : index}> : () -> index
            %834 = "arith.addi"(%833, %827) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %835 = "air.dma_memcpy_nd"(%arg226, %832, %arg219, %834) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 39 : i64, orbit.source_copies = array<i64: 15>, orbit.storage = "B", orbit.target_copies = array<i64: 133>, orbit.transfer = "host_to_l1", orbit.transfer_event = 103 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 0>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%831, %835) {orbit.computation_event = 105 : i64, orbit.phase = 39 : i64, orbit.phase_dependencies = array<i64: 38>, orbit.read_copies = array<i64: 132, 133, 134>, orbit.task = "gemm", orbit.write_copies = array<i64: 135>} : (!air.async.token, !air.async.token) -> ()
            %836 = "memref.cast"(%828) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %837 = "memref.cast"(%832) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %838 = "memref.cast"(%750) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %839 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %840 = "arith.constant"() <{value = 16 : index}> : () -> index
            %841 = "arith.constant"() <{value = 17 : index}> : () -> index
            %842 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%840, %841, %842) ({
            ^bb0(%arg227: index):
              %844 = "arith.constant"() <{value = 0 : index}> : () -> index
              %845 = "arith.constant"() <{value = 32 : index}> : () -> index
              %846 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%844, %845, %846) ({
              ^bb0(%arg228: index):
                %847 = "arith.constant"() <{value = 0 : index}> : () -> index
                %848 = "arith.constant"() <{value = 32 : index}> : () -> index
                %849 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%847, %848, %849) ({
                ^bb0(%arg229: index):
                  %850 = "arith.addi"(%arg229, %823) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %851 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %852 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %853 = "arith.subi"(%arg227, %852) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %854 = "arith.subi"(%850, %825) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %855 = "memref.load"(%836, %853, %854) <{nontemporal = false}> : (memref<1x32xf32, 2 : i32>, index, index) -> f32
                  %856 = "vector.broadcast"(%855) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %857 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %858 = "arith.subi"(%850, %827) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %859 = "vector.transfer_read"(%837, %858, %arg228, %857) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %860 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %861 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %862 = "arith.subi"(%arg227, %861) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %863 = "vector.transfer_read"(%838, %862, %arg228, %860) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %864 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %865 = "vector.extract"(%859) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %866 = "func.call"(%855, %865) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %867 = "vector.insert"(%866, %864) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %868 = "vector.extract"(%859) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %869 = "func.call"(%855, %868) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %870 = "vector.insert"(%869, %867) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %871 = "vector.extract"(%859) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %872 = "func.call"(%855, %871) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %873 = "vector.insert"(%872, %870) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %874 = "vector.extract"(%859) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %875 = "func.call"(%855, %874) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %876 = "vector.insert"(%875, %873) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %877 = "vector.extract"(%859) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %878 = "func.call"(%855, %877) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %879 = "vector.insert"(%878, %876) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %880 = "vector.extract"(%859) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %881 = "func.call"(%855, %880) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %882 = "vector.insert"(%881, %879) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %883 = "vector.extract"(%859) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %884 = "func.call"(%855, %883) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %885 = "vector.insert"(%884, %882) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %886 = "vector.extract"(%859) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %887 = "func.call"(%855, %886) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %888 = "vector.insert"(%887, %885) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %889 = "arith.addf"(%863, %888) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %890 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %891 = "arith.subi"(%arg227, %890) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%889, %838, %891, %arg228) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %843 = "air.wait_all"(%arg226) : (!air.async.token) -> !air.async.token
            "scf.yield"(%843) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %759 = "memref.reinterpret_cast"(%744) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 43 : i64, orbit.storage = "A"} : (memref<1xf32, 2 : i32>) -> memref<1x1xf32, strided<[1, 1]>, 2 : i32>
          %760 = "air.dma_memcpy_nd"(%758, %759, %arg218) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 43 : i64, orbit.source_copies = array<i64: 14>, orbit.storage = "A", orbit.target_copies = array<i64: 145>, orbit.transfer = "host_to_l1", orbit.transfer_event = 115 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 16, 128>, static_src_sizes = array<i64: 1, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %761 = "memref.reinterpret_cast"(%746) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 43 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %762 = "air.dma_memcpy_nd"(%758, %761, %arg219) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 43 : i64, orbit.source_copies = array<i64: 27>, orbit.storage = "B", orbit.target_copies = array<i64: 146>, orbit.transfer = "host_to_l1", orbit.transfer_event = 116 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%760, %762) {orbit.computation_event = 117 : i64, orbit.phase = 43 : i64, orbit.phase_dependencies = array<i64: 42>, orbit.read_copies = array<i64: 145, 146, 144>, orbit.task = "gemm", orbit.write_copies = array<i64: 147>} : (!air.async.token, !air.async.token) -> ()
          %763 = "memref.cast"(%759) : (memref<1x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<1x1xf32, 2 : i32>
          %764 = "memref.cast"(%761) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %765 = "memref.cast"(%750) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %766 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %767 = "arith.constant"() <{value = 16 : index}> : () -> index
          %768 = "arith.constant"() <{value = 17 : index}> : () -> index
          %769 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%767, %768, %769) ({
          ^bb0(%arg222: index):
            %773 = "arith.constant"() <{value = 0 : index}> : () -> index
            %774 = "arith.constant"() <{value = 32 : index}> : () -> index
            %775 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%773, %774, %775) ({
            ^bb0(%arg223: index):
              %776 = "arith.constant"() <{value = 128 : index}> : () -> index
              %777 = "arith.constant"() <{value = 129 : index}> : () -> index
              %778 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%776, %777, %778) ({
              ^bb0(%arg224: index):
                %779 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %780 = "arith.constant"() <{value = 16 : index}> : () -> index
                %781 = "arith.subi"(%arg222, %780) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %782 = "arith.constant"() <{value = 128 : index}> : () -> index
                %783 = "arith.subi"(%arg224, %782) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %784 = "memref.load"(%763, %781, %783) <{nontemporal = false}> : (memref<1x1xf32, 2 : i32>, index, index) -> f32
                %785 = "vector.broadcast"(%784) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %786 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %787 = "arith.constant"() <{value = 128 : index}> : () -> index
                %788 = "arith.subi"(%arg224, %787) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %789 = "vector.transfer_read"(%764, %788, %arg223, %786) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %790 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %791 = "arith.constant"() <{value = 16 : index}> : () -> index
                %792 = "arith.subi"(%arg222, %791) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %793 = "vector.transfer_read"(%765, %792, %arg223, %790) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %794 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %795 = "vector.extract"(%789) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %796 = "func.call"(%784, %795) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %797 = "vector.insert"(%796, %794) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %798 = "vector.extract"(%789) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %799 = "func.call"(%784, %798) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %800 = "vector.insert"(%799, %797) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %801 = "vector.extract"(%789) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %802 = "func.call"(%784, %801) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %803 = "vector.insert"(%802, %800) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %804 = "vector.extract"(%789) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %805 = "func.call"(%784, %804) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %806 = "vector.insert"(%805, %803) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %807 = "vector.extract"(%789) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %808 = "func.call"(%784, %807) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %809 = "vector.insert"(%808, %806) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %810 = "vector.extract"(%789) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %811 = "func.call"(%784, %810) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %812 = "vector.insert"(%811, %809) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %813 = "vector.extract"(%789) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %814 = "func.call"(%784, %813) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %815 = "vector.insert"(%814, %812) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %816 = "vector.extract"(%789) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %817 = "func.call"(%784, %816) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %818 = "vector.insert"(%817, %815) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %819 = "arith.addf"(%793, %818) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %820 = "arith.constant"() <{value = 16 : index}> : () -> index
                %821 = "arith.subi"(%arg222, %820) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%819, %765, %821, %arg223) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %770 = "air.wait_all"(%758) : (!air.async.token) -> !air.async.token
          %771 = "air.dma_memcpy_nd"(%770, %arg221, %750) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 43 : i64, orbit.retained_begin = 39 : i64, orbit.retained_end = 44 : i64, orbit.source_copies = array<i64: 147>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 148>, orbit.transfer = "l1_to_host", orbit.transfer_event = 118 : i64, static_dst_offsets = array<i64: 16, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %772 = "air.wait_all"(%771) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%772) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_39"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%743) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_39"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_39"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg172: index, %arg173: index, %arg174: index, %arg175: index, %arg176: memref<17x129xf32>, %arg177: memref<129x80xf32>, %arg178: memref<17x80xf32>, %arg179: memref<17x80xf32>):
      "air.segment"(%arg176, %arg177, %arg178, %arg179) ({
      ^bb0(%arg180: memref<17x129xf32>, %arg181: memref<129x80xf32>, %arg182: memref<17x80xf32>, %arg183: memref<17x80xf32>):
        %573 = "arith.constant"() <{value = 1 : index}> : () -> index
        %574 = "air.herd"(%573, %573, %arg180, %arg181, %arg182, %arg183) ({
        ^bb0(%arg184: index, %arg185: index, %arg186: index, %arg187: index, %arg188: memref<17x129xf32>, %arg189: memref<129x80xf32>, %arg190: memref<17x80xf32>, %arg191: memref<17x80xf32>):
          %575 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.1.loops.1.32.1"} : () -> memref<1xf32, 2 : i32>
          %576 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.32.loops.1.32.32"} : () -> memref<32xf32, 2 : i32>
          %577 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.32.loops.1.32.1"} : () -> memref<32xf32, 2 : i32>
          %578 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.32.loops.1.32.32"} : () -> memref<1024xf32, 2 : i32>
          %579 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<32xf32, 2 : i32>
          %580 = "air.wait_all"() : () -> !air.async.token
          %581 = "memref.reinterpret_cast"(%579) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 44 : i64, orbit.storage = "intermediate"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %582 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %583 = "arith.constant"() <{value = 16 : index}> : () -> index
          %584 = "arith.constant"() <{value = 17 : index}> : () -> index
          %585 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%583, %584, %585) ({
          ^bb0(%arg200: index):
            %735 = "arith.constant"() <{value = 32 : index}> : () -> index
            %736 = "arith.constant"() <{value = 64 : index}> : () -> index
            %737 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%735, %736, %737) ({
            ^bb0(%arg201: index):
              %738 = "arith.constant"() <{value = 16 : index}> : () -> index
              %739 = "arith.subi"(%arg200, %738) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %740 = "arith.constant"() <{value = 32 : index}> : () -> index
              %741 = "arith.subi"(%arg201, %740) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%582, %581, %739, %741) <{nontemporal = false}> : (f32, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %586 = "arith.constant"() <{value = 0 : index}> : () -> index
          %587 = "arith.constant"() <{value = 4 : index}> : () -> index
          %588 = "arith.constant"() <{value = 1 : index}> : () -> index
          %589 = "scf.for"(%586, %587, %588, %580) ({
          ^bb0(%arg195: index, %arg196: !air.async.token):
            %659 = "arith.constant"() <{value = 32 : index}> : () -> index
            %660 = "arith.muli"(%arg195, %659) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %661 = "arith.constant"() <{value = 32 : index}> : () -> index
            %662 = "arith.muli"(%arg195, %661) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %663 = "arith.constant"() <{value = 32 : index}> : () -> index
            %664 = "arith.muli"(%arg195, %663) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %665 = "memref.reinterpret_cast"(%576) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 44 : i64, orbit.storage = "A"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %666 = "arith.constant"() <{value = 0 : index}> : () -> index
            %667 = "arith.addi"(%666, %662) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %668 = "air.dma_memcpy_nd"(%arg196, %665, %arg188, %667) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 44 : i64, orbit.source_copies = array<i64: 10>, orbit.storage = "A", orbit.target_copies = array<i64: 149>, orbit.transfer = "host_to_l1", orbit.transfer_event = 119 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 16, -9223372036854775808>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %669 = "memref.reinterpret_cast"(%578) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 44 : i64, orbit.storage = "B"} : (memref<1024xf32, 2 : i32>) -> memref<32x32xf32, strided<[32, 1]>, 2 : i32>
            %670 = "arith.constant"() <{value = 0 : index}> : () -> index
            %671 = "arith.addi"(%670, %664) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %672 = "air.dma_memcpy_nd"(%arg196, %669, %arg189, %671) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 44 : i64, orbit.source_copies = array<i64: 16>, orbit.storage = "B", orbit.target_copies = array<i64: 150>, orbit.transfer = "host_to_l1", orbit.transfer_event = 120 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: -9223372036854775808, 32>, static_src_sizes = array<i64: 32, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%668, %672) {orbit.computation_event = 122 : i64, orbit.phase = 44 : i64, orbit.phase_dependencies = array<i64: 43>, orbit.read_copies = array<i64: 149, 150, 151>, orbit.task = "gemm", orbit.write_copies = array<i64: 152>} : (!air.async.token, !air.async.token) -> ()
            %673 = "memref.cast"(%665) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %674 = "memref.cast"(%669) : (memref<32x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<32x32xf32, 2 : i32>
            %675 = "memref.cast"(%581) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %676 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %677 = "arith.constant"() <{value = 16 : index}> : () -> index
            %678 = "arith.constant"() <{value = 17 : index}> : () -> index
            %679 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%677, %678, %679) ({
            ^bb0(%arg197: index):
              %681 = "arith.constant"() <{value = 32 : index}> : () -> index
              %682 = "arith.constant"() <{value = 64 : index}> : () -> index
              %683 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%681, %682, %683) ({
              ^bb0(%arg198: index):
                %684 = "arith.constant"() <{value = 0 : index}> : () -> index
                %685 = "arith.constant"() <{value = 32 : index}> : () -> index
                %686 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%684, %685, %686) ({
                ^bb0(%arg199: index):
                  %687 = "arith.addi"(%arg199, %660) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %688 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %689 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %690 = "arith.subi"(%arg197, %689) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %691 = "arith.subi"(%687, %662) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %692 = "memref.load"(%673, %690, %691) <{nontemporal = false}> : (memref<1x32xf32, 2 : i32>, index, index) -> f32
                  %693 = "vector.broadcast"(%692) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %694 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %695 = "arith.subi"(%687, %664) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %696 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %697 = "arith.subi"(%arg198, %696) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %698 = "vector.transfer_read"(%674, %695, %697, %694) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %699 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %700 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %701 = "arith.subi"(%arg197, %700) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %702 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %703 = "arith.subi"(%arg198, %702) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %704 = "vector.transfer_read"(%675, %701, %703, %699) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %705 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %706 = "vector.extract"(%698) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %707 = "func.call"(%692, %706) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %708 = "vector.insert"(%707, %705) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %709 = "vector.extract"(%698) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %710 = "func.call"(%692, %709) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %711 = "vector.insert"(%710, %708) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %712 = "vector.extract"(%698) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %713 = "func.call"(%692, %712) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %714 = "vector.insert"(%713, %711) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %715 = "vector.extract"(%698) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %716 = "func.call"(%692, %715) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %717 = "vector.insert"(%716, %714) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %718 = "vector.extract"(%698) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %719 = "func.call"(%692, %718) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %720 = "vector.insert"(%719, %717) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %721 = "vector.extract"(%698) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %722 = "func.call"(%692, %721) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %723 = "vector.insert"(%722, %720) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %724 = "vector.extract"(%698) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %725 = "func.call"(%692, %724) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %726 = "vector.insert"(%725, %723) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %727 = "vector.extract"(%698) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %728 = "func.call"(%692, %727) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %729 = "vector.insert"(%728, %726) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %730 = "arith.addf"(%704, %729) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %731 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %732 = "arith.subi"(%arg197, %731) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %733 = "arith.constant"() <{value = 32 : index}> : () -> index
                  %734 = "arith.subi"(%arg198, %733) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%730, %675, %732, %734) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %680 = "air.wait_all"(%arg196) : (!air.async.token) -> !air.async.token
            "scf.yield"(%680) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %590 = "memref.reinterpret_cast"(%575) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 48 : i64, orbit.storage = "A"} : (memref<1xf32, 2 : i32>) -> memref<1x1xf32, strided<[1, 1]>, 2 : i32>
          %591 = "air.dma_memcpy_nd"(%589, %590, %arg188) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 48 : i64, orbit.source_copies = array<i64: 14>, orbit.storage = "A", orbit.target_copies = array<i64: 162>, orbit.transfer = "host_to_l1", orbit.transfer_event = 132 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 16, 128>, static_src_sizes = array<i64: 1, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %592 = "memref.reinterpret_cast"(%577) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 48 : i64, orbit.storage = "B"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
          %593 = "air.dma_memcpy_nd"(%589, %592, %arg189) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 48 : i64, orbit.source_copies = array<i64: 28>, orbit.storage = "B", orbit.target_copies = array<i64: 163>, orbit.transfer = "host_to_l1", orbit.transfer_event = 133 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 128, 32>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%591, %593) {orbit.computation_event = 134 : i64, orbit.phase = 48 : i64, orbit.phase_dependencies = array<i64: 47>, orbit.read_copies = array<i64: 162, 163, 161>, orbit.task = "gemm", orbit.write_copies = array<i64: 164>} : (!air.async.token, !air.async.token) -> ()
          %594 = "memref.cast"(%590) : (memref<1x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<1x1xf32, 2 : i32>
          %595 = "memref.cast"(%592) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %596 = "memref.cast"(%581) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
          %597 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %598 = "arith.constant"() <{value = 16 : index}> : () -> index
          %599 = "arith.constant"() <{value = 17 : index}> : () -> index
          %600 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%598, %599, %600) ({
          ^bb0(%arg192: index):
            %604 = "arith.constant"() <{value = 32 : index}> : () -> index
            %605 = "arith.constant"() <{value = 64 : index}> : () -> index
            %606 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%604, %605, %606) ({
            ^bb0(%arg193: index):
              %607 = "arith.constant"() <{value = 128 : index}> : () -> index
              %608 = "arith.constant"() <{value = 129 : index}> : () -> index
              %609 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%607, %608, %609) ({
              ^bb0(%arg194: index):
                %610 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %611 = "arith.constant"() <{value = 16 : index}> : () -> index
                %612 = "arith.subi"(%arg192, %611) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %613 = "arith.constant"() <{value = 128 : index}> : () -> index
                %614 = "arith.subi"(%arg194, %613) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %615 = "memref.load"(%594, %612, %614) <{nontemporal = false}> : (memref<1x1xf32, 2 : i32>, index, index) -> f32
                %616 = "vector.broadcast"(%615) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %617 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %618 = "arith.constant"() <{value = 128 : index}> : () -> index
                %619 = "arith.subi"(%arg194, %618) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %620 = "arith.constant"() <{value = 32 : index}> : () -> index
                %621 = "arith.subi"(%arg193, %620) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %622 = "vector.transfer_read"(%595, %619, %621, %617) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %623 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %624 = "arith.constant"() <{value = 16 : index}> : () -> index
                %625 = "arith.subi"(%arg192, %624) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %626 = "arith.constant"() <{value = 32 : index}> : () -> index
                %627 = "arith.subi"(%arg193, %626) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %628 = "vector.transfer_read"(%596, %625, %627, %623) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %629 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %630 = "vector.extract"(%622) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %631 = "func.call"(%615, %630) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %632 = "vector.insert"(%631, %629) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %633 = "vector.extract"(%622) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %634 = "func.call"(%615, %633) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %635 = "vector.insert"(%634, %632) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %636 = "vector.extract"(%622) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %637 = "func.call"(%615, %636) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %638 = "vector.insert"(%637, %635) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %639 = "vector.extract"(%622) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %640 = "func.call"(%615, %639) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %641 = "vector.insert"(%640, %638) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %642 = "vector.extract"(%622) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %643 = "func.call"(%615, %642) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %644 = "vector.insert"(%643, %641) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %645 = "vector.extract"(%622) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %646 = "func.call"(%615, %645) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %647 = "vector.insert"(%646, %644) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %648 = "vector.extract"(%622) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %649 = "func.call"(%615, %648) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %650 = "vector.insert"(%649, %647) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %651 = "vector.extract"(%622) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %652 = "func.call"(%615, %651) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %653 = "vector.insert"(%652, %650) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %654 = "arith.addf"(%628, %653) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %655 = "arith.constant"() <{value = 16 : index}> : () -> index
                %656 = "arith.subi"(%arg192, %655) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %657 = "arith.constant"() <{value = 32 : index}> : () -> index
                %658 = "arith.subi"(%arg193, %657) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%654, %596, %656, %658) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %601 = "air.wait_all"(%589) : (!air.async.token) -> !air.async.token
          %602 = "air.dma_memcpy_nd"(%601, %arg191, %581) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 48 : i64, orbit.retained_begin = 44 : i64, orbit.retained_end = 49 : i64, orbit.source_copies = array<i64: 164>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 165>, orbit.transfer = "l1_to_host", orbit.transfer_event = 135 : i64, static_dst_offsets = array<i64: 16, 32>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
          %603 = "air.wait_all"(%602) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%603) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_44"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%574) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_44"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_44"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg142: index, %arg143: index, %arg144: index, %arg145: index, %arg146: memref<17x129xf32>, %arg147: memref<129x80xf32>, %arg148: memref<17x80xf32>, %arg149: memref<17x80xf32>):
      "air.segment"(%arg146, %arg147, %arg148, %arg149) ({
      ^bb0(%arg150: memref<17x129xf32>, %arg151: memref<129x80xf32>, %arg152: memref<17x80xf32>, %arg153: memref<17x80xf32>):
        %404 = "arith.constant"() <{value = 1 : index}> : () -> index
        %405 = "air.herd"(%404, %404, %arg150, %arg151, %arg152, %arg153) ({
        ^bb0(%arg154: index, %arg155: index, %arg156: index, %arg157: index, %arg158: memref<17x129xf32>, %arg159: memref<129x80xf32>, %arg160: memref<17x80xf32>, %arg161: memref<17x80xf32>):
          %406 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.1.loops.1.16.1"} : () -> memref<1xf32, 2 : i32>
          %407 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 0 : i64, orbit.tile_pool = "storage-0.data.input.1.32.loops.1.16.32"} : () -> memref<32xf32, 2 : i32>
          %408 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.1.16.loops.1.16.1"} : () -> memref<16xf32, 2 : i32>
          %409 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 1 : i64, orbit.tile_pool = "storage-1.data.input.32.16.loops.1.16.32"} : () -> memref<512xf32, 2 : i32>
          %410 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.lifetime = "static-hardware-stage-region", orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data"} : () -> memref<16xf32, 2 : i32>
          %411 = "air.wait_all"() : () -> !air.async.token
          %412 = "memref.reinterpret_cast"(%410) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.initializer_task = "gemm.initialize", orbit.phase = 49 : i64, orbit.storage = "intermediate"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %413 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %414 = "arith.constant"() <{value = 16 : index}> : () -> index
          %415 = "arith.constant"() <{value = 17 : index}> : () -> index
          %416 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%414, %415, %416) ({
          ^bb0(%arg170: index):
            %566 = "arith.constant"() <{value = 64 : index}> : () -> index
            %567 = "arith.constant"() <{value = 80 : index}> : () -> index
            %568 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%566, %567, %568) ({
            ^bb0(%arg171: index):
              %569 = "arith.constant"() <{value = 16 : index}> : () -> index
              %570 = "arith.subi"(%arg170, %569) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %571 = "arith.constant"() <{value = 64 : index}> : () -> index
              %572 = "arith.subi"(%arg171, %571) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "memref.store"(%413, %412, %570, %572) <{nontemporal = false}> : (f32, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %417 = "arith.constant"() <{value = 0 : index}> : () -> index
          %418 = "arith.constant"() <{value = 4 : index}> : () -> index
          %419 = "arith.constant"() <{value = 1 : index}> : () -> index
          %420 = "scf.for"(%417, %418, %419, %411) ({
          ^bb0(%arg165: index, %arg166: !air.async.token):
            %490 = "arith.constant"() <{value = 32 : index}> : () -> index
            %491 = "arith.muli"(%arg165, %490) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %492 = "arith.constant"() <{value = 32 : index}> : () -> index
            %493 = "arith.muli"(%arg165, %492) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %494 = "arith.constant"() <{value = 32 : index}> : () -> index
            %495 = "arith.muli"(%arg165, %494) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %496 = "memref.reinterpret_cast"(%407) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 49 : i64, orbit.storage = "A"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %497 = "arith.constant"() <{value = 0 : index}> : () -> index
            %498 = "arith.addi"(%497, %493) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %499 = "air.dma_memcpy_nd"(%arg166, %496, %arg158, %498) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 49 : i64, orbit.source_copies = array<i64: 10>, orbit.storage = "A", orbit.target_copies = array<i64: 166>, orbit.transfer = "host_to_l1", orbit.transfer_event = 136 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 16, -9223372036854775808>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x129xf32>, index) -> !air.async.token
            %500 = "memref.reinterpret_cast"(%409) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 32, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 49 : i64, orbit.storage = "B"} : (memref<512xf32, 2 : i32>) -> memref<32x16xf32, strided<[16, 1]>, 2 : i32>
            %501 = "arith.constant"() <{value = 0 : index}> : () -> index
            %502 = "arith.addi"(%501, %495) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %503 = "air.dma_memcpy_nd"(%arg166, %500, %arg159, %502) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 49 : i64, orbit.source_copies = array<i64: 17>, orbit.storage = "B", orbit.target_copies = array<i64: 167>, orbit.transfer = "host_to_l1", orbit.transfer_event = 137 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 32, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: -9223372036854775808, 64>, static_src_sizes = array<i64: 32, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<32x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>, index) -> !air.async.token
            "air.wait_all"(%499, %503) {orbit.computation_event = 139 : i64, orbit.phase = 49 : i64, orbit.phase_dependencies = array<i64: 48>, orbit.read_copies = array<i64: 166, 167, 168>, orbit.task = "gemm", orbit.write_copies = array<i64: 169>} : (!air.async.token, !air.async.token) -> ()
            %504 = "memref.cast"(%496) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %505 = "memref.cast"(%500) : (memref<32x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<32x16xf32, 2 : i32>
            %506 = "memref.cast"(%412) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
            %507 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
            %508 = "arith.constant"() <{value = 16 : index}> : () -> index
            %509 = "arith.constant"() <{value = 17 : index}> : () -> index
            %510 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%508, %509, %510) ({
            ^bb0(%arg167: index):
              %512 = "arith.constant"() <{value = 64 : index}> : () -> index
              %513 = "arith.constant"() <{value = 80 : index}> : () -> index
              %514 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%512, %513, %514) ({
              ^bb0(%arg168: index):
                %515 = "arith.constant"() <{value = 0 : index}> : () -> index
                %516 = "arith.constant"() <{value = 32 : index}> : () -> index
                %517 = "arith.constant"() <{value = 1 : index}> : () -> index
                "scf.for"(%515, %516, %517) ({
                ^bb0(%arg169: index):
                  %518 = "arith.addi"(%arg169, %491) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %519 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %520 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %521 = "arith.subi"(%arg167, %520) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %522 = "arith.subi"(%518, %493) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %523 = "memref.load"(%504, %521, %522) <{nontemporal = false}> : (memref<1x32xf32, 2 : i32>, index, index) -> f32
                  %524 = "vector.broadcast"(%523) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                  %525 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %526 = "arith.subi"(%518, %495) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %527 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %528 = "arith.subi"(%arg168, %527) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %529 = "vector.transfer_read"(%505, %526, %528, %525) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<32x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %530 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                  %531 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %532 = "arith.subi"(%arg167, %531) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %533 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %534 = "arith.subi"(%arg168, %533) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %535 = "vector.transfer_read"(%506, %532, %534, %530) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                  %536 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                  %537 = "vector.extract"(%529) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                  %538 = "func.call"(%523, %537) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %539 = "vector.insert"(%538, %536) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %540 = "vector.extract"(%529) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                  %541 = "func.call"(%523, %540) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %542 = "vector.insert"(%541, %539) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %543 = "vector.extract"(%529) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                  %544 = "func.call"(%523, %543) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %545 = "vector.insert"(%544, %542) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %546 = "vector.extract"(%529) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                  %547 = "func.call"(%523, %546) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %548 = "vector.insert"(%547, %545) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %549 = "vector.extract"(%529) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                  %550 = "func.call"(%523, %549) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %551 = "vector.insert"(%550, %548) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %552 = "vector.extract"(%529) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                  %553 = "func.call"(%523, %552) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %554 = "vector.insert"(%553, %551) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %555 = "vector.extract"(%529) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                  %556 = "func.call"(%523, %555) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %557 = "vector.insert"(%556, %554) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %558 = "vector.extract"(%529) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                  %559 = "func.call"(%523, %558) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                  %560 = "vector.insert"(%559, %557) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                  %561 = "arith.addf"(%535, %560) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                  %562 = "arith.constant"() <{value = 16 : index}> : () -> index
                  %563 = "arith.subi"(%arg167, %562) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  %564 = "arith.constant"() <{value = 64 : index}> : () -> index
                  %565 = "arith.subi"(%arg168, %564) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                  "vector.transfer_write"(%561, %506, %563, %565) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x16xf32, 2 : i32>, index, index) -> ()
                  "scf.yield"() : () -> ()
                }) : (index, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %511 = "air.wait_all"(%arg166) : (!air.async.token) -> !air.async.token
            "scf.yield"(%511) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 4 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          %421 = "memref.reinterpret_cast"(%406) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 1>, static_strides = array<i64: 1, 1>}> {orbit.phase = 53 : i64, orbit.storage = "A"} : (memref<1xf32, 2 : i32>) -> memref<1x1xf32, strided<[1, 1]>, 2 : i32>
          %422 = "air.dma_memcpy_nd"(%420, %421, %arg158) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 53 : i64, orbit.source_copies = array<i64: 14>, orbit.storage = "A", orbit.target_copies = array<i64: 179>, orbit.transfer = "host_to_l1", orbit.transfer_event = 149 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 1>, static_dst_strides = array<i64: 1, 1>, static_src_offsets = array<i64: 16, 128>, static_src_sizes = array<i64: 1, 1>, static_src_strides = array<i64: 129, 1>} : (!air.async.token, memref<1x1xf32, strided<[1, 1]>, 2 : i32>, memref<17x129xf32>) -> !air.async.token
          %423 = "memref.reinterpret_cast"(%408) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 53 : i64, orbit.storage = "B"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %424 = "air.dma_memcpy_nd"(%420, %423, %arg159) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 53 : i64, orbit.source_copies = array<i64: 29>, orbit.storage = "B", orbit.target_copies = array<i64: 180>, orbit.transfer = "host_to_l1", orbit.transfer_event = 150 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 128, 64>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, memref<129x80xf32>) -> !air.async.token
          "air.wait_all"(%422, %424) {orbit.computation_event = 151 : i64, orbit.phase = 53 : i64, orbit.phase_dependencies = array<i64: 52>, orbit.read_copies = array<i64: 179, 180, 178>, orbit.task = "gemm", orbit.write_copies = array<i64: 181>} : (!air.async.token, !air.async.token) -> ()
          %425 = "memref.cast"(%421) : (memref<1x1xf32, strided<[1, 1]>, 2 : i32>) -> memref<1x1xf32, 2 : i32>
          %426 = "memref.cast"(%423) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %427 = "memref.cast"(%412) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %428 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
          %429 = "arith.constant"() <{value = 16 : index}> : () -> index
          %430 = "arith.constant"() <{value = 17 : index}> : () -> index
          %431 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%429, %430, %431) ({
          ^bb0(%arg162: index):
            %435 = "arith.constant"() <{value = 64 : index}> : () -> index
            %436 = "arith.constant"() <{value = 80 : index}> : () -> index
            %437 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%435, %436, %437) ({
            ^bb0(%arg163: index):
              %438 = "arith.constant"() <{value = 128 : index}> : () -> index
              %439 = "arith.constant"() <{value = 129 : index}> : () -> index
              %440 = "arith.constant"() <{value = 1 : index}> : () -> index
              "scf.for"(%438, %439, %440) ({
              ^bb0(%arg164: index):
                %441 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %442 = "arith.constant"() <{value = 16 : index}> : () -> index
                %443 = "arith.subi"(%arg162, %442) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %444 = "arith.constant"() <{value = 128 : index}> : () -> index
                %445 = "arith.subi"(%arg164, %444) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %446 = "memref.load"(%425, %443, %445) <{nontemporal = false}> : (memref<1x1xf32, 2 : i32>, index, index) -> f32
                %447 = "vector.broadcast"(%446) {orbit.invariant_scalar_broadcast} : (f32) -> vector<8xf32>
                %448 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %449 = "arith.constant"() <{value = 128 : index}> : () -> index
                %450 = "arith.subi"(%arg164, %449) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %451 = "arith.constant"() <{value = 64 : index}> : () -> index
                %452 = "arith.subi"(%arg163, %451) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %453 = "vector.transfer_read"(%426, %450, %452, %448) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %454 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %455 = "arith.constant"() <{value = 16 : index}> : () -> index
                %456 = "arith.subi"(%arg162, %455) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %457 = "arith.constant"() <{value = 64 : index}> : () -> index
                %458 = "arith.subi"(%arg163, %457) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %459 = "vector.transfer_read"(%427, %456, %458, %454) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %460 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %461 = "vector.extract"(%453) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %462 = "func.call"(%446, %461) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %463 = "vector.insert"(%462, %460) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %464 = "vector.extract"(%453) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %465 = "func.call"(%446, %464) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %466 = "vector.insert"(%465, %463) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %467 = "vector.extract"(%453) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %468 = "func.call"(%446, %467) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %469 = "vector.insert"(%468, %466) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %470 = "vector.extract"(%453) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %471 = "func.call"(%446, %470) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %472 = "vector.insert"(%471, %469) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %473 = "vector.extract"(%453) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %474 = "func.call"(%446, %473) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %475 = "vector.insert"(%474, %472) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %476 = "vector.extract"(%453) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %477 = "func.call"(%446, %476) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %478 = "vector.insert"(%477, %475) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %479 = "vector.extract"(%453) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %480 = "func.call"(%446, %479) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %481 = "vector.insert"(%480, %478) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %482 = "vector.extract"(%453) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %483 = "func.call"(%446, %482) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %484 = "vector.insert"(%483, %481) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %485 = "arith.addf"(%459, %484) <{fastmath = #arith.fastmath<none>}> : (vector<8xf32>, vector<8xf32>) -> vector<8xf32>
                %486 = "arith.constant"() <{value = 16 : index}> : () -> index
                %487 = "arith.subi"(%arg162, %486) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %488 = "arith.constant"() <{value = 64 : index}> : () -> index
                %489 = "arith.subi"(%arg163, %488) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%485, %427, %487, %489) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x16xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %432 = "air.wait_all"(%420) : (!air.async.token) -> !air.async.token
          %433 = "air.dma_memcpy_nd"(%432, %arg161, %412) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 53 : i64, orbit.retained_begin = 49 : i64, orbit.retained_end = 54 : i64, orbit.source_copies = array<i64: 181>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 182>, orbit.transfer = "l1_to_host", orbit.transfer_event = 152 : i64, static_dst_offsets = array<i64: 16, 64>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %434 = "air.wait_all"(%433) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%434) : (!air.async.token) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_49"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> !air.async.token
        "air.wait_all"(%405) : (!air.async.token) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_49"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_49"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg118: index, %arg119: index, %arg120: index, %arg121: index, %arg122: memref<17x129xf32>, %arg123: memref<129x80xf32>, %arg124: memref<17x80xf32>, %arg125: memref<17x80xf32>):
      "air.segment"(%arg122, %arg123, %arg124, %arg125) ({
      ^bb0(%arg126: memref<17x129xf32>, %arg127: memref<129x80xf32>, %arg128: memref<17x80xf32>, %arg129: memref<17x80xf32>):
        %333 = "arith.constant"() <{value = 1 : index}> : () -> index
        "air.herd"(%333, %333, %arg126, %arg127, %arg128, %arg129) ({
        ^bb0(%arg130: index, %arg131: index, %arg132: index, %arg133: index, %arg134: memref<17x129xf32>, %arg135: memref<129x80xf32>, %arg136: memref<17x80xf32>, %arg137: memref<17x80xf32>):
          %334 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<256xf32, 2 : i32>
          %335 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.8.32.loops.8.32"} : () -> memref<256xf32, 2 : i32>
          %336 = "air.wait_all"() : () -> !air.async.token
          %337 = "arith.constant"() <{value = 0 : index}> : () -> index
          %338 = "arith.constant"() <{value = 2 : index}> : () -> index
          %339 = "arith.constant"() <{value = 1 : index}> : () -> index
          %340 = "scf.for"(%337, %338, %339, %336) ({
          ^bb0(%arg138: index, %arg139: !air.async.token):
            %341 = "arith.constant"() <{value = 32 : index}> : () -> index
            %342 = "arith.muli"(%arg138, %341) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %343 = "arith.constant"() <{value = 32 : index}> : () -> index
            %344 = "arith.muli"(%arg138, %343) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %345 = "arith.constant"() <{value = 32 : index}> : () -> index
            %346 = "arith.muli"(%arg138, %345) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %347 = "memref.reinterpret_cast"(%334) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 54 : i64, orbit.storage = "Y"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %348 = "memref.reinterpret_cast"(%335) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 54 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %349 = "arith.constant"() <{value = 0 : index}> : () -> index
            %350 = "arith.addi"(%349, %346) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %351 = "air.dma_memcpy_nd"(%arg139, %348, %arg137, %350) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 54 : i64, orbit.source_copies = array<i64: 46>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 183>, orbit.transfer = "host_to_l1", orbit.transfer_event = 153 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 0, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x80xf32>, index) -> !air.async.token
            "air.wait_all"(%351) {orbit.computation_event = 154 : i64, orbit.phase = 54 : i64, orbit.phase_dependencies = array<i64: 53>, orbit.read_copies = array<i64: 183>, orbit.task = "scale", orbit.write_copies = array<i64: 184>} : (!air.async.token) -> ()
            %352 = "memref.cast"(%347) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %353 = "memref.cast"(%348) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %354 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
            %355 = "arith.constant"() <{value = 0 : index}> : () -> index
            %356 = "arith.constant"() <{value = 8 : index}> : () -> index
            %357 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%355, %356, %357) ({
            ^bb0(%arg140: index):
              %362 = "arith.constant"() <{value = 0 : index}> : () -> index
              %363 = "arith.constant"() <{value = 32 : index}> : () -> index
              %364 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%362, %363, %364) ({
              ^bb0(%arg141: index):
                %365 = "arith.addi"(%arg141, %342) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %366 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
                %367 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %368 = "arith.subi"(%365, %346) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %369 = "vector.transfer_read"(%353, %arg140, %368, %367) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %370 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %371 = "vector.extract"(%369) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %372 = "vector.extract"(%366) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %373 = "func.call"(%371, %372) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %374 = "vector.insert"(%373, %370) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %375 = "vector.extract"(%369) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %376 = "vector.extract"(%366) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %377 = "func.call"(%375, %376) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %378 = "vector.insert"(%377, %374) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %379 = "vector.extract"(%369) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %380 = "vector.extract"(%366) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %381 = "func.call"(%379, %380) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %382 = "vector.insert"(%381, %378) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %383 = "vector.extract"(%369) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %384 = "vector.extract"(%366) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %385 = "func.call"(%383, %384) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %386 = "vector.insert"(%385, %382) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %387 = "vector.extract"(%369) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %388 = "vector.extract"(%366) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %389 = "func.call"(%387, %388) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %390 = "vector.insert"(%389, %386) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %391 = "vector.extract"(%369) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %392 = "vector.extract"(%366) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %393 = "func.call"(%391, %392) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %394 = "vector.insert"(%393, %390) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %395 = "vector.extract"(%369) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %396 = "vector.extract"(%366) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %397 = "func.call"(%395, %396) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %398 = "vector.insert"(%397, %394) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %399 = "vector.extract"(%369) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %400 = "vector.extract"(%366) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %401 = "func.call"(%399, %400) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %402 = "vector.insert"(%401, %398) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %403 = "arith.subi"(%365, %344) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%402, %352, %arg140, %403) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %358 = "arith.constant"() <{value = 0 : index}> : () -> index
            %359 = "arith.addi"(%358, %344) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %360 = "air.dma_memcpy_nd"(%arg139, %arg136, %359, %347) {operandSegmentSizes = array<i32: 1, 1, 1, 0, 0, 1, 0, 0, 0>, orbit.phase = 54 : i64, orbit.source_copies = array<i64: 184>, orbit.storage = "Y", orbit.target_copies = array<i64: 185>, orbit.transfer = "l1_to_host", orbit.transfer_event = 155 : i64, static_dst_offsets = array<i64: 0, -9223372036854775808>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, index, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
            %361 = "air.wait_all"(%360) : (!air.async.token) -> !air.async.token
            "scf.yield"(%361) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 2 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          "air.wait_all"(%340) : (!air.async.token) -> ()
          "memref.dealloc"(%334) : (memref<256xf32, 2 : i32>) -> ()
          "memref.dealloc"(%335) : (memref<256xf32, 2 : i32>) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_54"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_54"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_54"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg96: index, %arg97: index, %arg98: index, %arg99: index, %arg100: memref<17x129xf32>, %arg101: memref<129x80xf32>, %arg102: memref<17x80xf32>, %arg103: memref<17x80xf32>):
      "air.segment"(%arg100, %arg101, %arg102, %arg103) ({
      ^bb0(%arg104: memref<17x129xf32>, %arg105: memref<129x80xf32>, %arg106: memref<17x80xf32>, %arg107: memref<17x80xf32>):
        %275 = "arith.constant"() <{value = 1 : index}> : () -> index
        "air.herd"(%275, %275, %arg104, %arg105, %arg106, %arg107) ({
        ^bb0(%arg108: index, %arg109: index, %arg110: index, %arg111: index, %arg112: memref<17x129xf32>, %arg113: memref<129x80xf32>, %arg114: memref<17x80xf32>, %arg115: memref<17x80xf32>):
          %276 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<128xf32, 2 : i32>
          %277 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.8.16.loops.8.16"} : () -> memref<128xf32, 2 : i32>
          %278 = "air.wait_all"() : () -> !air.async.token
          %279 = "memref.reinterpret_cast"(%276) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 56 : i64, orbit.storage = "Y"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %280 = "memref.reinterpret_cast"(%277) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 56 : i64, orbit.storage = "intermediate"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %281 = "air.dma_memcpy_nd"(%278, %280, %arg115) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 56 : i64, orbit.source_copies = array<i64: 80>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 189>, orbit.transfer = "host_to_l1", orbit.transfer_event = 159 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 0, 64>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<8x16xf32, strided<[16, 1]>, 2 : i32>, memref<17x80xf32>) -> !air.async.token
          "air.wait_all"(%281) {orbit.computation_event = 160 : i64, orbit.phase = 56 : i64, orbit.phase_dependencies = array<i64: 55>, orbit.read_copies = array<i64: 189>, orbit.task = "scale", orbit.write_copies = array<i64: 190>} : (!air.async.token) -> ()
          %282 = "memref.cast"(%279) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %283 = "memref.cast"(%280) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %284 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
          %285 = "arith.constant"() <{value = 0 : index}> : () -> index
          %286 = "arith.constant"() <{value = 8 : index}> : () -> index
          %287 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%285, %286, %287) ({
          ^bb0(%arg116: index):
            %290 = "arith.constant"() <{value = 64 : index}> : () -> index
            %291 = "arith.constant"() <{value = 80 : index}> : () -> index
            %292 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%290, %291, %292) ({
            ^bb0(%arg117: index):
              %293 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
              %294 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
              %295 = "arith.constant"() <{value = 64 : index}> : () -> index
              %296 = "arith.subi"(%arg117, %295) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %297 = "vector.transfer_read"(%283, %arg116, %296, %294) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
              %298 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
              %299 = "vector.extract"(%297) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %300 = "vector.extract"(%293) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %301 = "func.call"(%299, %300) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %302 = "vector.insert"(%301, %298) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %303 = "vector.extract"(%297) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %304 = "vector.extract"(%293) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %305 = "func.call"(%303, %304) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %306 = "vector.insert"(%305, %302) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %307 = "vector.extract"(%297) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %308 = "vector.extract"(%293) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %309 = "func.call"(%307, %308) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %310 = "vector.insert"(%309, %306) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %311 = "vector.extract"(%297) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %312 = "vector.extract"(%293) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %313 = "func.call"(%311, %312) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %314 = "vector.insert"(%313, %310) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %315 = "vector.extract"(%297) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %316 = "vector.extract"(%293) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %317 = "func.call"(%315, %316) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %318 = "vector.insert"(%317, %314) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %319 = "vector.extract"(%297) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %320 = "vector.extract"(%293) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %321 = "func.call"(%319, %320) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %322 = "vector.insert"(%321, %318) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %323 = "vector.extract"(%297) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %324 = "vector.extract"(%293) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %325 = "func.call"(%323, %324) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %326 = "vector.insert"(%325, %322) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %327 = "vector.extract"(%297) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %328 = "vector.extract"(%293) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %329 = "func.call"(%327, %328) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %330 = "vector.insert"(%329, %326) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %331 = "arith.constant"() <{value = 64 : index}> : () -> index
              %332 = "arith.subi"(%arg117, %331) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "vector.transfer_write"(%330, %282, %arg116, %332) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %288 = "air.dma_memcpy_nd"(%278, %arg114, %279) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 56 : i64, orbit.source_copies = array<i64: 190>, orbit.storage = "Y", orbit.target_copies = array<i64: 191>, orbit.transfer = "l1_to_host", orbit.transfer_event = 161 : i64, static_dst_offsets = array<i64: 0, 64>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %289 = "air.wait_all"(%288) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%289) : (!air.async.token) -> ()
          "memref.dealloc"(%276) : (memref<128xf32, 2 : i32>) -> ()
          "memref.dealloc"(%277) : (memref<128xf32, 2 : i32>) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_56"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_56"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_56"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg72: index, %arg73: index, %arg74: index, %arg75: index, %arg76: memref<17x129xf32>, %arg77: memref<129x80xf32>, %arg78: memref<17x80xf32>, %arg79: memref<17x80xf32>):
      "air.segment"(%arg76, %arg77, %arg78, %arg79) ({
      ^bb0(%arg80: memref<17x129xf32>, %arg81: memref<129x80xf32>, %arg82: memref<17x80xf32>, %arg83: memref<17x80xf32>):
        %200 = "arith.constant"() <{value = 1 : index}> : () -> index
        "air.herd"(%200, %200, %arg80, %arg81, %arg82, %arg83) ({
        ^bb0(%arg84: index, %arg85: index, %arg86: index, %arg87: index, %arg88: memref<17x129xf32>, %arg89: memref<129x80xf32>, %arg90: memref<17x80xf32>, %arg91: memref<17x80xf32>):
          %201 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<256xf32, 2 : i32>
          %202 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.8.32.loops.8.32"} : () -> memref<256xf32, 2 : i32>
          %203 = "air.wait_all"() : () -> !air.async.token
          %204 = "arith.constant"() <{value = 0 : index}> : () -> index
          %205 = "arith.constant"() <{value = 2 : index}> : () -> index
          %206 = "arith.constant"() <{value = 1 : index}> : () -> index
          %207 = "scf.for"(%204, %205, %206, %203) ({
          ^bb0(%arg92: index, %arg93: !air.async.token):
            %208 = "arith.constant"() <{value = 32 : index}> : () -> index
            %209 = "arith.muli"(%arg92, %208) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %210 = "arith.constant"() <{value = 32 : index}> : () -> index
            %211 = "arith.muli"(%arg92, %210) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %212 = "arith.constant"() <{value = 32 : index}> : () -> index
            %213 = "arith.muli"(%arg92, %212) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %214 = "memref.reinterpret_cast"(%201) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 57 : i64, orbit.storage = "Y"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %215 = "memref.reinterpret_cast"(%202) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 57 : i64, orbit.storage = "intermediate"} : (memref<256xf32, 2 : i32>) -> memref<8x32xf32, strided<[32, 1]>, 2 : i32>
            %216 = "arith.constant"() <{value = 0 : index}> : () -> index
            %217 = "arith.addi"(%216, %213) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %218 = "air.dma_memcpy_nd"(%arg93, %215, %arg91, %217) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 57 : i64, orbit.source_copies = array<i64: 97>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 192>, orbit.transfer = "host_to_l1", orbit.transfer_event = 162 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 8, -9223372036854775808>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<8x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x80xf32>, index) -> !air.async.token
            "air.wait_all"(%218) {orbit.computation_event = 163 : i64, orbit.phase = 57 : i64, orbit.phase_dependencies = array<i64: 56>, orbit.read_copies = array<i64: 192>, orbit.task = "scale", orbit.write_copies = array<i64: 193>} : (!air.async.token) -> ()
            %219 = "memref.cast"(%214) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %220 = "memref.cast"(%215) : (memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<8x32xf32, 2 : i32>
            %221 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
            %222 = "arith.constant"() <{value = 8 : index}> : () -> index
            %223 = "arith.constant"() <{value = 16 : index}> : () -> index
            %224 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%222, %223, %224) ({
            ^bb0(%arg94: index):
              %229 = "arith.constant"() <{value = 0 : index}> : () -> index
              %230 = "arith.constant"() <{value = 32 : index}> : () -> index
              %231 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%229, %230, %231) ({
              ^bb0(%arg95: index):
                %232 = "arith.addi"(%arg95, %209) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %233 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
                %234 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %235 = "arith.constant"() <{value = 8 : index}> : () -> index
                %236 = "arith.subi"(%arg94, %235) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %237 = "arith.subi"(%232, %213) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %238 = "vector.transfer_read"(%220, %236, %237, %234) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %239 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %240 = "vector.extract"(%238) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %241 = "vector.extract"(%233) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %242 = "func.call"(%240, %241) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %243 = "vector.insert"(%242, %239) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %244 = "vector.extract"(%238) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %245 = "vector.extract"(%233) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %246 = "func.call"(%244, %245) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %247 = "vector.insert"(%246, %243) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %248 = "vector.extract"(%238) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %249 = "vector.extract"(%233) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %250 = "func.call"(%248, %249) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %251 = "vector.insert"(%250, %247) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %252 = "vector.extract"(%238) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %253 = "vector.extract"(%233) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %254 = "func.call"(%252, %253) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %255 = "vector.insert"(%254, %251) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %256 = "vector.extract"(%238) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %257 = "vector.extract"(%233) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %258 = "func.call"(%256, %257) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %259 = "vector.insert"(%258, %255) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %260 = "vector.extract"(%238) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %261 = "vector.extract"(%233) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %262 = "func.call"(%260, %261) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %263 = "vector.insert"(%262, %259) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %264 = "vector.extract"(%238) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %265 = "vector.extract"(%233) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %266 = "func.call"(%264, %265) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %267 = "vector.insert"(%266, %263) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %268 = "vector.extract"(%238) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %269 = "vector.extract"(%233) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %270 = "func.call"(%268, %269) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %271 = "vector.insert"(%270, %267) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %272 = "arith.constant"() <{value = 8 : index}> : () -> index
                %273 = "arith.subi"(%arg94, %272) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %274 = "arith.subi"(%232, %211) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%271, %219, %273, %274) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %225 = "arith.constant"() <{value = 0 : index}> : () -> index
            %226 = "arith.addi"(%225, %211) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %227 = "air.dma_memcpy_nd"(%arg93, %arg90, %226, %214) {operandSegmentSizes = array<i32: 1, 1, 1, 0, 0, 1, 0, 0, 0>, orbit.phase = 57 : i64, orbit.source_copies = array<i64: 193>, orbit.storage = "Y", orbit.target_copies = array<i64: 194>, orbit.transfer = "l1_to_host", orbit.transfer_event = 164 : i64, static_dst_offsets = array<i64: 8, -9223372036854775808>, static_dst_sizes = array<i64: 8, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, index, memref<8x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
            %228 = "air.wait_all"(%227) : (!air.async.token) -> !air.async.token
            "scf.yield"(%228) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 2 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          "air.wait_all"(%207) : (!air.async.token) -> ()
          "memref.dealloc"(%201) : (memref<256xf32, 2 : i32>) -> ()
          "memref.dealloc"(%202) : (memref<256xf32, 2 : i32>) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_57"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_57"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_57"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg50: index, %arg51: index, %arg52: index, %arg53: index, %arg54: memref<17x129xf32>, %arg55: memref<129x80xf32>, %arg56: memref<17x80xf32>, %arg57: memref<17x80xf32>):
      "air.segment"(%arg54, %arg55, %arg56, %arg57) ({
      ^bb0(%arg58: memref<17x129xf32>, %arg59: memref<129x80xf32>, %arg60: memref<17x80xf32>, %arg61: memref<17x80xf32>):
        %138 = "arith.constant"() <{value = 1 : index}> : () -> index
        "air.herd"(%138, %138, %arg58, %arg59, %arg60, %arg61) ({
        ^bb0(%arg62: index, %arg63: index, %arg64: index, %arg65: index, %arg66: memref<17x129xf32>, %arg67: memref<129x80xf32>, %arg68: memref<17x80xf32>, %arg69: memref<17x80xf32>):
          %139 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<128xf32, 2 : i32>
          %140 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.8.16.loops.8.16"} : () -> memref<128xf32, 2 : i32>
          %141 = "air.wait_all"() : () -> !air.async.token
          %142 = "memref.reinterpret_cast"(%139) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 59 : i64, orbit.storage = "Y"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %143 = "memref.reinterpret_cast"(%140) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 8, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 59 : i64, orbit.storage = "intermediate"} : (memref<128xf32, 2 : i32>) -> memref<8x16xf32, strided<[16, 1]>, 2 : i32>
          %144 = "air.dma_memcpy_nd"(%141, %143, %arg69) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 59 : i64, orbit.source_copies = array<i64: 131>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 198>, orbit.transfer = "host_to_l1", orbit.transfer_event = 168 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 8, 64>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<8x16xf32, strided<[16, 1]>, 2 : i32>, memref<17x80xf32>) -> !air.async.token
          "air.wait_all"(%144) {orbit.computation_event = 169 : i64, orbit.phase = 59 : i64, orbit.phase_dependencies = array<i64: 58>, orbit.read_copies = array<i64: 198>, orbit.task = "scale", orbit.write_copies = array<i64: 199>} : (!air.async.token) -> ()
          %145 = "memref.cast"(%142) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %146 = "memref.cast"(%143) : (memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<8x16xf32, 2 : i32>
          %147 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
          %148 = "arith.constant"() <{value = 8 : index}> : () -> index
          %149 = "arith.constant"() <{value = 16 : index}> : () -> index
          %150 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%148, %149, %150) ({
          ^bb0(%arg70: index):
            %153 = "arith.constant"() <{value = 64 : index}> : () -> index
            %154 = "arith.constant"() <{value = 80 : index}> : () -> index
            %155 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%153, %154, %155) ({
            ^bb0(%arg71: index):
              %156 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
              %157 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
              %158 = "arith.constant"() <{value = 8 : index}> : () -> index
              %159 = "arith.subi"(%arg70, %158) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %160 = "arith.constant"() <{value = 64 : index}> : () -> index
              %161 = "arith.subi"(%arg71, %160) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %162 = "vector.transfer_read"(%146, %159, %161, %157) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<8x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
              %163 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
              %164 = "vector.extract"(%162) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %165 = "vector.extract"(%156) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %166 = "func.call"(%164, %165) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %167 = "vector.insert"(%166, %163) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %168 = "vector.extract"(%162) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %169 = "vector.extract"(%156) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %170 = "func.call"(%168, %169) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %171 = "vector.insert"(%170, %167) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %172 = "vector.extract"(%162) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %173 = "vector.extract"(%156) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %174 = "func.call"(%172, %173) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %175 = "vector.insert"(%174, %171) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %176 = "vector.extract"(%162) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %177 = "vector.extract"(%156) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %178 = "func.call"(%176, %177) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %179 = "vector.insert"(%178, %175) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %180 = "vector.extract"(%162) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %181 = "vector.extract"(%156) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %182 = "func.call"(%180, %181) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %183 = "vector.insert"(%182, %179) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %184 = "vector.extract"(%162) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %185 = "vector.extract"(%156) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %186 = "func.call"(%184, %185) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %187 = "vector.insert"(%186, %183) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %188 = "vector.extract"(%162) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %189 = "vector.extract"(%156) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %190 = "func.call"(%188, %189) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %191 = "vector.insert"(%190, %187) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %192 = "vector.extract"(%162) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %193 = "vector.extract"(%156) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %194 = "func.call"(%192, %193) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %195 = "vector.insert"(%194, %191) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %196 = "arith.constant"() <{value = 8 : index}> : () -> index
              %197 = "arith.subi"(%arg70, %196) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %198 = "arith.constant"() <{value = 64 : index}> : () -> index
              %199 = "arith.subi"(%arg71, %198) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "vector.transfer_write"(%195, %145, %197, %199) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<8x16xf32, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %151 = "air.dma_memcpy_nd"(%141, %arg68, %142) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 59 : i64, orbit.source_copies = array<i64: 199>, orbit.storage = "Y", orbit.target_copies = array<i64: 200>, orbit.transfer = "l1_to_host", orbit.transfer_event = 170 : i64, static_dst_offsets = array<i64: 8, 64>, static_dst_sizes = array<i64: 8, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 8, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<8x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %152 = "air.wait_all"(%151) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%152) : (!air.async.token) -> ()
          "memref.dealloc"(%139) : (memref<128xf32, 2 : i32>) -> ()
          "memref.dealloc"(%140) : (memref<128xf32, 2 : i32>) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_59"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_59"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_59"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg26: index, %arg27: index, %arg28: index, %arg29: index, %arg30: memref<17x129xf32>, %arg31: memref<129x80xf32>, %arg32: memref<17x80xf32>, %arg33: memref<17x80xf32>):
      "air.segment"(%arg30, %arg31, %arg32, %arg33) ({
      ^bb0(%arg34: memref<17x129xf32>, %arg35: memref<129x80xf32>, %arg36: memref<17x80xf32>, %arg37: memref<17x80xf32>):
        %63 = "arith.constant"() <{value = 1 : index}> : () -> index
        "air.herd"(%63, %63, %arg34, %arg35, %arg36, %arg37) ({
        ^bb0(%arg38: index, %arg39: index, %arg40: index, %arg41: index, %arg42: memref<17x129xf32>, %arg43: memref<129x80xf32>, %arg44: memref<17x80xf32>, %arg45: memref<17x80xf32>):
          %64 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<32xf32, 2 : i32>
          %65 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.1.32.loops.1.32"} : () -> memref<32xf32, 2 : i32>
          %66 = "air.wait_all"() : () -> !air.async.token
          %67 = "arith.constant"() <{value = 0 : index}> : () -> index
          %68 = "arith.constant"() <{value = 2 : index}> : () -> index
          %69 = "arith.constant"() <{value = 1 : index}> : () -> index
          %70 = "scf.for"(%67, %68, %69, %66) ({
          ^bb0(%arg46: index, %arg47: !air.async.token):
            %71 = "arith.constant"() <{value = 32 : index}> : () -> index
            %72 = "arith.muli"(%arg46, %71) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %73 = "arith.constant"() <{value = 32 : index}> : () -> index
            %74 = "arith.muli"(%arg46, %73) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %75 = "arith.constant"() <{value = 32 : index}> : () -> index
            %76 = "arith.muli"(%arg46, %75) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %77 = "memref.reinterpret_cast"(%64) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 60 : i64, orbit.storage = "Y"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %78 = "memref.reinterpret_cast"(%65) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 32>, static_strides = array<i64: 32, 1>}> {orbit.phase = 60 : i64, orbit.storage = "intermediate"} : (memref<32xf32, 2 : i32>) -> memref<1x32xf32, strided<[32, 1]>, 2 : i32>
            %79 = "arith.constant"() <{value = 0 : index}> : () -> index
            %80 = "arith.addi"(%79, %76) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %81 = "air.dma_memcpy_nd"(%arg47, %78, %arg45, %80) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 1, 0, 0>, orbit.phase = 60 : i64, orbit.source_copies = array<i64: 148>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 201>, orbit.transfer = "host_to_l1", orbit.transfer_event = 171 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 32, 1>, static_src_offsets = array<i64: 16, -9223372036854775808>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x32xf32, strided<[32, 1]>, 2 : i32>, memref<17x80xf32>, index) -> !air.async.token
            "air.wait_all"(%81) {orbit.computation_event = 172 : i64, orbit.phase = 60 : i64, orbit.phase_dependencies = array<i64: 59>, orbit.read_copies = array<i64: 201>, orbit.task = "scale", orbit.write_copies = array<i64: 202>} : (!air.async.token) -> ()
            %82 = "memref.cast"(%77) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %83 = "memref.cast"(%78) : (memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> memref<1x32xf32, 2 : i32>
            %84 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
            %85 = "arith.constant"() <{value = 16 : index}> : () -> index
            %86 = "arith.constant"() <{value = 17 : index}> : () -> index
            %87 = "arith.constant"() <{value = 1 : index}> : () -> index
            "scf.for"(%85, %86, %87) ({
            ^bb0(%arg48: index):
              %92 = "arith.constant"() <{value = 0 : index}> : () -> index
              %93 = "arith.constant"() <{value = 32 : index}> : () -> index
              %94 = "arith.constant"() <{value = 8 : index}> : () -> index
              "scf.for"(%92, %93, %94) ({
              ^bb0(%arg49: index):
                %95 = "arith.addi"(%arg49, %72) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %96 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
                %97 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
                %98 = "arith.constant"() <{value = 16 : index}> : () -> index
                %99 = "arith.subi"(%arg48, %98) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %100 = "arith.subi"(%95, %76) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %101 = "vector.transfer_read"(%83, %99, %100, %97) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x32xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
                %102 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
                %103 = "vector.extract"(%101) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %104 = "vector.extract"(%96) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
                %105 = "func.call"(%103, %104) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %106 = "vector.insert"(%105, %102) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %107 = "vector.extract"(%101) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %108 = "vector.extract"(%96) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
                %109 = "func.call"(%107, %108) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %110 = "vector.insert"(%109, %106) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %111 = "vector.extract"(%101) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %112 = "vector.extract"(%96) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
                %113 = "func.call"(%111, %112) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %114 = "vector.insert"(%113, %110) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %115 = "vector.extract"(%101) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %116 = "vector.extract"(%96) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
                %117 = "func.call"(%115, %116) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %118 = "vector.insert"(%117, %114) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %119 = "vector.extract"(%101) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %120 = "vector.extract"(%96) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
                %121 = "func.call"(%119, %120) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %122 = "vector.insert"(%121, %118) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %123 = "vector.extract"(%101) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %124 = "vector.extract"(%96) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
                %125 = "func.call"(%123, %124) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %126 = "vector.insert"(%125, %122) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %127 = "vector.extract"(%101) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %128 = "vector.extract"(%96) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
                %129 = "func.call"(%127, %128) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %130 = "vector.insert"(%129, %126) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %131 = "vector.extract"(%101) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %132 = "vector.extract"(%96) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
                %133 = "func.call"(%131, %132) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
                %134 = "vector.insert"(%133, %130) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
                %135 = "arith.constant"() <{value = 16 : index}> : () -> index
                %136 = "arith.subi"(%arg48, %135) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                %137 = "arith.subi"(%95, %74) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
                "vector.transfer_write"(%134, %82, %136, %137) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x32xf32, 2 : i32>, index, index) -> ()
                "scf.yield"() : () -> ()
              }) : (index, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            %88 = "arith.constant"() <{value = 0 : index}> : () -> index
            %89 = "arith.addi"(%88, %74) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
            %90 = "air.dma_memcpy_nd"(%arg47, %arg44, %89, %77) {operandSegmentSizes = array<i32: 1, 1, 1, 0, 0, 1, 0, 0, 0>, orbit.phase = 60 : i64, orbit.source_copies = array<i64: 202>, orbit.storage = "Y", orbit.target_copies = array<i64: 203>, orbit.transfer = "l1_to_host", orbit.transfer_event = 173 : i64, static_dst_offsets = array<i64: 16, -9223372036854775808>, static_dst_sizes = array<i64: 1, 32>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 32>, static_src_strides = array<i64: 32, 1>} : (!air.async.token, memref<17x80xf32>, index, memref<1x32xf32, strided<[32, 1]>, 2 : i32>) -> !air.async.token
            %91 = "air.wait_all"(%90) : (!air.async.token) -> !air.async.token
            "scf.yield"(%91) : (!air.async.token) -> ()
          }) {orbit.compressed_phases = 2 : i64} : (index, index, index, !air.async.token) -> !air.async.token
          "air.wait_all"(%70) : (!air.async.token) -> ()
          "memref.dealloc"(%64) : (memref<32xf32, 2 : i32>) -> ()
          "memref.dealloc"(%65) : (memref<32xf32, 2 : i32>) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_60"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_60"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_60"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "air.launch"(%0, %0, %arg0, %arg1, %arg2, %arg3) ({
    ^bb0(%arg4: index, %arg5: index, %arg6: index, %arg7: index, %arg8: memref<17x129xf32>, %arg9: memref<129x80xf32>, %arg10: memref<17x80xf32>, %arg11: memref<17x80xf32>):
      "air.segment"(%arg8, %arg9, %arg10, %arg11) ({
      ^bb0(%arg12: memref<17x129xf32>, %arg13: memref<129x80xf32>, %arg14: memref<17x80xf32>, %arg15: memref<17x80xf32>):
        %1 = "arith.constant"() <{value = 1 : index}> : () -> index
        "air.herd"(%1, %1, %arg12, %arg13, %arg14, %arg15) ({
        ^bb0(%arg16: index, %arg17: index, %arg18: index, %arg19: index, %arg20: memref<17x129xf32>, %arg21: memref<129x80xf32>, %arg22: memref<17x80xf32>, %arg23: memref<17x80xf32>):
          %2 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 2 : i64, orbit.tile_pool = "storage-2.data"} : () -> memref<16xf32, 2 : i32>
          %3 = "memref.alloc"() <{operandSegmentSizes = array<i32: 0, 0>}> {orbit.storage_index = 3 : i64, orbit.tile_pool = "storage-3.data.input.1.16.loops.1.16"} : () -> memref<16xf32, 2 : i32>
          %4 = "air.wait_all"() : () -> !air.async.token
          %5 = "memref.reinterpret_cast"(%2) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 62 : i64, orbit.storage = "Y"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %6 = "memref.reinterpret_cast"(%3) <{operandSegmentSizes = array<i32: 1, 0, 0, 0>, static_offsets = array<i64: 0>, static_sizes = array<i64: 1, 16>, static_strides = array<i64: 16, 1>}> {orbit.phase = 62 : i64, orbit.storage = "intermediate"} : (memref<16xf32, 2 : i32>) -> memref<1x16xf32, strided<[16, 1]>, 2 : i32>
          %7 = "air.dma_memcpy_nd"(%4, %6, %arg23) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 62 : i64, orbit.source_copies = array<i64: 182>, orbit.storage = "intermediate", orbit.target_copies = array<i64: 207>, orbit.transfer = "host_to_l1", orbit.transfer_event = 177 : i64, static_dst_offsets = array<i64: 0, 0>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 16, 1>, static_src_offsets = array<i64: 16, 64>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 80, 1>} : (!air.async.token, memref<1x16xf32, strided<[16, 1]>, 2 : i32>, memref<17x80xf32>) -> !air.async.token
          "air.wait_all"(%7) {orbit.computation_event = 178 : i64, orbit.phase = 62 : i64, orbit.phase_dependencies = array<i64: 61>, orbit.read_copies = array<i64: 207>, orbit.task = "scale", orbit.write_copies = array<i64: 208>} : (!air.async.token) -> ()
          %8 = "memref.cast"(%5) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %9 = "memref.cast"(%6) : (memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> memref<1x16xf32, 2 : i32>
          %10 = "arith.constant"() <{value = 5.000000e-01 : f32}> : () -> f32
          %11 = "arith.constant"() <{value = 16 : index}> : () -> index
          %12 = "arith.constant"() <{value = 17 : index}> : () -> index
          %13 = "arith.constant"() <{value = 1 : index}> : () -> index
          "scf.for"(%11, %12, %13) ({
          ^bb0(%arg24: index):
            %16 = "arith.constant"() <{value = 64 : index}> : () -> index
            %17 = "arith.constant"() <{value = 80 : index}> : () -> index
            %18 = "arith.constant"() <{value = 8 : index}> : () -> index
            "scf.for"(%16, %17, %18) ({
            ^bb0(%arg25: index):
              %19 = "arith.constant"() <{value = dense<5.000000e-01> : vector<8xf32>}> : () -> vector<8xf32>
              %20 = "arith.constant"() <{value = 0.000000e+00 : f32}> : () -> f32
              %21 = "arith.constant"() <{value = 16 : index}> : () -> index
              %22 = "arith.subi"(%arg24, %21) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %23 = "arith.constant"() <{value = 64 : index}> : () -> index
              %24 = "arith.subi"(%arg25, %23) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %25 = "vector.transfer_read"(%9, %22, %24, %20) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 2, 1, 0>, permutation_map = #map}> : (memref<1x16xf32, 2 : i32>, index, index, f32) -> vector<8xf32>
              %26 = "arith.constant"() <{value = dense<0.000000e+00> : vector<8xf32>}> : () -> vector<8xf32>
              %27 = "vector.extract"(%25) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %28 = "vector.extract"(%19) <{static_position = array<i64: 0>}> : (vector<8xf32>) -> f32
              %29 = "func.call"(%27, %28) <{callee = @__mulsf3}> {orbit.scalarized_lane = 0 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %30 = "vector.insert"(%29, %26) <{static_position = array<i64: 0>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %31 = "vector.extract"(%25) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %32 = "vector.extract"(%19) <{static_position = array<i64: 1>}> : (vector<8xf32>) -> f32
              %33 = "func.call"(%31, %32) <{callee = @__mulsf3}> {orbit.scalarized_lane = 1 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %34 = "vector.insert"(%33, %30) <{static_position = array<i64: 1>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %35 = "vector.extract"(%25) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %36 = "vector.extract"(%19) <{static_position = array<i64: 2>}> : (vector<8xf32>) -> f32
              %37 = "func.call"(%35, %36) <{callee = @__mulsf3}> {orbit.scalarized_lane = 2 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %38 = "vector.insert"(%37, %34) <{static_position = array<i64: 2>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %39 = "vector.extract"(%25) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %40 = "vector.extract"(%19) <{static_position = array<i64: 3>}> : (vector<8xf32>) -> f32
              %41 = "func.call"(%39, %40) <{callee = @__mulsf3}> {orbit.scalarized_lane = 3 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %42 = "vector.insert"(%41, %38) <{static_position = array<i64: 3>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %43 = "vector.extract"(%25) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %44 = "vector.extract"(%19) <{static_position = array<i64: 4>}> : (vector<8xf32>) -> f32
              %45 = "func.call"(%43, %44) <{callee = @__mulsf3}> {orbit.scalarized_lane = 4 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %46 = "vector.insert"(%45, %42) <{static_position = array<i64: 4>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %47 = "vector.extract"(%25) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %48 = "vector.extract"(%19) <{static_position = array<i64: 5>}> : (vector<8xf32>) -> f32
              %49 = "func.call"(%47, %48) <{callee = @__mulsf3}> {orbit.scalarized_lane = 5 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %50 = "vector.insert"(%49, %46) <{static_position = array<i64: 5>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %51 = "vector.extract"(%25) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %52 = "vector.extract"(%19) <{static_position = array<i64: 6>}> : (vector<8xf32>) -> f32
              %53 = "func.call"(%51, %52) <{callee = @__mulsf3}> {orbit.scalarized_lane = 6 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %54 = "vector.insert"(%53, %50) <{static_position = array<i64: 6>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %55 = "vector.extract"(%25) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %56 = "vector.extract"(%19) <{static_position = array<i64: 7>}> : (vector<8xf32>) -> f32
              %57 = "func.call"(%55, %56) <{callee = @__mulsf3}> {orbit.scalarized_lane = 7 : i64, orbit.scalarized_operation = "arith.mulf"} : (f32, f32) -> f32
              %58 = "vector.insert"(%57, %54) <{static_position = array<i64: 7>}> : (f32, vector<8xf32>) -> vector<8xf32>
              %59 = "arith.constant"() <{value = 16 : index}> : () -> index
              %60 = "arith.subi"(%arg24, %59) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              %61 = "arith.constant"() <{value = 64 : index}> : () -> index
              %62 = "arith.subi"(%arg25, %61) <{overflowFlags = #arith.overflow<none>}> : (index, index) -> index
              "vector.transfer_write"(%58, %8, %60, %62) <{in_bounds = [false], operandSegmentSizes = array<i32: 1, 1, 2, 0>, permutation_map = #map}> : (vector<8xf32>, memref<1x16xf32, 2 : i32>, index, index) -> ()
              "scf.yield"() : () -> ()
            }) : (index, index, index) -> ()
            "scf.yield"() : () -> ()
          }) : (index, index, index) -> ()
          %14 = "air.dma_memcpy_nd"(%4, %arg22, %5) {operandSegmentSizes = array<i32: 1, 1, 0, 0, 0, 1, 0, 0, 0>, orbit.phase = 62 : i64, orbit.source_copies = array<i64: 208>, orbit.storage = "Y", orbit.target_copies = array<i64: 209>, orbit.transfer = "l1_to_host", orbit.transfer_event = 179 : i64, static_dst_offsets = array<i64: 16, 64>, static_dst_sizes = array<i64: 1, 16>, static_dst_strides = array<i64: 80, 1>, static_src_offsets = array<i64: 0, 0>, static_src_sizes = array<i64: 1, 16>, static_src_strides = array<i64: 16, 1>} : (!air.async.token, memref<17x80xf32>, memref<1x16xf32, strided<[16, 1]>, 2 : i32>) -> !air.async.token
          %15 = "air.wait_all"(%14) : (!air.async.token) -> !air.async.token
          "air.wait_all"(%15) : (!air.async.token) -> ()
          "memref.dealloc"(%2) : (memref<16xf32, 2 : i32>) -> ()
          "memref.dealloc"(%3) : (memref<16xf32, 2 : i32>) -> ()
          "air.herd_terminator"() : () -> ()
        }) {operandSegmentSizes = array<i32: 0, 2, 4>, orbit.mapping_strategy = "serial-tiled", sym_name = "orbit_herd_62"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
        "air.segment_terminator"() : () -> ()
      }) {operandSegmentSizes = array<i32: 0, 0, 4>, sym_name = "orbit_segment_62"} : (memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
      "air.launch_terminator"() : () -> ()
    }) {operandSegmentSizes = array<i32: 0, 2, 4>, sym_name = "orbit_launch_62"} : (index, index, memref<17x129xf32>, memref<129x80xf32>, memref<17x80xf32>, memref<17x80xf32>) -> ()
    "func.return"() : () -> ()
  }) : () -> ()
}) {orbit.cost_status = "uncalibrated-direct-air", orbit.data_organization = "phase-local", orbit.data_organization_scope = "phase-local input copies; source output/reduction lifetime preserved", orbit.f32_lane_legalization = "scalar-product-vector-add-f32; scalar compiler-rt mul/div; source-ordered vector add/sub; no FMA/BF16", orbit.mapping_plan = "c14485d41c0cee6086df950cdc3c0ce4c35696c31598a72f9bb26b5725ef4cea", orbit.source_fingerprint = "912511a293a64cce8e0d6c281bea7fa9b2ada1f653348173aee833f4c600a053"} : () -> ()

