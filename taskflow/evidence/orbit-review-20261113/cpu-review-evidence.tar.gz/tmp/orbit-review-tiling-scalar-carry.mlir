module {
 func.func @inplace_alias(%state: memref<2x2xi32> {amoeba.noalias}, %input: memref<2x2xi32> {amoeba.noalias}) {
  %done = taskflow.task @update will_reads(%input : memref<2x2xi32>) will_writes(%state : memref<2x2xi32>) [original_read_memrefs(%input : memref<2x2xi32>), original_write_memrefs(%state : memref<2x2xi32>)] : (memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
   ^bb0(%in: memref<2x2xi32>, %write: memref<2x2xi32>):
    %z = arith.constant 0 : index
    %o = arith.constant 1 : index
    %two = arith.constant 2 : index
    %init = arith.constant 0 : i32
    %m = taskflow.counter from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
    %n = taskflow.counter parent(%m : index) from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
    %result = neura.kernel inputs(%write, %in : memref<2x2xi32>, memref<2x2xi32>) iter_args_init(%init : i32) attributes {accelerator = "neura"} {
     ^bb0(%out: memref<2x2xi32>, %arg: memref<2x2xi32>, %acc: i32):
      %zero = arith.constant 0 : index
      %one = arith.constant 1 : index
      %bound = arith.constant 2 : index
      %i = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
      %j = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
      %v = memref.load %arg[%j, %i] : memref<2x2xi32>
      %sum = arith.addi %acc, %v : i32
      memref.store %sum, %out[%i, %j] : memref<2x2xi32>
      neura.yield iter_args_next(%sum : i32) results(%sum : i32)
    } : i32
    taskflow.yield done_writes(%write : memref<2x2xi32>)
  }
  return
 }
}
