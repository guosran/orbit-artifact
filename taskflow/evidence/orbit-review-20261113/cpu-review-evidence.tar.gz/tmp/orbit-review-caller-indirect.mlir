module {
 func.func @target(%n: index, %a: memref<4xi32>, %b: memref<4xi32>) {
 return
 }
 func.func @main() {
 %n = arith.constant 4 : index
 %a = memref.alloc() : memref<4xi32>
 %b = memref.alloc() : memref<4xi32>
 func.call @target(%n, %a, %b) : (index, memref<4xi32>, memref<4xi32>) -> ()
 func.call @other() : () -> ()
 return
 }
 func.func private @other() {
 %n = arith.constant 4 : index
 %a = memref.alloc() : memref<4xi32>
 %f = func.constant @target : (index, memref<4xi32>, memref<4xi32>) -> ()
 func.call_indirect %f(%n, %a, %a) : (index, memref<4xi32>, memref<4xi32>) -> ()
 return
 }
}
