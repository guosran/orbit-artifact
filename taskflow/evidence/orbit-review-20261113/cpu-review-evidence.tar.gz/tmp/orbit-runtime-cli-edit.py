from pathlib import Path
p=Path('tools/taskflow-opt/taskflow-opt.cpp');s=p.read_text().replace('#include "Taskflow/ProgramJointAIR.h"','#include "Taskflow/ProgramJointAIR.h"\n#include "Taskflow/ProgramMatrixRuntime.h"');s=s.replace('static cl::opt<std::string> airOutput(','''static cl::opt<std::string> programRuntimeContract(
    "realize-program-runtime",
    cl::desc("Realize and check final generic NPU AIE using the sealed selected "
             "transfer contract; write --air-output and --implementation-output"));
static cl::opt<std::string> airOutput(''');s=s.replace('if (lowerAIR || !publicLower.empty()', 'if (!programRuntimeContract.empty() || lowerAIR || !publicLower.empty()');needle='  HeterogeneousAIREmitter emitSelectedRegion;';insert='''  if (!programRuntimeContract.empty()) {
#ifdef ORBIT_ENABLE_AIR
    if (airOutput.empty() || implementationOutput.empty())
      return fatal("runtime realization requires IR and proof output paths");
    auto contract = readJSON(programRuntimeContract);
    if (!contract)
      return fatal(llvm::toString(contract.takeError()));
    // AIE dialect properties are preserved by generic parsing; installed
    // aie-opt performs the registered dialect verification in the next stage.
    mlir::ParserConfig parserConfig(&context, /*verifyAfterParse=*/false);
    auto actual = mlir::parseSourceString<mlir::ModuleOp>(text, parserConfig);
    mlir::OwningOpRef<mlir::ModuleOp> realized;
    llvm::json::Value proof = nullptr;
    if (!actual || !realizeProgramMatrixRuntime(*contract, *actual, realized,
                                                proof, error))
      return fatal(error.empty() ? "invalid generic NPU AIE" : error);
    std::error_code ec;
    llvm::raw_fd_ostream out(airOutput, ec);
    if (ec)
      return fatal(ec.message());
    realized->print(out, mlir::OpPrintingFlags().printGenericOpForm());
    out << "\\n";
    out.close();
    if (out.has_error()) {
      error = out.error().message();
      out.clear_error();
      return fatal(error);
    }
    return writeJSON(implementationOutput, proof) ? 0 : fatal(error);
#else
    return fatal("runtime realization requires ORBIT_ENABLE_AIR=ON");
#endif
  }
''';assert needle in s;s=s.replace(needle,insert+needle);needle='''    if (!writeText(path,
''';insert='''    std::vector<int64_t> abiStorageIndices;
    for (const auto &entry : *physical.getAsObject()->getArray("abi_storage_indices"))
      abiStorageIndices.push_back(*entry.getAsInteger());
    auto runtimeContract = serializeProgramMatrixRuntimeContract(
        plan.communication, abiStorageIndices, reason);
    if (runtimeContract.getAsNull())
      return false;
    (*physical.getAsObject())["runtime_contract_sha256"] =
        staticFingerprint(runtimeContract);
    if (!writeJSON(path + ".runtime-contract.json", runtimeContract))
      return false;
''';assert needle in s;s=s.replace(needle,insert+needle,1);p.write_text(s)
