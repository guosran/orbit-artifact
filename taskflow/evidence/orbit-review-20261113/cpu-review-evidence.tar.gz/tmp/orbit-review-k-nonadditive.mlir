module {
 func.func @nonadditive(%a: memref<2x2xi32> {amoeba.noalias}, %b: memref<2x2xi32> {amoeba.noalias}, %c: memref<2x2xi32> {amoeba.noalias}, %t: memref<2x2xi32> {amoeba.noalias}, %e: memref<2x2xi32> {amoeba.noalias}, %d: memref<2x2xi32> {amoeba.noalias}) {
  %p = taskflow.task @producer will_reads(%a, %b, %c : memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) will_writes(%t : memref<2x2xi32>) [original_read_memrefs(%a, %b, %c : memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>), original_write_memrefs(%t : memref<2x2xi32>)] : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
   ^bb0(%aa: memref<2x2xi32>, %bb: memref<2x2xi32>, %cc: memref<2x2xi32>, %tt: memref<2x2xi32>):
    %z = arith.constant 0 : index
    %o = arith.constant 1 : index
    %two = arith.constant 2 : index
    %m = taskflow.counter from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
    %n = taskflow.counter parent(%m : index) from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
    neura.kernel inputs(%aa, %bb, %cc, %tt : memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) attributes {accelerator = "neura"} {
     ^bb0(%ka: memref<2x2xi32>, %kb: memref<2x2xi32>, %kc: memref<2x2xi32>, %kt: memref<2x2xi32>):
      %zero = arith.constant 0 : index
      %one = arith.constant 1 : index
      %bound = arith.constant 2 : index
      %i = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
      %j = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
      %init = memref.load %kc[%i, %j] : memref<2x2xi32>
      %sum = scf.for %k = %zero to %bound step %one iter_args(%acc = %init) -> (i32) {
       %av = memref.load %ka[%i, %k] : memref<2x2xi32>
       %bv = memref.load %kb[%k, %j] : memref<2x2xi32>
       %prod = arith.muli %av, %bv : i32
       %next = arith.muli %acc, %prod : i32
       scf.yield %next : i32
      }
      memref.store %sum, %kt[%i, %j] : memref<2x2xi32>
      neura.yield {yield_type = "void"}
    }
    taskflow.yield done_writes(%tt : memref<2x2xi32>)
  }
  %out = taskflow.task @consumer will_reads(%p, %e : memref<2x2xi32>, memref<2x2xi32>) will_writes(%d : memref<2x2xi32>) [original_read_memrefs(%t, %e : memref<2x2xi32>, memref<2x2xi32>), original_write_memrefs(%d : memref<2x2xi32>)] : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
   ^bb0(%r: memref<2x2xi32>, %unused: memref<2x2xi32>, %w: memref<2x2xi32>):
    memref.copy %r, %w : memref<2x2xi32> to memref<2x2xi32>
    taskflow.yield done_writes(%w : memref<2x2xi32>)
  }
  return
 }
}
