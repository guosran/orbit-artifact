module {
 func.func @feedback(%a: memref<2x4xi32> {amoeba.noalias}, %out: memref<2x4xi32> {amoeba.noalias}) -> memref<2x4xi32> {
 %done = taskflow.task @producer will_reads(%a : memref<2x4xi32>) will_writes(%out : memref<2x4xi32>) [original_read_memrefs(%a : memref<2x4xi32>), original_write_memrefs(%out : memref<2x4xi32>)] : (memref<2x4xi32>, memref<2x4xi32>) -> memref<2x4xi32> {
 ^bb0(%read: memref<2x4xi32>, %write: memref<2x4xi32>):
 %z = arith.constant 0 : index
 %o = arith.constant 1 : index
 %two = arith.constant 2 : index
 %four = arith.constant 4 : index
 %ten = arith.constant 10 : i32
 %m = taskflow.counter from %z to %two step %o : index
 %n = taskflow.counter parent(%m : index) from %z to %four step %o : index
 "taskflow.hyperblock"(%m, %n) <{operandSegmentSizes = array<i32: 2, 0>}> ({
 ^bb0(%i: index, %j: index):
 %prior = memref.load %write[%z, %z] : memref<2x4xi32>
 %scaled = arith.muli %prior, %ten : i32
 %v = memref.load %read[%i, %j] : memref<2x4xi32>
 %next = arith.addi %scaled, %v : i32
 memref.store %next, %write[%z, %z] : memref<2x4xi32>
 "taskflow.hyperblock.yield"() <{operandSegmentSizes = array<i32: 0, 0>}> : () -> ()
 }) : (index, index) -> ()
 taskflow.yield done_writes(%write : memref<2x4xi32>)
 }
 return %done : memref<2x4xi32>
 }
}
