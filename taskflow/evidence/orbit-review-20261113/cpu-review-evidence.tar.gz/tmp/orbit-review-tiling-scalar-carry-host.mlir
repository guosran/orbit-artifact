module {
  func.func @inplace_alias(%arg0: memref<2x2xi32> {amoeba.noalias}, %arg1: memref<2x2xi32> {amoeba.noalias}) {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0_i32 = arith.constant 0 : i32
    %c0_0 = arith.constant 0 : index
    %c1_1 = arith.constant 1 : index
    %c2_2 = arith.constant 2 : index
    scf.for %arg2 = %c0_0 to %c2_2 step %c1_1 {
      %0 = scf.for %arg3 = %c0_0 to %c2_2 step %c1_1 iter_args(%arg4 = %c0_i32) -> (i32) {
        %1 = memref.load %arg1[%arg3, %arg2] : memref<2x2xi32>
        %2 = arith.addi %arg4, %1 : i32
        memref.store %2, %arg0[%arg2, %arg3] : memref<2x2xi32>
        scf.yield %2 : i32
      }
    } {amoeba.host.task_completion, amoeba.host.task_name = "update"}
    return
  }
}

