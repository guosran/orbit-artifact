module {
 func.func @phi3(%out: memref<1xi32>) {
 %done = taskflow.task @phi3 will_writes(%out : memref<1xi32>) [original_write_memrefs(%out : memref<1xi32>)] : (memref<1xi32>) -> memref<1xi32> {
 ^bb0(%write: memref<1xi32>):
 %c0 = arith.constant 0 : index
 %c1 = arith.constant 1 : index
 %i = taskflow.counter from %c0 to %c1 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 0 : i32} : index
 neura.kernel inputs(%write : memref<1xi32>) attributes {accelerator = "neura", dataflow_mode = "predicate"} {
 ^bb0(%input0: !neura.data<memref<1xi32>, i1>):
 %idx = neura.counter attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 0 : i32, lower_bound_value = 0 : index, step_value = 1 : index, upper_bound_value = 1 : index} -> !neura.data<index, i1>
 %false = "neura.constant"() {value = false} : () -> !neura.data<i1, i1>
 %v = "neura.constant"() {value = 7 : i32} : () -> !neura.data<i32, i1>
 %invalid = neura.grant_predicate %v, %false : !neura.data<i32, i1>, !neura.data<i1, i1> -> !neura.data<i32, i1>
 %merged = "neura.phi"(%invalid, %invalid, %v) : (!neura.data<i32, i1>, !neura.data<i32, i1>, !neura.data<i32, i1>) -> !neura.data<i32, i1>
 neura.store_indexed %merged to [%idx : !neura.data<index, i1>] {rhs_value = "%input0"} : !neura.data<i32, i1>
 neura.yield {yield_type = "void"}
 }
 taskflow.yield done_writes(%write : memref<1xi32>)
 }
 return
 }
}
