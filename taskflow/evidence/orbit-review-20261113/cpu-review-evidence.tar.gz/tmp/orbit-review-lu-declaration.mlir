module {
 func.func private @lu_func(i32, memref<?x100xi32>, memref<?xi32>, memref<?x100xi32>, memref<?x100xi32>, memref<?x100xi32>, memref<?xi32>, memref<?xi32>, memref<?x100xi32>, memref<?xi32>)
}
