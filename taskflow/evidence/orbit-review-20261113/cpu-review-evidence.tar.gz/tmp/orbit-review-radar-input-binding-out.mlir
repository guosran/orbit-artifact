module {
  func.func @_Z10radar_func_review(%arg0: memref<32x256xi32> {amoeba.noalias}, %arg1: memref<32x256xi32> {amoeba.noalias}, %arg2: memref<32x256xi32> {amoeba.noalias}, %arg3: memref<32x256xi32> {amoeba.noalias}) attributes {amoeba.replica.count = 2 : i64, amoeba.replica.materialized_task = "Task_2", amoeba.replica.parent_task = "Task_2", amoeba.replica.shard_axis = 0 : i64, amoeba.replica.shard_trip_count = 1024 : i64, amoeba.replica.total_trip_count = 2048 : i64} {
    %done_writes:2 = taskflow.task @Task_2.replica.0 will_reads(%arg1 : memref<32x256xi32>) will_writes(%arg1, %arg2 : memref<32x256xi32>, memref<32x256xi32>) [original_read_memrefs(%arg0 : memref<32x256xi32>), original_write_memrefs(%arg1, %arg2 : memref<32x256xi32>, memref<32x256xi32>)] {amoeba.replica.count = 2 : i64, amoeba.replica.id = 0 : i64, amoeba.replica.output_counter_axes = array<i64: 1, 0>, amoeba.replica.output_shard_axis = 1 : i64, amoeba.replica.parent_task = "Task_2", amoeba.replica.shard_axis = 0 : i64, amoeba.replica.shard_lower = 0 : i64, amoeba.replica.shard_trip_count = 1024 : i64, amoeba.replica.shard_upper = 32 : i64, amoeba.replica.total_trip_count = 2048 : i64, amoeba.tiling.output_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 32, 32>, array<i64: 32, 32>], trip_count = 1024 : i64} : (memref<32x256xi32>, memref<32x256xi32>, memref<32x256xi32>) -> (memref<32x256xi32>, memref<32x256xi32>) {
    ^bb0(%arg4: memref<32x256xi32>, %arg5: memref<32x256xi32>, %arg6: memref<32x256xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c64 = arith.constant 64 : index
      %c32 = arith.constant 32 : index
      %c0_9 = arith.constant 0 : index
      %c32_10 = arith.constant 32 : index
      %2 = taskflow.counter from %c0_9 to %c32_10 step %c1 attributes {counter_dynamism = "constant_bound", counter_id = 0 : i32} : index
      %3 = taskflow.counter parent(%2 : index) from %c0 to %c32 step %c1 attributes {counter_id = 1 : i32} : index
      neura.kernel inputs(%arg4, %arg5, %arg6 : memref<32x256xi32>, memref<32x256xi32>, memref<32x256xi32>) attributes {accelerator = "neura"} {
      ^bb0(%arg7: memref<32x256xi32>, %arg8: memref<32x256xi32>, %arg9: memref<32x256xi32>):
        %c0_11 = arith.constant 0 : index
        %c32_12 = arith.constant 32 : index
        %4 = neura.counter from %c0_11 : index to %c32_12 : index attributes {counter_dynamism = "constant_bound", counter_id = 0 : i32, lower_bound_value = 0 : index, step_value = 1 : index, upper_bound_value = 32 : index} -> !neura.data<index, i1>
        %5 = neura.counter attributes {counter_id = 1 : i32, lower_bound_value = 0 : index, step_value = 1 : index, upper_bound_value = 32 : index} -> !neura.data<index, i1>
        %6 = neura.load_indexed [%5, %4 : !neura.data<index, i1>, !neura.data<index, i1>]  {lhs_value = "%input0"} : !neura.data<i32, i1>
        %7 = "neura.add"(%6) {rhs_value = 1 : i32} : (!neura.data<i32, i1>) -> !neura.data<i32, i1>
        neura.store_indexed %7 to [%5, %4 : !neura.data<index, i1>, !neura.data<index, i1>]  {rhs_value = "%input1"} : !neura.data<i32, i1>
        neura.store_indexed %7 to [%5, %4 : !neura.data<index, i1>, !neura.data<index, i1>]  {rhs_value = "%input2"} : !neura.data<i32, i1>
        neura.yield {yield_type = "void"}
      }
      taskflow.yield done_writes(%arg5, %arg6 : memref<32x256xi32>, memref<32x256xi32>)
    }
    %done_writes_0:2 = taskflow.task @Task_2.replica.1 will_reads(%arg1 : memref<32x256xi32>) will_writes(%arg1, %arg2 : memref<32x256xi32>, memref<32x256xi32>) [original_read_memrefs(%arg0 : memref<32x256xi32>), original_write_memrefs(%arg1, %arg2 : memref<32x256xi32>, memref<32x256xi32>)] {amoeba.replica.count = 2 : i64, amoeba.replica.id = 1 : i64, amoeba.replica.output_counter_axes = array<i64: 1, 0>, amoeba.replica.output_shard_axis = 1 : i64, amoeba.replica.parent_task = "Task_2", amoeba.replica.shard_axis = 0 : i64, amoeba.replica.shard_lower = 32 : i64, amoeba.replica.shard_trip_count = 1024 : i64, amoeba.replica.shard_upper = 64 : i64, amoeba.replica.total_trip_count = 2048 : i64, amoeba.tiling.output_region_lowers = [array<i64: 0, 32>, array<i64: 0, 32>], amoeba.tiling.output_region_uppers = [array<i64: 32, 64>, array<i64: 32, 64>], trip_count = 1024 : i64} : (memref<32x256xi32>, memref<32x256xi32>, memref<32x256xi32>) -> (memref<32x256xi32>, memref<32x256xi32>) {
    ^bb0(%arg4: memref<32x256xi32>, %arg5: memref<32x256xi32>, %arg6: memref<32x256xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c64 = arith.constant 64 : index
      %c32 = arith.constant 32 : index
      %c32_9 = arith.constant 32 : index
      %c64_10 = arith.constant 64 : index
      %2 = taskflow.counter from %c32_9 to %c64_10 step %c1 attributes {counter_dynamism = "constant_bound", counter_id = 0 : i32} : index
      %3 = taskflow.counter parent(%2 : index) from %c0 to %c32 step %c1 attributes {counter_id = 1 : i32} : index
      neura.kernel inputs(%arg4, %arg5, %arg6 : memref<32x256xi32>, memref<32x256xi32>, memref<32x256xi32>) attributes {accelerator = "neura"} {
      ^bb0(%arg7: memref<32x256xi32>, %arg8: memref<32x256xi32>, %arg9: memref<32x256xi32>):
        %c32_11 = arith.constant 32 : index
        %c64_12 = arith.constant 64 : index
        %4 = neura.counter from %c32_11 : index to %c64_12 : index attributes {counter_dynamism = "constant_bound", counter_id = 0 : i32, lower_bound_value = 32 : index, step_value = 1 : index, upper_bound_value = 64 : index} -> !neura.data<index, i1>
        %5 = neura.counter attributes {counter_id = 1 : i32, lower_bound_value = 0 : index, step_value = 1 : index, upper_bound_value = 32 : index} -> !neura.data<index, i1>
        %6 = neura.load_indexed [%5, %4 : !neura.data<index, i1>, !neura.data<index, i1>]  {lhs_value = "%input0"} : !neura.data<i32, i1>
        %7 = "neura.add"(%6) {rhs_value = 1 : i32} : (!neura.data<i32, i1>) -> !neura.data<i32, i1>
        neura.store_indexed %7 to [%5, %4 : !neura.data<index, i1>, !neura.data<index, i1>]  {rhs_value = "%input1"} : !neura.data<i32, i1>
        neura.store_indexed %7 to [%5, %4 : !neura.data<index, i1>, !neura.data<index, i1>]  {rhs_value = "%input2"} : !neura.data<i32, i1>
        neura.yield {yield_type = "void"}
      }
      taskflow.yield done_writes(%arg5, %arg6 : memref<32x256xi32>, memref<32x256xi32>)
    }
    %cast = memref.cast %arg1 : memref<32x256xi32> to memref<32x256xi32>
    %cast_1 = memref.cast %done_writes#0 : memref<32x256xi32> to memref<32x256xi32>
    %cast_2 = memref.cast %done_writes_0#0 : memref<32x256xi32> to memref<32x256xi32>
    %0 = taskflow.join states(%cast_1, %cast_2) base(%cast) axis(1) region([0, 0], [32, 64]) {amoeba.replica.completion_only, amoeba.semantic.completion_only} : memref<32x256xi32>
    %cast_3 = memref.cast %0 : memref<32x256xi32> to memref<32x256xi32>
    %cast_4 = memref.cast %arg2 : memref<32x256xi32> to memref<32x256xi32>
    %cast_5 = memref.cast %done_writes#1 : memref<32x256xi32> to memref<32x256xi32>
    %cast_6 = memref.cast %done_writes_0#1 : memref<32x256xi32> to memref<32x256xi32>
    %1 = taskflow.join states(%cast_5, %cast_6) base(%cast_4) axis(1) region([0, 0], [32, 64]) {amoeba.replica.completion_only, amoeba.semantic.completion_only} : memref<32x256xi32>
    %cast_7 = memref.cast %1 : memref<32x256xi32> to memref<32x256xi32>
    %done_writes_8 = taskflow.task @Task_4 will_reads(%cast_3, %cast_7 : memref<32x256xi32>, memref<32x256xi32>) will_writes(%arg3 : memref<32x256xi32>) [original_read_memrefs(%arg1, %arg2 : memref<32x256xi32>, memref<32x256xi32>), original_write_memrefs(%arg3 : memref<32x256xi32>)] : (memref<32x256xi32>, memref<32x256xi32>, memref<32x256xi32>) -> (memref<32x256xi32>) {
    ^bb0(%arg4: memref<32x256xi32>, %arg5: memref<32x256xi32>, %arg6: memref<32x256xi32>):
      memref.copy %arg4, %arg6 : memref<32x256xi32> to memref<32x256xi32>
      taskflow.yield done_writes(%arg6 : memref<32x256xi32>)
    }
    return
  }
}

