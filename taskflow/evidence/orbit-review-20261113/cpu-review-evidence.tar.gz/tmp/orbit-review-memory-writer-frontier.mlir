module {
func.func @writer_frontier(%a: memref<2xi32>, %b: memref<1xi32>) {
 %p = taskflow.task @p will_writes(%a : memref<2xi32>) [original_write_memrefs(%a : memref<2xi32>)] {amoeba.tiling.output_region_lowers = [array<i64: 0>], amoeba.tiling.output_region_uppers = [array<i64: 1>]} : (memref<2xi32>) -> memref<2xi32> {
 ^bb0(%out: memref<2xi32>):
  %c0 = arith.constant 0 : index
  %v = arith.constant 7 : i32
  memref.store %v, %out[%c0] : memref<2xi32>
  taskflow.yield done_writes(%out : memref<2xi32>)
 }
 %q = taskflow.task @q will_writes(%a : memref<2xi32>) [original_write_memrefs(%a : memref<2xi32>)] {amoeba.tiling.output_region_lowers = [array<i64: 1>], amoeba.tiling.output_region_uppers = [array<i64: 2>]} : (memref<2xi32>) -> memref<2xi32> {
 ^bb0(%out: memref<2xi32>):
  %c1 = arith.constant 1 : index
  %v = arith.constant 9 : i32
  memref.store %v, %out[%c1] : memref<2xi32>
  taskflow.yield done_writes(%out : memref<2xi32>)
 }
 %r = taskflow.task @r will_reads(%a : memref<2xi32>) will_writes(%b : memref<1xi32>) [original_read_memrefs(%a : memref<2xi32>), original_write_memrefs(%b : memref<1xi32>)] {amoeba.tiling.input_region_lowers = [array<i64: 0>], amoeba.tiling.input_region_uppers = [array<i64: 1>], amoeba.tiling.input_region_reasons = ["direct"]} : (memref<2xi32>, memref<1xi32>) -> memref<1xi32> {
 ^bb0(%in: memref<2xi32>, %out: memref<1xi32>):
  %c0 = arith.constant 0 : index
  %v = memref.load %in[%c0] : memref<2xi32>
  memref.store %v, %out[%c0] : memref<1xi32>
  taskflow.yield done_writes(%out : memref<1xi32>)
 }
 return
}
}
