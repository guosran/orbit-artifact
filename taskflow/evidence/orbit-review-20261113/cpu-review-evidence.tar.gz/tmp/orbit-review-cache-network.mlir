module {
func.func @network_cache(%a: memref<4xi32>, %b: memref<4xi32>) {
 %p = taskflow.task @p will_writes(%a : memref<4xi32>) [original_write_memrefs(%a : memref<4xi32>)] : (memref<4xi32>) -> (memref<4xi32>) {
 ^bb0(%out: memref<4xi32>):
  taskflow.yield done_writes(%out : memref<4xi32>)
 }
 %q = taskflow.task @q will_reads(%p : memref<4xi32>) will_writes(%b : memref<4xi32>) [original_read_memrefs(%a : memref<4xi32>), original_write_memrefs(%b : memref<4xi32>)] : (memref<4xi32>, memref<4xi32>) -> (memref<4xi32>) {
 ^bb0(%in: memref<4xi32>, %out: memref<4xi32>):
  taskflow.yield done_writes(%out : memref<4xi32>)
 }
 return
}
}
