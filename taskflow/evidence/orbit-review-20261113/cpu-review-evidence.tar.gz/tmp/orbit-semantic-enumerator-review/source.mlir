module {
 func.func @canonical(%a: memref<8x8xi32> {amoeba.noalias}, %b: memref<8x8xi32> {amoeba.noalias}, %c: memref<8x8xi32> {amoeba.noalias}, %e: memref<8x8xi32> {amoeba.noalias}, %d: memref<8x8xi32> {amoeba.noalias}) -> memref<8x8xi32> {
 %t = memref.alloc() : memref<8x8xi32>
 %p = taskflow.task @producer will_reads(%a, %b, %c : memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) will_writes(%t : memref<8x8xi32>) [original_read_memrefs(%a, %b, %c : memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>), original_write_memrefs(%t : memref<8x8xi32>)] : (memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) -> memref<8x8xi32> {
 ^bb0(%ra: memref<8x8xi32>, %rb: memref<8x8xi32>, %rc: memref<8x8xi32>, %wt: memref<8x8xi32>):
 %z = arith.constant 0 : index
 %o = arith.constant 1 : index
 %eight = arith.constant 8 : index
 %m = taskflow.counter from %z to %eight step %o : index
 %n = taskflow.counter parent(%m : index) from %z to %eight step %o : index
 "taskflow.hyperblock"(%m, %n) <{operandSegmentSizes = array<i32: 2, 0>}> ({
 ^bb0(%i: index, %j: index):
 %init = memref.load %rc[%i, %j] : memref<8x8xi32>
 %sum = scf.for %k = %z to %eight step %o iter_args(%acc = %init) -> i32 {
 %av = memref.load %ra[%i, %k] : memref<8x8xi32>
 %bv = memref.load %rb[%k, %j] : memref<8x8xi32>
 %mul = arith.muli %av, %bv : i32
 %add = arith.addi %acc, %mul : i32
 scf.yield %add : i32
 }
 memref.store %sum, %wt[%i, %j] : memref<8x8xi32>
 "taskflow.hyperblock.yield"() <{operandSegmentSizes = array<i32: 0, 0>}> : () -> ()
 }) : (index, index) -> ()
 taskflow.yield done_writes(%wt : memref<8x8xi32>)
 }
 %q = taskflow.task @consumer will_reads(%p, %e : memref<8x8xi32>, memref<8x8xi32>) will_writes(%d : memref<8x8xi32>) [original_read_memrefs(%t, %e : memref<8x8xi32>, memref<8x8xi32>), original_write_memrefs(%d : memref<8x8xi32>)] : (memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) -> memref<8x8xi32> {
 ^bb0(%rt: memref<8x8xi32>, %re: memref<8x8xi32>, %wd: memref<8x8xi32>):
 %z = arith.constant 0 : index
 %o = arith.constant 1 : index
 %eight = arith.constant 8 : index
 %m = taskflow.counter from %z to %eight step %o : index
 %n = taskflow.counter parent(%m : index) from %z to %eight step %o : index
 "taskflow.hyperblock"(%m, %n) <{operandSegmentSizes = array<i32: 2, 0>}> ({
 ^bb0(%i: index, %j: index):
 %tv = memref.load %rt[%i, %j] : memref<8x8xi32>
 %ev = memref.load %re[%i, %j] : memref<8x8xi32>
 %sum = arith.addi %tv, %ev : i32
 memref.store %sum, %wd[%i, %j] : memref<8x8xi32>
 "taskflow.hyperblock.yield"() <{operandSegmentSizes = array<i32: 0, 0>}> : () -> ()
 }) : (index, index) -> ()
 taskflow.yield done_writes(%wd : memref<8x8xi32>)
 }
 return %q : memref<8x8xi32>
 }
}
