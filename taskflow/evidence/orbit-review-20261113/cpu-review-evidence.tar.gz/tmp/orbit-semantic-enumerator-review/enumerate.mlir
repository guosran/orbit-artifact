module {
  func.func @canonical(%arg0: memref<8x8xi32> {amoeba.noalias}, %arg1: memref<8x8xi32> {amoeba.noalias}, %arg2: memref<8x8xi32> {amoeba.noalias}, %arg3: memref<8x8xi32> {amoeba.noalias}, %arg4: memref<8x8xi32> {amoeba.noalias}) -> memref<8x8xi32> {
    %alloc = memref.alloc() : memref<8x8xi32>
    %done_writes = taskflow.task @producer will_reads(%arg0, %arg1, %arg2 : memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) will_writes(%alloc : memref<8x8xi32>) [original_read_memrefs(%arg0, %arg1, %arg2 : memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>), original_write_memrefs(%alloc : memref<8x8xi32>)] : (memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) -> (memref<8x8xi32>) {
    ^bb0(%arg5: memref<8x8xi32>, %arg6: memref<8x8xi32>, %arg7: memref<8x8xi32>, %arg8: memref<8x8xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c8 = arith.constant 8 : index
      %0 = taskflow.counter from %c0 to %c8 step %c1 : index
      %1 = taskflow.counter parent(%0 : index) from %c0 to %c8 step %c1 : index
      "taskflow.hyperblock"(%0, %1) <{operandSegmentSizes = array<i32: 2, 0>}> ({
      ^bb0(%arg9: index, %arg10: index):
        %2 = memref.load %arg7[%arg9, %arg10] : memref<8x8xi32>
        %3 = scf.for %arg11 = %c0 to %c8 step %c1 iter_args(%arg12 = %2) -> (i32) {
          %4 = memref.load %arg5[%arg9, %arg11] : memref<8x8xi32>
          %5 = memref.load %arg6[%arg11, %arg10] : memref<8x8xi32>
          %6 = arith.muli %4, %5 : i32
          %7 = arith.addi %arg12, %6 : i32
          scf.yield %7 : i32
        }
        memref.store %3, %arg8[%arg9, %arg10] : memref<8x8xi32>
        taskflow.hyperblock.yield
      }) : (index, index) -> ()
      taskflow.yield done_writes(%arg8 : memref<8x8xi32>)
    }
    %done_writes_0 = taskflow.task @consumer will_reads(%done_writes, %arg3 : memref<8x8xi32>, memref<8x8xi32>) will_writes(%arg4 : memref<8x8xi32>) [original_read_memrefs(%alloc, %arg3 : memref<8x8xi32>, memref<8x8xi32>), original_write_memrefs(%arg4 : memref<8x8xi32>)] : (memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) -> (memref<8x8xi32>) {
    ^bb0(%arg5: memref<8x8xi32>, %arg6: memref<8x8xi32>, %arg7: memref<8x8xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c8 = arith.constant 8 : index
      %0 = taskflow.counter from %c0 to %c8 step %c1 : index
      %1 = taskflow.counter parent(%0 : index) from %c0 to %c8 step %c1 : index
      "taskflow.hyperblock"(%0, %1) <{operandSegmentSizes = array<i32: 2, 0>}> ({
      ^bb0(%arg8: index, %arg9: index):
        %2 = memref.load %arg5[%arg8, %arg9] : memref<8x8xi32>
        %3 = memref.load %arg6[%arg8, %arg9] : memref<8x8xi32>
        %4 = arith.addi %2, %3 : i32
        memref.store %4, %arg7[%arg8, %arg9] : memref<8x8xi32>
        taskflow.hyperblock.yield
      }) : (index, index) -> ()
      taskflow.yield done_writes(%arg7 : memref<8x8xi32>)
    }
    return %done_writes_0 : memref<8x8xi32>
  }
}

