module {
  func.func @canonical(%arg0: memref<8x8xi32> {amoeba.noalias}, %arg1: memref<8x8xi32> {amoeba.noalias}, %arg2: memref<8x8xi32> {amoeba.noalias}, %arg3: memref<8x8xi32> {amoeba.noalias}, %arg4: memref<8x8xi32> {amoeba.noalias}) -> memref<8x8xi32> attributes {amoeba.semantic.k_policy = "parallel", amoeba.semantic.reduction_topology = "numeric", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1"} {
    %alloc = memref.alloc() : memref<8x8xi32>
    %alloc_0 = memref.alloc() {amoeba.semantic.logical_k_block = 0 : i64, amoeba.semantic.private_partial} : memref<8x8xi32>
    %done_writes = taskflow.task @partial_k.0 will_reads(%arg0, %arg1 : memref<8x8xi32>, memref<8x8xi32>) will_writes(%alloc_0 : memref<8x8xi32>) [original_read_memrefs(%arg0, %arg1 : memref<8x8xi32>, memref<8x8xi32>), original_write_memrefs(%alloc_0 : memref<8x8xi32>)] {amoeba.semantic.K_range = array<i64: 0, 4>, amoeba.semantic.M_range = array<i64: 0, 8>, amoeba.semantic.N_range = array<i64: 0, 8>, amoeba.semantic.incoming_edges = [], amoeba.semantic.k_policy = "parallel", amoeba.semantic.logical_k_block = 0 : i64, amoeba.semantic.output_visibility = "private_partial", amoeba.semantic.partial_buffer = "partial_k.0", amoeba.semantic.private_partial, amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "gemm_producer", amoeba.semantic.task_role = "producer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["private_partial", "private_partial"], amoeba.tiling.input_region_uppers = [array<i64: 8, 4>, array<i64: 4, 8>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 8, 8>]} : (memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) -> (memref<8x8xi32>) {
    ^bb0(%arg5: memref<8x8xi32>, %arg6: memref<8x8xi32>, %arg7: memref<8x8xi32>):
      %c0 = arith.constant 0 : index
      %c8 = arith.constant 8 : index
      %c1 = arith.constant 1 : index
      %0 = taskflow.counter from %c0 to %c8 step %c1 : index
      %c0_4 = arith.constant 0 : index
      %c8_5 = arith.constant 8 : index
      %c1_6 = arith.constant 1 : index
      %1 = taskflow.counter parent(%0 : index) from %c0_4 to %c8_5 step %c1_6 : index
      "taskflow.hyperblock"(%0, %1) <{operandSegmentSizes = array<i32: 2, 0>}> ({
      ^bb0(%arg8: index, %arg9: index):
        %c0_7 = arith.constant 0 : index
        %c4 = arith.constant 4 : index
        %c1_8 = arith.constant 1 : index
        %c0_i32 = arith.constant 0 : i32
        %2 = scf.for %arg10 = %c0_7 to %c4 step %c1_8 iter_args(%arg11 = %c0_i32) -> (i32) {
          %3 = memref.load %arg5[%arg8, %arg10] : memref<8x8xi32>
          %4 = memref.load %arg6[%arg10, %arg9] : memref<8x8xi32>
          %5 = arith.muli %3, %4 : i32
          %6 = arith.addi %arg11, %5 : i32
          scf.yield %6 : i32
        }
        memref.store %2, %arg7[%arg8, %arg9] : memref<8x8xi32>
        taskflow.hyperblock.yield
      }) : (index, index) -> ()
      taskflow.yield done_writes(%arg7 : memref<8x8xi32>)
    }
    %alloc_1 = memref.alloc() {amoeba.semantic.logical_k_block = 1 : i64, amoeba.semantic.private_partial} : memref<8x8xi32>
    %done_writes_2 = taskflow.task @partial_k.1 will_reads(%arg0, %arg1 : memref<8x8xi32>, memref<8x8xi32>) will_writes(%alloc_1 : memref<8x8xi32>) [original_read_memrefs(%arg0, %arg1 : memref<8x8xi32>, memref<8x8xi32>), original_write_memrefs(%alloc_1 : memref<8x8xi32>)] {amoeba.semantic.K_range = array<i64: 4, 8>, amoeba.semantic.M_range = array<i64: 0, 8>, amoeba.semantic.N_range = array<i64: 0, 8>, amoeba.semantic.incoming_edges = [], amoeba.semantic.k_policy = "parallel", amoeba.semantic.logical_k_block = 1 : i64, amoeba.semantic.output_visibility = "private_partial", amoeba.semantic.partial_buffer = "partial_k.1", amoeba.semantic.private_partial, amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "gemm_producer", amoeba.semantic.task_role = "producer", amoeba.tiling.input_region_lowers = [array<i64: 0, 4>, array<i64: 4, 0>], amoeba.tiling.input_region_reasons = ["private_partial", "private_partial"], amoeba.tiling.input_region_uppers = [array<i64: 8, 8>, array<i64: 8, 8>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 8, 8>]} : (memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) -> (memref<8x8xi32>) {
    ^bb0(%arg5: memref<8x8xi32>, %arg6: memref<8x8xi32>, %arg7: memref<8x8xi32>):
      %c0 = arith.constant 0 : index
      %c8 = arith.constant 8 : index
      %c1 = arith.constant 1 : index
      %0 = taskflow.counter from %c0 to %c8 step %c1 : index
      %c0_4 = arith.constant 0 : index
      %c8_5 = arith.constant 8 : index
      %c1_6 = arith.constant 1 : index
      %1 = taskflow.counter parent(%0 : index) from %c0_4 to %c8_5 step %c1_6 : index
      "taskflow.hyperblock"(%0, %1) <{operandSegmentSizes = array<i32: 2, 0>}> ({
      ^bb0(%arg8: index, %arg9: index):
        %c4 = arith.constant 4 : index
        %c8_7 = arith.constant 8 : index
        %c1_8 = arith.constant 1 : index
        %c0_i32 = arith.constant 0 : i32
        %2 = scf.for %arg10 = %c4 to %c8_7 step %c1_8 iter_args(%arg11 = %c0_i32) -> (i32) {
          %3 = memref.load %arg5[%arg8, %arg10] : memref<8x8xi32>
          %4 = memref.load %arg6[%arg10, %arg9] : memref<8x8xi32>
          %5 = arith.muli %3, %4 : i32
          %6 = arith.addi %arg11, %5 : i32
          scf.yield %6 : i32
        }
        memref.store %2, %arg7[%arg8, %arg9] : memref<8x8xi32>
        taskflow.hyperblock.yield
      }) : (index, index) -> ()
      taskflow.yield done_writes(%arg7 : memref<8x8xi32>)
    }
    %done_writes_3 = taskflow.task @fused.reduction.final.consumer will_reads(%arg2, %done_writes, %done_writes_2, %arg3 : memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) will_writes(%arg4 : memref<8x8xi32>) [original_read_memrefs(%arg2, %alloc_0, %alloc_1, %arg3 : memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>), original_write_memrefs(%arg4 : memref<8x8xi32>)] {amoeba.semantic.K_range = array<i64: 0, 8>, amoeba.semantic.M_range = array<i64: 0, 8>, amoeba.semantic.N_range = array<i64: 0, 8>, amoeba.semantic.final_C_ownership = "external_final_D", amoeba.semantic.fusion_layer = "task_graph_fusion", amoeba.semantic.fusion_mode = "reduction_consumer", amoeba.semantic.incoming_edges = ["partial_k.0|partial_reduction|tile_local", "partial_k.1|partial_reduction|tile_local"], amoeba.semantic.k_policy = "parallel", amoeba.semantic.numeric_reduction, amoeba.semantic.output_visibility = "global_materialized", amoeba.semantic.reduction_final, amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "fused_reduction_consumer", amoeba.semantic.task_role = "fused_reduction_consumer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>, array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["fused_final", "fused_final", "fused_final", "fused_final"], amoeba.tiling.input_region_uppers = [array<i64: 8, 8>, array<i64: 8, 8>, array<i64: 8, 8>, array<i64: 8, 8>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 8, 8>]} : (memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) -> (memref<8x8xi32>) {
    ^bb0(%arg5: memref<8x8xi32>, %arg6: memref<8x8xi32>, %arg7: memref<8x8xi32>, %arg8: memref<8x8xi32>, %arg9: memref<8x8xi32>):
      %c0 = arith.constant 0 : index
      %c8 = arith.constant 8 : index
      %c1 = arith.constant 1 : index
      %0 = taskflow.counter from %c0 to %c8 step %c1 : index
      %c0_4 = arith.constant 0 : index
      %c8_5 = arith.constant 8 : index
      %c1_6 = arith.constant 1 : index
      %1 = taskflow.counter parent(%0 : index) from %c0_4 to %c8_5 step %c1_6 : index
      "taskflow.hyperblock"(%0, %1) <{operandSegmentSizes = array<i32: 2, 0>}> ({
      ^bb0(%arg10: index, %arg11: index):
        %2 = memref.load %arg5[%arg10, %arg11] : memref<8x8xi32>
        %3 = memref.load %arg6[%arg10, %arg11] : memref<8x8xi32>
        %4 = arith.addi %2, %3 : i32
        %5 = memref.load %arg7[%arg10, %arg11] : memref<8x8xi32>
        %6 = arith.addi %4, %5 : i32
        %7 = memref.load %arg8[%arg10, %arg11] : memref<8x8xi32>
        %8 = arith.addi %6, %7 : i32
        memref.store %8, %arg9[%arg10, %arg11] : memref<8x8xi32>
        taskflow.hyperblock.yield
      }) : (index, index) -> ()
      taskflow.yield done_writes(%arg9 : memref<8x8xi32>)
    }
    return %done_writes_3 : memref<8x8xi32>
  }
}

