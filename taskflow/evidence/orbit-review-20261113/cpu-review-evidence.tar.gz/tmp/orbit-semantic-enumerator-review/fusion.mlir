module {
  func.func @canonical(%arg0: memref<8x8xi32> {amoeba.noalias}, %arg1: memref<8x8xi32> {amoeba.noalias}, %arg2: memref<8x8xi32> {amoeba.noalias}, %arg3: memref<8x8xi32> {amoeba.noalias}, %arg4: memref<8x8xi32> {amoeba.noalias}) -> memref<8x8xi32> {
    %done_reads:4, %done_writes = taskflow.task @producer.fuse.consumer will_reads(%arg0, %arg1, %arg2, %arg3 : memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) will_writes(%arg4 : memref<8x8xi32>) [original_read_memrefs(%arg0, %arg1, %arg2, %arg3 : memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>), original_write_memrefs(%arg4 : memref<8x8xi32>)] {amoeba.semantic.fusion_mode = "producer_consumer", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.task_kind = "fused_producer_consumer", amoeba.semantic.task_role = "fused_producer_consumer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>, array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["proven_rectangular", "proven_rectangular", "proven_rectangular", "proven_rectangular"], amoeba.tiling.input_region_uppers = [array<i64: 8, 8>, array<i64: 8, 8>, array<i64: 8, 8>, array<i64: 8, 8>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 8, 8>]} : (memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) -> (memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) {
    ^bb0(%arg5: memref<8x8xi32>, %arg6: memref<8x8xi32>, %arg7: memref<8x8xi32>, %arg8: memref<8x8xi32>, %arg9: memref<8x8xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c8 = arith.constant 8 : index
      %c0_0 = arith.constant 0 : index
      %c1_1 = arith.constant 1 : index
      %c8_2 = arith.constant 8 : index
      %0 = taskflow.counter from %c0 to %c8 step %c1 : index
      %1 = taskflow.counter parent(%0 : index) from %c0 to %c8 step %c1 : index
      "taskflow.hyperblock"(%0, %1) <{operandSegmentSizes = array<i32: 2, 0>}> ({
      ^bb0(%arg10: index, %arg11: index):
        %2 = memref.load %arg7[%arg10, %arg11] : memref<8x8xi32>
        %3 = scf.for %arg12 = %c0 to %c8 step %c1 iter_args(%arg13 = %2) -> (i32) {
          %6 = memref.load %arg5[%arg10, %arg12] : memref<8x8xi32>
          %7 = memref.load %arg6[%arg12, %arg11] : memref<8x8xi32>
          %8 = arith.muli %6, %7 : i32
          %9 = arith.addi %arg13, %8 : i32
          scf.yield %9 : i32
        }
        %4 = memref.load %arg8[%arg10, %arg11] : memref<8x8xi32>
        %5 = arith.addi %3, %4 : i32
        memref.store %5, %arg9[%arg10, %arg11] : memref<8x8xi32>
        taskflow.hyperblock.yield
      }) : (index, index) -> ()
      taskflow.yield done_reads(%arg5, %arg6, %arg7, %arg8 : memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>, memref<8x8xi32>) done_writes(%arg9 : memref<8x8xi32>)
    }
    return %done_writes : memref<8x8xi32>
  }
}

