module {
  func.func @inplace_alias(%arg0: memref<2x2xi32>, %arg1: memref<2x2xi32>) attributes {amoeba.neura.joint_rewrite = "post-neura-mn-tiling"} {
    %done_writes = taskflow.task @update.tile.1.0 will_reads(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>) will_writes(%arg0 : memref<2x2xi32>) [original_read_memrefs(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>), original_write_memrefs(%arg0 : memref<2x2xi32>)] {amoeba.neura.joint_rewrite = "post-neura-mn-tiling", amoeba.neura.tiling.axis = 1 : i64, amoeba.neura.tiling.derived_range = array<i64: 0, 1>, amoeba.neura.tiling.factor = 2 : i64, amoeba.neura.tiling.original_range = array<i64: 0, 2>, amoeba.neura.tiling.parent_task = "update", amoeba.neura.tiling.part_index = 0 : i64, amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, unit], amoeba.tiling.input_region_reasons = ["in_place_output_coordinate_proof", "unproven"], amoeba.tiling.input_region_uppers = [array<i64: 2, 1>, unit], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 1>]} : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
    ^bb0(%arg2: memref<2x2xi32>, %arg3: memref<2x2xi32>, %arg4: memref<2x2xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %c0_1 = arith.constant 0 : index
      %c2_2 = arith.constant 2 : index
      %1 = taskflow.counter from %c0_1 to %c2_2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
      %c0_3 = arith.constant 0 : index
      %c1_4 = arith.constant 1 : index
      %2 = taskflow.counter parent(%1 : index) from %c0_3 to %c1_4 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
      neura.kernel inputs(%arg4, %arg3 : memref<2x2xi32>, memref<2x2xi32>) attributes {accelerator = "neura"} {
      ^bb0(%arg5: memref<2x2xi32>, %arg6: memref<2x2xi32>):
        %c0_5 = arith.constant 0 : index
        %c1_6 = arith.constant 1 : index
        %c2_7 = arith.constant 2 : index
        %c0_8 = arith.constant 0 : index
        %c2_9 = arith.constant 2 : index
        %3 = neura.counter from %c0_8 : index to %c2_9 : index step %c1_6 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
        %c0_10 = arith.constant 0 : index
        %c1_11 = arith.constant 1 : index
        %4 = neura.counter from %c0_10 : index to %c1_11 : index step %c1_6 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
        %5 = memref.load %arg5[%3, %4] : memref<2x2xi32>
        %6 = memref.load %arg6[%4, %3] : memref<2x2xi32>
        %7 = arith.addi %5, %6 : i32
        memref.store %7, %arg5[%3, %4] : memref<2x2xi32>
        neura.yield {yield_type = "void"}
      }
      taskflow.yield done_writes(%arg4 : memref<2x2xi32>)
    }
    %done_writes_0 = taskflow.task @update.tile.1.1 will_reads(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>) will_writes(%arg0 : memref<2x2xi32>) [original_read_memrefs(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>), original_write_memrefs(%arg0 : memref<2x2xi32>)] {amoeba.neura.joint_rewrite = "post-neura-mn-tiling", amoeba.neura.tiling.axis = 1 : i64, amoeba.neura.tiling.derived_range = array<i64: 1, 2>, amoeba.neura.tiling.factor = 2 : i64, amoeba.neura.tiling.original_range = array<i64: 0, 2>, amoeba.neura.tiling.parent_task = "update", amoeba.neura.tiling.part_index = 1 : i64, amoeba.tiling.input_region_lowers = [array<i64: 0, 1>, unit], amoeba.tiling.input_region_reasons = ["in_place_output_coordinate_proof", "unproven"], amoeba.tiling.input_region_uppers = [array<i64: 2, 2>, unit], amoeba.tiling.output_region_lowers = [array<i64: 0, 1>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]} : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
    ^bb0(%arg2: memref<2x2xi32>, %arg3: memref<2x2xi32>, %arg4: memref<2x2xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %c0_1 = arith.constant 0 : index
      %c2_2 = arith.constant 2 : index
      %1 = taskflow.counter from %c0_1 to %c2_2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
      %c1_3 = arith.constant 1 : index
      %c2_4 = arith.constant 2 : index
      %2 = taskflow.counter parent(%1 : index) from %c1_3 to %c2_4 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
      neura.kernel inputs(%arg4, %arg3 : memref<2x2xi32>, memref<2x2xi32>) attributes {accelerator = "neura"} {
      ^bb0(%arg5: memref<2x2xi32>, %arg6: memref<2x2xi32>):
        %c0_5 = arith.constant 0 : index
        %c1_6 = arith.constant 1 : index
        %c2_7 = arith.constant 2 : index
        %c0_8 = arith.constant 0 : index
        %c2_9 = arith.constant 2 : index
        %3 = neura.counter from %c0_8 : index to %c2_9 : index step %c1_6 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
        %c1_10 = arith.constant 1 : index
        %c2_11 = arith.constant 2 : index
        %4 = neura.counter from %c1_10 : index to %c2_11 : index step %c1_6 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
        %5 = memref.load %arg5[%3, %4] : memref<2x2xi32>
        %6 = memref.load %arg6[%4, %3] : memref<2x2xi32>
        %7 = arith.addi %5, %6 : i32
        memref.store %7, %arg5[%3, %4] : memref<2x2xi32>
        neura.yield {yield_type = "void"}
      }
      taskflow.yield done_writes(%arg4 : memref<2x2xi32>)
    }
    %0 = taskflow.join states(%done_writes, %done_writes_0) base(%arg0) axis(1) region([0, 0], [2, 2]) {amoeba.neura.joint_rewrite = "post-neura-mn-tiling", amoeba.semantic.completion_only} : memref<2x2xi32>
    return
  }
}

