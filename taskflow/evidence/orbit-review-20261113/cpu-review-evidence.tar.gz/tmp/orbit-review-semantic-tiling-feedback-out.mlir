module {
  func.func @feedback(%arg0: memref<2x4xi32> {amoeba.noalias}, %arg1: memref<2x4xi32> {amoeba.noalias}) -> memref<2x4xi32> attributes {amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1"} {
    %done_writes = taskflow.task @producer.tile.1.0 will_reads(%arg0 : memref<2x4xi32>) will_writes(%arg1 : memref<2x4xi32>) [original_read_memrefs(%arg0 : memref<2x4xi32>), original_write_memrefs(%arg1 : memref<2x4xi32>)] {amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.task_kind = "gemm_producer", amoeba.semantic.task_role = "producer", amoeba.semantic.tile_axis = 1 : i64, amoeba.semantic.tile_range = array<i64: 0, 2>, amoeba.semantic.tile_size = 2 : i64, amoeba.semantic.tiled_axes = "1", amoeba.tiling.axis = 1 : i64, amoeba.tiling.factor = 2 : i64, amoeba.tiling.input_region_lowers = [array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["proven_rectangular"], amoeba.tiling.input_region_uppers = [array<i64: 2, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>], amoeba.tiling.parent_task = "producer", amoeba.tiling.part_index = 0 : i64} : (memref<2x4xi32>, memref<2x4xi32>) -> (memref<2x4xi32>) {
    ^bb0(%arg2: memref<2x4xi32>, %arg3: memref<2x4xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %c4 = arith.constant 4 : index
      %c10_i32 = arith.constant 10 : i32
      %1 = taskflow.counter from %c0 to %c2 step %c1 : index
      %c0_1 = arith.constant 0 : index
      %c2_2 = arith.constant 2 : index
      %2 = taskflow.counter parent(%1 : index) from %c0_1 to %c2_2 step %c1 : index
      "taskflow.hyperblock"(%1, %2) <{operandSegmentSizes = array<i32: 2, 0>}> ({
      ^bb0(%arg4: index, %arg5: index):
        %3 = memref.load %arg3[%c0, %c0] : memref<2x4xi32>
        %4 = arith.muli %3, %c10_i32 : i32
        %5 = memref.load %arg2[%arg4, %arg5] : memref<2x4xi32>
        %6 = arith.addi %4, %5 : i32
        memref.store %6, %arg3[%c0, %c0] : memref<2x4xi32>
        taskflow.hyperblock.yield
      }) : (index, index) -> ()
      taskflow.yield done_writes(%arg3 : memref<2x4xi32>)
    }
    %done_writes_0 = taskflow.task @producer.tile.1.1 will_reads(%arg0 : memref<2x4xi32>) will_writes(%arg1 : memref<2x4xi32>) [original_read_memrefs(%arg0 : memref<2x4xi32>), original_write_memrefs(%arg1 : memref<2x4xi32>)] {amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.task_kind = "gemm_producer", amoeba.semantic.task_role = "producer", amoeba.semantic.tile_axis = 1 : i64, amoeba.semantic.tile_range = array<i64: 2, 4>, amoeba.semantic.tile_size = 2 : i64, amoeba.semantic.tiled_axes = "1", amoeba.tiling.axis = 1 : i64, amoeba.tiling.factor = 2 : i64, amoeba.tiling.input_region_lowers = [array<i64: 0, 2>], amoeba.tiling.input_region_reasons = ["proven_rectangular"], amoeba.tiling.input_region_uppers = [array<i64: 2, 4>], amoeba.tiling.output_region_lowers = [array<i64: 0, 2>], amoeba.tiling.output_region_uppers = [array<i64: 2, 4>], amoeba.tiling.parent_task = "producer", amoeba.tiling.part_index = 1 : i64} : (memref<2x4xi32>, memref<2x4xi32>) -> (memref<2x4xi32>) {
    ^bb0(%arg2: memref<2x4xi32>, %arg3: memref<2x4xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %c4 = arith.constant 4 : index
      %c10_i32 = arith.constant 10 : i32
      %1 = taskflow.counter from %c0 to %c2 step %c1 : index
      %c2_1 = arith.constant 2 : index
      %c4_2 = arith.constant 4 : index
      %2 = taskflow.counter parent(%1 : index) from %c2_1 to %c4_2 step %c1 : index
      "taskflow.hyperblock"(%1, %2) <{operandSegmentSizes = array<i32: 2, 0>}> ({
      ^bb0(%arg4: index, %arg5: index):
        %3 = memref.load %arg3[%c0, %c0] : memref<2x4xi32>
        %4 = arith.muli %3, %c10_i32 : i32
        %5 = memref.load %arg2[%arg4, %arg5] : memref<2x4xi32>
        %6 = arith.addi %4, %5 : i32
        memref.store %6, %arg3[%c0, %c0] : memref<2x4xi32>
        taskflow.hyperblock.yield
      }) : (index, index) -> ()
      taskflow.yield done_writes(%arg3 : memref<2x4xi32>)
    }
    %0 = taskflow.join states(%done_writes, %done_writes_0) base(%arg1) axis(1) region([0, 0], [2, 4]) {amoeba.semantic.completion_only} : memref<2x4xi32>
    return %0 : memref<2x4xi32>
  }
}

