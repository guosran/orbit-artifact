module {
  func.func @transpose(%arg0: memref<2x2xi32> {amoeba.noalias}, %arg1: memref<2x2xi32> {amoeba.noalias}, %arg2: memref<2x2xi32> {amoeba.noalias}) -> memref<2x2xi32> {
    %done_reads, %done_writes = taskflow.task @producer.fuse.consumer will_reads(%arg0 : memref<2x2xi32>) will_writes(%arg2 : memref<2x2xi32>) [original_read_memrefs(%arg0 : memref<2x2xi32>), original_write_memrefs(%arg2 : memref<2x2xi32>)] {amoeba.semantic.fusion_mode = "producer_consumer", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.task_kind = "fused_producer_consumer", amoeba.semantic.task_role = "fused_producer_consumer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["proven_rectangular"], amoeba.tiling.input_region_uppers = [array<i64: 2, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]} : (memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>, memref<2x2xi32>) {
    ^bb0(%arg3: memref<2x2xi32>, %arg4: memref<2x2xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %c0_0 = arith.constant 0 : index
      %c1_1 = arith.constant 1 : index
      %c2_2 = arith.constant 2 : index
      %0 = taskflow.counter from %c0 to %c2 step %c1 : index
      %1 = taskflow.counter parent(%0 : index) from %c0 to %c2 step %c1 : index
      "taskflow.hyperblock"(%0, %1) <{operandSegmentSizes = array<i32: 2, 0>}> ({
      ^bb0(%arg5: index, %arg6: index):
        %2 = memref.load %arg3[%arg5, %arg6] : memref<2x2xi32>
        memref.store %2, %arg4[%arg5, %arg6] : memref<2x2xi32>
        taskflow.hyperblock.yield
      }) : (index, index) -> ()
      taskflow.yield done_reads(%arg3 : memref<2x2xi32>) done_writes(%arg4 : memref<2x2xi32>)
    }
    return %done_writes : memref<2x2xi32>
  }
}

