module {
 func.func @inplace_alias(%state: memref<2x2xi32>, %input: memref<2x2xi32>) {
  %done = taskflow.task @update will_reads(%state, %input : memref<2x2xi32>, memref<2x2xi32>) will_writes(%state : memref<2x2xi32>) [original_read_memrefs(%state, %input : memref<2x2xi32>, memref<2x2xi32>), original_write_memrefs(%state : memref<2x2xi32>)] : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
   ^bb0(%read: memref<2x2xi32>, %in: memref<2x2xi32>, %write: memref<2x2xi32>):
    %z = arith.constant 0 : index
    %o = arith.constant 1 : index
    %two = arith.constant 2 : index
    %m = taskflow.counter from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
    %n = taskflow.counter parent(%m : index) from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
    neura.kernel inputs(%write, %in : memref<2x2xi32>, memref<2x2xi32>) attributes {accelerator = "neura"} {
     ^bb0(%out: memref<2x2xi32>, %arg: memref<2x2xi32>):
      %zero = arith.constant 0 : index
      %one = arith.constant 1 : index
      %bound = arith.constant 2 : index
      %i = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
      %j = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
      %old = memref.load %out[%i, %j] : memref<2x2xi32>
      %v = memref.load %arg[%j, %i] : memref<2x2xi32>
      %sum = arith.addi %old, %v : i32
      memref.store %sum, %out[%i, %j] : memref<2x2xi32>
      neura.yield {yield_type = "void"}
    }
    taskflow.yield done_writes(%write : memref<2x2xi32>)
  }
  return
 }
}
