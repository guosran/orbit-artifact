module {
  func.func @gcn_memory_feedback_lifetime(%arg0: memref<1x1x4xi32>, %arg1: memref<1x1x4xi32>, %arg2: memref<1x1x4xi32>) -> memref<1x1x4xi32> {
    %c4 = arith.constant 4 : index
    %c0_i32 = arith.constant 0 : i32
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %true = arith.constant true
    %c0_0 = arith.constant 0 : index
    %c1_1 = arith.constant 1 : index
    %c1_2 = arith.constant 1 : index
    %c0_3 = arith.constant 0 : index
    %c2_4 = arith.constant 2 : index
    %c1_5 = arith.constant 1 : index
    %c0_6 = arith.constant 0 : index
    %c1_7 = arith.constant 1 : index
    scf.for %arg3 = %c0_0 to %c1_1 step %c1_2 {
      scf.for %arg4 = %c0_3 to %c2_4 step %c1_5 {
        scf.for %arg5 = %c0_6 to %c4 step %c1_7 {
          %0 = arith.cmpi eq, %arg5, %c0_6 : index
          %c0_8 = arith.constant 0 : index
          %1 = arith.andi %true, %true : i1
          %c0_9 = arith.constant 0 : index
          %2 = arith.cmpi sge, %c0_8, %c0_9 : index
          %c1_10 = arith.constant 1 : index
          %3 = arith.cmpi slt, %c0_8, %c1_10 : index
          %4 = arith.andi %2, %3 : i1
          %5 = arith.andi %1, %4 : i1
          %6 = arith.andi %5, %true : i1
          %c0_11 = arith.constant 0 : index
          %7 = arith.cmpi sge, %arg3, %c0_11 : index
          %c1_12 = arith.constant 1 : index
          %8 = arith.cmpi slt, %arg3, %c1_12 : index
          %9 = arith.andi %7, %8 : i1
          %10 = arith.andi %6, %9 : i1
          %11 = arith.andi %10, %true : i1
          %c0_13 = arith.constant 0 : index
          %12 = arith.cmpi sge, %arg5, %c0_13 : index
          %c4_14 = arith.constant 4 : index
          %13 = arith.cmpi slt, %arg5, %c4_14 : index
          %14 = arith.andi %12, %13 : i1
          %15 = arith.andi %11, %14 : i1
          %16 = scf.if %15 -> (i32) {
            %69 = memref.load %arg0[%c0_8, %arg3, %arg5] : memref<1x1x4xi32>
            scf.yield %69 : i32
          } else {
            %c0_i32_33 = arith.constant 0 : i32
            scf.yield %c0_i32_33 : i32
          }
          %17 = arith.andi %true, %true : i1
          %c0_15 = arith.constant 0 : index
          %18 = arith.cmpi sge, %c0_8, %c0_15 : index
          %c1_16 = arith.constant 1 : index
          %19 = arith.cmpi slt, %c0_8, %c1_16 : index
          %20 = arith.andi %18, %19 : i1
          %21 = arith.andi %17, %20 : i1
          %22 = arith.andi %21, %true : i1
          %c0_17 = arith.constant 0 : index
          %23 = arith.cmpi sge, %arg3, %c0_17 : index
          %c1_18 = arith.constant 1 : index
          %24 = arith.cmpi slt, %arg3, %c1_18 : index
          %25 = arith.andi %23, %24 : i1
          %26 = arith.andi %22, %25 : i1
          %27 = arith.andi %26, %true : i1
          %c0_19 = arith.constant 0 : index
          %28 = arith.cmpi sge, %arg5, %c0_19 : index
          %c4_20 = arith.constant 4 : index
          %29 = arith.cmpi slt, %arg5, %c4_20 : index
          %30 = arith.andi %28, %29 : i1
          %31 = arith.andi %27, %30 : i1
          %32 = scf.if %31 -> (i32) {
            %69 = memref.load %arg1[%c0_8, %arg3, %arg5] : memref<1x1x4xi32>
            scf.yield %69 : i32
          } else {
            %c0_i32_33 = arith.constant 0 : i32
            scf.yield %c0_i32_33 : i32
          }
          %33 = arith.andi %15, %31 : i1
          %34 = arith.muli %16, %32 : i32
          %35 = arith.andi %true, %true : i1
          %c0_21 = arith.constant 0 : index
          %36 = arith.cmpi sge, %c0_8, %c0_21 : index
          %c1_22 = arith.constant 1 : index
          %37 = arith.cmpi slt, %c0_8, %c1_22 : index
          %38 = arith.andi %36, %37 : i1
          %39 = arith.andi %35, %38 : i1
          %40 = arith.andi %39, %true : i1
          %c0_23 = arith.constant 0 : index
          %41 = arith.cmpi sge, %arg3, %c0_23 : index
          %c1_24 = arith.constant 1 : index
          %42 = arith.cmpi slt, %arg3, %c1_24 : index
          %43 = arith.andi %41, %42 : i1
          %44 = arith.andi %40, %43 : i1
          %45 = arith.andi %44, %true : i1
          %c0_25 = arith.constant 0 : index
          %46 = arith.cmpi sge, %arg4, %c0_25 : index
          %c4_26 = arith.constant 4 : index
          %47 = arith.cmpi slt, %arg4, %c4_26 : index
          %48 = arith.andi %46, %47 : i1
          %49 = arith.andi %45, %48 : i1
          %50 = scf.if %49 -> (i32) {
            %69 = memref.load %arg2[%c0_8, %arg3, %arg4] : memref<1x1x4xi32>
            scf.yield %69 : i32
          } else {
            %c0_i32_33 = arith.constant 0 : i32
            scf.yield %c0_i32_33 : i32
          }
          %51 = arith.andi %49, %33 : i1
          %52 = arith.addi %50, %34 : i32
          %53 = arith.andi %51, %true : i1
          %54 = arith.andi %53, %true : i1
          %c0_27 = arith.constant 0 : index
          %55 = arith.cmpi sge, %c0_8, %c0_27 : index
          %c1_28 = arith.constant 1 : index
          %56 = arith.cmpi slt, %c0_8, %c1_28 : index
          %57 = arith.andi %55, %56 : i1
          %58 = arith.andi %54, %57 : i1
          %59 = arith.andi %58, %true : i1
          %c0_29 = arith.constant 0 : index
          %60 = arith.cmpi sge, %arg3, %c0_29 : index
          %c1_30 = arith.constant 1 : index
          %61 = arith.cmpi slt, %arg3, %c1_30 : index
          %62 = arith.andi %60, %61 : i1
          %63 = arith.andi %59, %62 : i1
          %64 = arith.andi %63, %true : i1
          %c0_31 = arith.constant 0 : index
          %65 = arith.cmpi sge, %arg4, %c0_31 : index
          %c4_32 = arith.constant 4 : index
          %66 = arith.cmpi slt, %arg4, %c4_32 : index
          %67 = arith.andi %65, %66 : i1
          %68 = arith.andi %64, %67 : i1
          scf.if %68 {
            memref.store %52, %arg2[%c0_8, %arg3, %arg4] : memref<1x1x4xi32>
          }
        }
      }
    } {amoeba.host.task_completion, amoeba.host.task_name = "Task_16"}
    return %arg1 : memref<1x1x4xi32>
  }
}

