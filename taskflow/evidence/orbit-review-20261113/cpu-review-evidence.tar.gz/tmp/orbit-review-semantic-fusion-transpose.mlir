module {
 func.func @transpose(%a: memref<2x2xi32> {amoeba.noalias}, %t: memref<2x2xi32> {amoeba.noalias}, %d: memref<2x2xi32> {amoeba.noalias}) -> memref<2x2xi32> {
 %p = taskflow.task @producer will_reads(%a : memref<2x2xi32>) will_writes(%t : memref<2x2xi32>) [original_read_memrefs(%a : memref<2x2xi32>), original_write_memrefs(%t : memref<2x2xi32>)] : (memref<2x2xi32>, memref<2x2xi32>) -> memref<2x2xi32> {
 ^bb0(%read: memref<2x2xi32>, %write: memref<2x2xi32>):
 %z = arith.constant 0 : index
 %o = arith.constant 1 : index
 %b = arith.constant 2 : index
 %m = taskflow.counter from %z to %b step %o : index
 %n = taskflow.counter parent(%m : index) from %z to %b step %o : index
 "taskflow.hyperblock"(%m, %n) <{operandSegmentSizes = array<i32: 2, 0>}> ({
 ^bb0(%i: index, %j: index):
 %v = memref.load %read[%i, %j] : memref<2x2xi32>
 memref.store %v, %write[%i, %j] : memref<2x2xi32>
 "taskflow.hyperblock.yield"() <{operandSegmentSizes = array<i32: 0, 0>}> : () -> ()
 }) : (index, index) -> ()
 taskflow.yield done_writes(%write : memref<2x2xi32>)
 }
 %q = taskflow.task @consumer will_reads(%p : memref<2x2xi32>) will_writes(%d : memref<2x2xi32>) [original_read_memrefs(%t : memref<2x2xi32>), original_write_memrefs(%d : memref<2x2xi32>)] : (memref<2x2xi32>, memref<2x2xi32>) -> memref<2x2xi32> {
 ^bb0(%read: memref<2x2xi32>, %write: memref<2x2xi32>):
 %z = arith.constant 0 : index
 %o = arith.constant 1 : index
 %b = arith.constant 2 : index
 %m = taskflow.counter from %z to %b step %o : index
 %n = taskflow.counter parent(%m : index) from %z to %b step %o : index
 "taskflow.hyperblock"(%m, %n) <{operandSegmentSizes = array<i32: 2, 0>}> ({
 ^bb0(%i: index, %j: index):
 %v = memref.load %read[%j, %i] : memref<2x2xi32>
 memref.store %v, %write[%i, %j] : memref<2x2xi32>
 "taskflow.hyperblock.yield"() <{operandSegmentSizes = array<i32: 0, 0>}> : () -> ()
 }) : (index, index) -> ()
 taskflow.yield done_writes(%write : memref<2x2xi32>)
 }
return %q : memref<2x2xi32>
 }
}
