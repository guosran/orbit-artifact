module {
  func.func private @touch(%arg0: memref<4xi32>, %arg1: memref<4xi32>) {
    %c3 = arith.constant 3 : index
    %0 = memref.load %arg1[%c3] : memref<4xi32>
    memref.store %0, %arg0[%c3] : memref<4xi32>
    return
  }
  func.func @opaque_second(%arg0: memref<4xi32> {amoeba.logical_transfer_shape = array<i64: 4>, amoeba.noalias}, %arg1: memref<4xi32> {amoeba.active_transfer_capacity_shape = array<i64: 4>, amoeba.active_transfer_proof = {accesses = [{axes = [{lower = 0 : i64, proven = true, route = "authenticated-constant", upper = 1 : i64}], operation = "memref.load", ordinal = 1 : i64, proven = true, task = "opaque"}], active_shape = array<i64: 1>, argument = 1 : i64, caller_evidence = "fixture-caller.mlir", caller_function = "main", caller_noalias_proven = true, caller_prepared_input = "fixture-prepared.mlir", caller_proof_mode = "prepared-external-caller", capacity_present = true, capacity_shape = array<i64: 4>, function = "opaque_second", noalias_arguments = [{index = 0 : i64, proven = true}, {index = 1 : i64, proven = true}], reasons = [], schema = "orbit-static-active-transfer-proof-v1", status = "proven"}, amoeba.active_transfer_shape = array<i64: 1>, amoeba.logical_transfer_shape = array<i64: 4>, amoeba.noalias}) attributes {amoeba.input0_caller_evidence_path = "fixture-caller.mlir", amoeba.input0_caller_function = "main", amoeba.input0_caller_noalias_proof_mode = "prepared-external-caller", amoeba.input0_caller_noalias_proven, amoeba.input0_caller_prepared_input_path = "fixture-prepared.mlir"} {
    %done_reads:2 = taskflow.task @opaque will_reads(%arg0, %arg1 : memref<4xi32>, memref<4xi32>) [original_read_memrefs(%arg0, %arg1 : memref<4xi32>, memref<4xi32>)] : (memref<4xi32>, memref<4xi32>) -> (memref<4xi32>, memref<4xi32>) {
    ^bb0(%arg2: memref<4xi32>, %arg3: memref<4xi32>):
      func.call @touch(%arg2, %arg3) : (memref<4xi32>, memref<4xi32>) -> ()
      %c0 = arith.constant 0 : index
      %0 = memref.load %arg3[%c0] : memref<4xi32>
      taskflow.yield done_reads(%arg2, %arg3 : memref<4xi32>, memref<4xi32>)
    }
    return
  }
}

