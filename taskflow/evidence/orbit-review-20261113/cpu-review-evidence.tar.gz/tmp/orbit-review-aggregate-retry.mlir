module {
func.func @aggregate(%a: memref<4xi32>) attributes {joint_scheduling_candidate_id = "candidate-0"} {
 %p = taskflow.task @p will_writes(%a : memref<4xi32>) [original_write_memrefs(%a : memref<4xi32>)] {cgra_count = 4 : i32, cgra_shape = "2x2", amoeba.joint_shape_orientation_fixed, amoeba.aggregate_active_replicas = 4 : i32, est_latency = 1 : i64} : (memref<4xi32>) -> memref<4xi32> {
 ^bb0(%out: memref<4xi32>):
  taskflow.yield done_writes(%out : memref<4xi32>)
 }
 return
}
}
