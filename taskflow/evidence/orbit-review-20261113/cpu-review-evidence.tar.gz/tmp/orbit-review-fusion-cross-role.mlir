module {
 func.func @fusion_alias(%state: memref<2x2xi32> {amoeba.noalias}, %input: memref<2x2xi32> {amoeba.noalias}) {
  %produced = taskflow.task @producer will_reads(%input : memref<2x2xi32>) will_writes(%state : memref<2x2xi32>) [original_read_memrefs(%input : memref<2x2xi32>), original_write_memrefs(%state : memref<2x2xi32>)] : (memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
   ^bb0(%in: memref<2x2xi32>, %write: memref<2x2xi32>):
    %z = arith.constant 0 : index
    %o = arith.constant 1 : index
    %two = arith.constant 2 : index
    %m = taskflow.counter from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
    %n = taskflow.counter parent(%m : index) from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
    neura.kernel inputs(%write, %in : memref<2x2xi32>, memref<2x2xi32>) attributes {accelerator = "neura"} {
     ^bb0(%out: memref<2x2xi32>, %arg: memref<2x2xi32>):
      %zero = arith.constant 0 : index
      %one = arith.constant 1 : index
      %bound = arith.constant 2 : index
      %i = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
      %j = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
      %v = memref.load %arg[%i, %j] : memref<2x2xi32>
      memref.store %v, %out[%i, %j] : memref<2x2xi32>
      neura.yield {yield_type = "void"}
    }
    taskflow.yield done_writes(%write : memref<2x2xi32>)
  }
  %consumed = taskflow.task @consumer will_reads(%produced : memref<2x2xi32>) will_writes(%input : memref<2x2xi32>) [original_read_memrefs(%state : memref<2x2xi32>), original_write_memrefs(%input : memref<2x2xi32>)] : (memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
   ^bb0(%in: memref<2x2xi32>, %write: memref<2x2xi32>):
    %z = arith.constant 0 : index
    %o = arith.constant 1 : index
    %two = arith.constant 2 : index
    %m = taskflow.counter from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
    %n = taskflow.counter parent(%m : index) from %z to %two step %o attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
    neura.kernel inputs(%write, %in : memref<2x2xi32>, memref<2x2xi32>) attributes {accelerator = "neura"} {
     ^bb0(%out: memref<2x2xi32>, %arg: memref<2x2xi32>):
      %zero = arith.constant 0 : index
      %one = arith.constant 1 : index
      %bound = arith.constant 2 : index
      %i = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
      %j = neura.counter from %zero : index to %bound : index step %one : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
      %v = memref.load %arg[%i, %j] : memref<2x2xi32>
      memref.store %v, %out[%j, %i] : memref<2x2xi32>
      neura.yield {yield_type = "void"}
    }
    taskflow.yield done_writes(%write : memref<2x2xi32>)
  }
  return
 }
}
