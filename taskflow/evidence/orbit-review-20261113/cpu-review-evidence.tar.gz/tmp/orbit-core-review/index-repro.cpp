#include "Taskflow/ProgramMapping.h"
#include "TaskflowDialect/TaskflowDialect.h"
#include "mlir/Dialect/Affine/IR/AffineOps.h"
#include "mlir/Dialect/Arith/IR/Arith.h"
#include "mlir/Dialect/MemRef/IR/MemRef.h"
#include "mlir/Parser/Parser.h"
#include <iostream>
using namespace orbit::taskflow;
int main(){ mlir::DialectRegistry registry;registry.insert<mlir::taskflow::TaskflowDialect,mlir::affine::AffineDialect,mlir::arith::ArithDialect,mlir::memref::MemRefDialect,mlir::func::FuncDialect>();mlir::MLIRContext context(registry);
 auto m=mlir::parseSourceString<mlir::ModuleOp>(R"mlir(module {
 func.func @copy(%a: memref<16xindex> {orbit.role="input",orbit.name="A"}, %b: memref<16xindex> {orbit.role="output",orbit.name="B"}) attributes {orbit.noalias} {
  %d = taskflow.task @copy will_reads(%a : memref<16xindex>) will_writes(%b : memref<16xindex>) [original_read_memrefs(%a : memref<16xindex>), original_write_memrefs(%b : memref<16xindex>)] : (memref<16xindex>,memref<16xindex>) -> memref<16xindex> {
  ^bb0(%in: memref<16xindex>,%out: memref<16xindex>):
   affine.for %i=0 to 16 { %v=affine.load %in[%i] : memref<16xindex>
     affine.store %v,%out[%i] : memref<16xindex> }
   taskflow.yield done_writes(%out : memref<16xindex>) }
 return }
})mlir",&context);GenericAnalysis a;std::string error;bool ok=m && analyzeGenericProgram(*m,a,error);std::cerr<<"analysis="<<ok<<" "<<error<<std::endl;
 StaticConfig t;t.resources={{"cpu","compute","cpu",1}};t.memories={{"dram",4096,{"cpu"}}};t.assumptions.initialLocations={{"A","dram"}};t.assumptions.outputLocations={{"B","dram"}};
 ProgramDataOrganizationChoice c;c.placements={{0,"cpu","dram","scalar"}};ProgramGraph g;ok=planProgramDataOrganization(a,t,c,g,error);std::cout<<"planning="<<ok<<" "<<error<<std::endl;
}
