#include "Taskflow/ProgramMapping.h"
#include <iostream>
using namespace orbit::taskflow;
int main(){ ProgramGraph g;
 g.resources={{"c0","compute","cpu",1},{"c1","compute","cpu",1}};
 g.memories={{"m",1024,{"cpu"}}};
 for(int i=0;i<2;++i){ MappingEvent e;e.kind="compute";e.resource="c"+std::to_string(i);g.events.push_back(e); MappingTaskInstance t;t.event=i;g.instances.push_back(t);ProgramExecutionGroup x;x.resource=e.resource;x.memory="m";x.memberEvents={size_t(i)};g.executionGroups.push_back(x);}
 g.executionGroups[1].implementationDependencies={0};
 auto &s=g.schedule;s.policy="constraint-resource-schedule";s.modelIdentity="model";s.timingBoundary="wall";s.eventDurationsMs={1,1};s.estimatedMakespanMs=2.;
 s.events={{0,{},1.,2.},{1,{},0.,1.}};
 s.configurations={{{1},0.,1.,0.},{{0},1.,2.,0.}};
 std::string error;bool ok=checkProgramResourceSchedule(g,error);std::cout<<"reversed_group_order_accepted="<<ok<<" error="<<error<<"\n";
}
