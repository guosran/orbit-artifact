#include "Taskflow/GenericReuse.h"
#include "TaskflowDialect/TaskflowDialect.h"
#include "mlir/Dialect/Affine/IR/AffineOps.h"
#include "mlir/Dialect/Arith/IR/Arith.h"
#include "mlir/Dialect/MemRef/IR/MemRef.h"
#include "mlir/Parser/Parser.h"
#include <iostream>
using namespace orbit::taskflow;
int main(){ mlir::DialectRegistry registry;registry.insert<mlir::taskflow::TaskflowDialect,mlir::affine::AffineDialect,mlir::arith::ArithDialect,mlir::memref::MemRefDialect,mlir::func::FuncDialect>();mlir::MLIRContext context(registry);
 auto m=mlir::parseSourceString<mlir::ModuleOp>(R"mlir(module {
 func.func @copy(%a: memref<16xf32> {orbit.role="input",orbit.name="A"}, %b: memref<16xf32> {orbit.role="output",orbit.name="B"}) attributes {orbit.noalias} {
  %d = taskflow.task @copy will_reads(%a : memref<16xf32>) will_writes(%b : memref<16xf32>) [original_read_memrefs(%a : memref<16xf32>), original_write_memrefs(%b : memref<16xf32>)] : (memref<16xf32>,memref<16xf32>) -> memref<16xf32> {
  ^bb0(%in: memref<16xf32>,%out: memref<16xf32>):
   affine.for %i=0 to 16 { %v=affine.load %in[%i] : memref<16xf32>
     affine.store %v,%out[%i] : memref<16xf32> }
   taskflow.yield done_writes(%out : memref<16xf32>) }
 return }
})mlir",&context);GenericAnalysis a;std::string error;bool ok=m && analyzeGenericProgram(*m,a,error);std::cerr<<"analysis="<<ok<<" "<<error<<std::endl;
 GenericReuseOptions o;o.currentTile={0,1,1};o.requireDivisible=true;o.includeBaseline=true;auto r=discoverGenericReuseConfigurations(a,llvm::json::Object{},o);std::cout<<r.stopReason<<std::endl;
}
