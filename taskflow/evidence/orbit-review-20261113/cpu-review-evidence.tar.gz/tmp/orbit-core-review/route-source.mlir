module {
 func.func @copy(%a: memref<16xf32> {orbit.role="input",orbit.name="A"}, %b: memref<16xf32> {orbit.role="output",orbit.name="B"}) attributes {orbit.noalias} {
  %d = taskflow.task @copy will_reads(%a : memref<16xf32>) will_writes(%b : memref<16xf32>) [original_read_memrefs(%a : memref<16xf32>), original_write_memrefs(%b : memref<16xf32>)] : (memref<16xf32>,memref<16xf32>) -> memref<16xf32> {
  ^bb0(%in: memref<16xf32>,%out: memref<16xf32>):
   affine.for %i=0 to 16 { %v=affine.load %in[%i] : memref<16xf32>
     affine.store %v,%out[%i] : memref<16xf32> }
   taskflow.yield done_writes(%out : memref<16xf32>) }
 return }
}