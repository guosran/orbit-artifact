#include "Taskflow/StaticMapping.h"
#include <iostream>
using namespace orbit::taskflow;
int main(){ StaticConfig c; c.resources={{"a","compute","cpu",1},{"b","compute","cpu",1},{"shared","shared","cpu",1}}; c.resources[0].sharedResources={{"shared",1}};c.resources[1].sharedResources={{"shared",1}};c.assumptions.overlap="explicit";StaticPlan p; for(const char *id:{"a","b"}){StaticEvent e;e.id=id;e.kind="compute";e.durationMs=1;e.resourceDemands={{id,1}};p.events.push_back(e);}std::string error;std::cout<<scheduleStaticPlan(p,c,error)<<" "<<p.events[0].startMs<<" "<<p.events[1].startMs<<" makespan="<<p.totals.makespanMs<<" error="<<error<<"\n";}
