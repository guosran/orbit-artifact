#include "Taskflow/ProgramBeamSearch.h"
#include <chrono>
#include <iostream>
using namespace orbit::taskflow;
int main(){ProgramSearchSpace s;ProgramSearchDimension d;d.id="x";d.choices={{"zero",nullptr},{"one",nullptr}};s.dimensions={d};ProgramSearchConstraint c;c.dimensions={0};c.allowedTuples.resize(100000,std::vector<int64_t>{0});c.allowedTuples.push_back({1});s.constraints.push_back(c);ProgramBeamInitialStates initial;initial.assignments.resize(20000,std::vector<int64_t>{1});ProgramSearchOptions o;o.wallSeconds=.2;o.maxTupleCells=200000;int calls=0;auto begin=std::chrono::steady_clock::now();auto r=searchProgramSpaceBeam(s,[&](auto&){++calls;return ProgramSearchEvaluation{};},o,1,-1,0,{}, {},initial);std::cout<<"elapsed_ms="<<std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count()<<" calls="<<calls<<" status="<<constraintSearchStatusName(r.status)<<"\n";}
