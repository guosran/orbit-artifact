module {
  func.func @network_cache(%arg0: memref<4xi32>, %arg1: memref<4xi32>) attributes {amoeba.graph_variant_id = "g"} {
    %done_writes = taskflow.task @p will_writes(%arg0 : memref<4xi32>) [original_write_memrefs(%arg0 : memref<4xi32>)] : (memref<4xi32>) -> (memref<4xi32>) {
    ^bb0(%arg2: memref<4xi32>):
      taskflow.yield done_writes(%arg2 : memref<4xi32>)
    }
    %done_writes_0 = taskflow.task @q will_reads(%done_writes : memref<4xi32>) will_writes(%arg1 : memref<4xi32>) [original_read_memrefs(%arg0 : memref<4xi32>), original_write_memrefs(%arg1 : memref<4xi32>)] : (memref<4xi32>, memref<4xi32>) -> (memref<4xi32>) {
    ^bb0(%arg2: memref<4xi32>, %arg3: memref<4xi32>):
      taskflow.yield done_writes(%arg3 : memref<4xi32>)
    }
    return
  }
}

