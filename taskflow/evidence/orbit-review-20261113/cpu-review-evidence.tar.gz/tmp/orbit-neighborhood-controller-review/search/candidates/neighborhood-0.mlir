"builtin.module"() ({
  "func.func"() <{function_type = (memref<4xi32>, memref<4xi32>) -> (), sym_name = "network_cache"}> ({
  ^bb0(%arg0: memref<4xi32>, %arg1: memref<4xi32>):
    %0 = "taskflow.task"(%arg0, %arg0) <{operandSegmentSizes = array<i32: 0, 1, 0, 0, 1>, resultSegmentSizes = array<i32: 0, 1, 0>, task_name = "p"}> ({
    ^bb0(%arg4: memref<4xi32>):
      "taskflow.yield"(%arg4) <{operandSegmentSizes = array<i32: 0, 1, 0>}> : (memref<4xi32>) -> ()
    }) : (memref<4xi32>, memref<4xi32>) -> memref<4xi32>
    %1 = "taskflow.task"(%0, %arg1, %arg0, %arg1) <{operandSegmentSizes = array<i32: 1, 1, 0, 1, 1>, resultSegmentSizes = array<i32: 0, 1, 0>, task_name = "q"}> ({
    ^bb0(%arg2: memref<4xi32>, %arg3: memref<4xi32>):
      "taskflow.yield"(%arg3) <{operandSegmentSizes = array<i32: 0, 1, 0>}> : (memref<4xi32>) -> ()
    }) : (memref<4xi32>, memref<4xi32>, memref<4xi32>, memref<4xi32>) -> memref<4xi32>
    "func.return"() : () -> ()
  }) {amoeba.graph_variant_id = "graph-0"} : () -> ()
}) : () -> ()

