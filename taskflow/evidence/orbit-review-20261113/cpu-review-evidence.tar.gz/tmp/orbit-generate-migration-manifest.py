import collections,json,math,subprocess
from pathlib import Path
BASE='a57376e7043b1681e64e7169c5a8cb02eb192331'
original=json.loads(Path('/tmp/orbit-review-inventory-v1.json').read_text())
initial={}
for line in subprocess.check_output(['git','diff','--numstat','--no-renames',BASE,'e850af2'],text=True).splitlines():
 a,d,p=line.split('\t',2);initial[p]=dict(added=int(a),deleted=int(d))
vendor={r['path']:r for r in json.loads(Path('/tmp/orbit-vendor-review-inventory.json').read_text())['files']}
final={}
for line in subprocess.check_output(['git','diff','--numstat','--no-renames',BASE],text=True).splitlines():
 a,d,p=line.split('\t',2);final[p]=(int(a),int(d))

phases={
 'B':('Build and dialect interfaces',[]),
 'C1':('Core representation and source semantics',['B']),
 'C2':('Static mapping, resources and independent checking',['C1']),
 'C3':('Native analysis and data organization',['C1','C2']),
 'C4':('Public ProgramGraph and timing',['C3']),
 'C5':('Native structural actions and reuse',['C3','C4']),
 'C6':('Search, beam and continuation',['C4','C5']),
 'C7':('Constraint models and optional solver adapters',['C4']),
 'A':('AIR lowering and actual implementation checking',['C4','C5']),
 'N1':('Neura graph contracts and rewrite legality',['B']),
 'N2':('Neura cost, predictor and original-profile adapters',['N1']),
 'N3':('Neura scoring, ranking and neighborhood search',['N1','N2']),
 'E':('Companion runtime experiments and reproduction',['C6','A']),
 'D':('Design documentation and historical-report disposition',['C6','A','N3']),
 'V':('Locally modified Neura upstream changes',[]),
}

def phase(p):
 name=Path(p).name.lower()
 if p.startswith('docs/'):return 'D'
 if p.startswith('experimental/') or (p.startswith('scripts/') and p not in ('scripts/build-core.sh','scripts/check-pr-size.py')):return 'E'
 if p.startswith('thirdparty/'):return 'V'
 if p.startswith(('lib/TaskflowAIR/','test/TaskflowAIR/')):return 'A'
 if p.startswith(('lib/Backend/','include/Backend/','lib/Conversion/','include/Conversion/','test/multi-cgra/')):
  if any(s in name for s in ('neighborhood','closure','score','cache','rank','schedule','order','replay')):return 'N3'
  if any(s in name for s in ('cost','predict','retim','feature','profile','mlp')):return 'N2'
  return 'N1'
 if name=='cmakelists.txt' or p in ('.clang-format','.gitignore','UPSTREAM_PROVENANCE.json','scripts/build-core.sh','scripts/check-pr-size.py') or p.startswith(('lib/TaskflowDialect/','include/TaskflowDialect/','tools/mlir-amoeba-opt/')):return 'B'
 if p.startswith('test/TaskflowCore/'):return 'C1'
 if p.startswith(('test/TaskflowMapping/','test/TaskflowValidation/')):return 'C2'
 if 'joint' in name or 'cpsat' in name or 'constraint' in name or 'optimality' in name or 'solver' in name:return 'C7'
 if any(x in name for x in ('beam','search','native-transforms','nativetransforms')):return 'C6'
 if any(x in name for x in ('reuse','til','partition','group','implementation')):return 'C5'
 if any(x in name for x in ('program','timing','invocation','mechanism','sync','device','computeestimate','transfer')):return 'C4'
 if any(x in name for x in ('generic','analysis','data-organization','organization','mappingregion','mappingcopy','mappingversion')):return 'C3'
 if any(x in name for x in ('static','mapping','resource','schedule','checker')):return 'C2'
 return 'C1'

rows=[]
for p in sorted(initial.keys() | final.keys()):
 old=initial.get(p,{'added':0,'deleted':0});a,d=final.get(p,(0,0))
 status='retain-feature';group=None;amount=a+d
 if p in vendor:
  status='inherited-neura' if vendor[p]['status']=='inherited-exact' else 'neura-upstream-patch'
  if status=='inherited-neura':amount=0
  else:
   # Whole-file vendor counts are publication noise. Budget only real local
   # deltas against the pinned Neura source, supplied by the separate inventory.
   upstream=subprocess.check_output(['git','show','2c8f524f81135d50bcce507ec1599a264aa03571:'+vendor[p]['upstream_path']])
   tmp=Path('/tmp/orbit-neura-budget-base');tmp.write_bytes(upstream)
   run=subprocess.run(['git','diff','--no-index','--numstat',str(tmp),p],text=True,capture_output=True)
   x,y,_=run.stdout.strip().split('\t',2);amount=int(x)+int(y)
   group='V'
 elif p in initial and old['added']==0 and not Path(p).is_file():status='preserve-amoeba-publication-omission';amount=0
 elif p in initial and not Path(p).is_file():status='retired-preserved-snapshot';amount=0
 elif p in ('thirdparty/neura','thirdparty/cgra-ii-predictor'):status='preserve-upstream-dependency-boundary';amount=0
 elif p.startswith('docs/orbit-amoeba-') or p=='docs/repository-layout.md':status='review-maintenance';amount=0
 if amount and not group:group=phase(p)
 row=dict(path=p,original_added=old['added'],original_deleted=old['deleted'],final_added=a,final_deleted=d,disposition=status)
 if group:row.update(series=group,payload_lines=amount)
 rows.append(row)
# Allocate estimates within each responsibility series. New upstream review
# units reserve 200 changed lines for tests/glue; oversized files need logical
# extraction before migration, never arbitrary nonbuilding line fragments.
summary={}
for key,(title,deps) in phases.items():
 unit=0;used=0;payload=0;split=[]
 for row in [r for r in rows if r.get('series')==key]:
  amount=row['payload_lines'];payload+=amount
  if amount>800:
   count=math.ceil(amount/800);first=unit+1;unit+=count;used=0
   row['review_units']=f'{key}-{first:03d}..{key}-{unit:03d}'
   row['requires_responsibility_extraction']=True;split.append(row['path'])
  else:
   if not unit or used+amount>800:unit+=1;used=0
   row['review_units']=f'{key}-{unit:03d}';used+=amount
 summary[key]=dict(title=title,dependencies=deps,payload_lines=payload,estimated_review_units=unit,files_needing_extraction=split)
Path('docs/orbit-amoeba-migration-manifest.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in rows))
Path('/tmp/orbit-review-migration-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
counts=collections.Counter(r['disposition'] for r in rows)
print(json.dumps(dict(paths=len(rows),dispositions=counts,total_payload_lines=sum(s['payload_lines'] for s in summary.values()),estimated_review_units=sum(s['estimated_review_units'] for s in summary.values()),series={k:{a:v for a,v in s.items() if a!='files_needing_extraction'} for k,s in summary.items()}),indent=2))
