module {
  func.func @prefix_sum(%a: memref<4xi32> {amoeba.noalias}, %y: memref<4xi32> {amoeba.noalias}) -> memref<4xi32> {
    %zero_value = arith.constant 0 : i32
    %out = taskflow.task @prefix will_reads(%a : memref<4xi32>) will_writes(%y : memref<4xi32>) value_inputs(%zero_value : i32)
      [original_read_memrefs(%a : memref<4xi32>), original_write_memrefs(%y : memref<4xi32>)]
      : (memref<4xi32>, memref<4xi32>, i32) -> (memref<4xi32>) {
    ^bb0(%read: memref<4xi32>, %write: memref<4xi32>, %init: i32):
      %zero = arith.constant 0 : index
      %one = arith.constant 1 : index
      %four = arith.constant 4 : index
      %counter = taskflow.counter from %zero to %four step %one : index
      %unused = "taskflow.hyperblock"(%counter, %init) <{operandSegmentSizes = array<i32: 1, 1>}> ({
      ^bb0(%i: index, %carry: i32):
        %value = memref.load %read[%i] : memref<4xi32>
        %next = arith.addi %carry, %value : i32
        memref.store %next, %write[%i] : memref<4xi32>
        "taskflow.hyperblock.yield"(%next, %next) <{operandSegmentSizes = array<i32: 1, 1>}> : (i32, i32) -> ()
      }) : (index, i32) -> i32
      taskflow.yield done_writes(%write : memref<4xi32>)
    }
    return %out : memref<4xi32>
  }
}
