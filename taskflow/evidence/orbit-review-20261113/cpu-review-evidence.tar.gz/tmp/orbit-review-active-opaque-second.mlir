module {
 func.func private @touch(%x: memref<4xi32>, %y: memref<4xi32>) {
 %last = arith.constant 3 : index
 %v = memref.load %y[%last] : memref<4xi32>
 memref.store %v, %x[%last] : memref<4xi32>
 return
 }
 func.func @opaque_second(%a: memref<4xi32> {amoeba.logical_transfer_shape = array<i64: 4>, amoeba.noalias}, %b: memref<4xi32> {amoeba.logical_transfer_shape = array<i64: 4>, amoeba.noalias}) attributes {
 amoeba.input0_caller_evidence_path = "fixture-caller.mlir",
 amoeba.input0_caller_function = "main",
 amoeba.input0_caller_noalias_proof_mode = "prepared-external-caller",
 amoeba.input0_caller_noalias_proven,
 amoeba.input0_caller_prepared_input_path = "fixture-prepared.mlir"
 } {
 %done:2 = taskflow.task @opaque will_reads(%a, %b : memref<4xi32>, memref<4xi32>) [original_read_memrefs(%a, %b : memref<4xi32>, memref<4xi32>)] : (memref<4xi32>, memref<4xi32>) -> (memref<4xi32>, memref<4xi32>) {
 ^bb0(%ta: memref<4xi32>, %tb: memref<4xi32>):
  func.call @touch(%ta, %tb) : (memref<4xi32>, memref<4xi32>) -> ()
  %zero = arith.constant 0 : index
  %v = memref.load %tb[%zero] : memref<4xi32>
  taskflow.yield done_reads(%ta, %tb : memref<4xi32>, memref<4xi32>)
 }
 return
 }
}
