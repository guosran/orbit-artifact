module {
  func.func @nonadditive(%arg0: memref<2x2xi32> {amoeba.noalias}, %arg1: memref<2x2xi32> {amoeba.noalias}, %arg2: memref<2x2xi32> {amoeba.noalias}, %arg3: memref<2x2xi32> {amoeba.noalias}, %arg4: memref<2x2xi32> {amoeba.noalias}, %arg5: memref<2x2xi32> {amoeba.noalias}) {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0_0 = arith.constant 0 : index
    %c1_1 = arith.constant 1 : index
    %c2_2 = arith.constant 2 : index
    scf.for %arg6 = %c0_0 to %c2_2 step %c1_1 {
      scf.for %arg7 = %c0_0 to %c2_2 step %c1_1 {
        %0 = memref.load %arg2[%arg6, %arg7] : memref<2x2xi32>
        %1 = scf.for %arg8 = %c0_0 to %c2_2 step %c1_1 iter_args(%arg9 = %0) -> (i32) {
          %2 = memref.load %arg0[%arg6, %arg8] : memref<2x2xi32>
          %3 = memref.load %arg1[%arg8, %arg7] : memref<2x2xi32>
          %4 = arith.muli %2, %3 : i32
          %5 = arith.muli %arg9, %4 : i32
          scf.yield %5 : i32
        }
        memref.store %1, %arg3[%arg6, %arg7] : memref<2x2xi32>
      }
    } {amoeba.host.task_completion, amoeba.host.task_name = "producer"}
    memref.copy %arg3, %arg5 {amoeba.host.task_completion, amoeba.host.task_name = "consumer"} : memref<2x2xi32> to memref<2x2xi32>
    return
  }
}

