module {
  func.func @pipeline(%arg0: memref<16xf32> {orbit.name = "A", orbit.role = "input"}, %arg1: memref<16xf32> {orbit.name = "B", orbit.role = "input"}, %arg2: memref<16xf32> {orbit.name = "C", orbit.role = "output"}) attributes {orbit.noalias} {
    %alloc = memref.alloc() {orbit.name = "T"} : memref<16xf32>
    %alloc_0 = memref.alloc() {orbit.name = "U"} : memref<16xf32>
    %done_writes = taskflow.task @add will_reads(%arg0, %arg1 : memref<16xf32>, memref<16xf32>) will_writes(%alloc : memref<16xf32>) [original_read_memrefs(%arg0, %arg1 : memref<16xf32>, memref<16xf32>), original_write_memrefs(%alloc : memref<16xf32>)] {orbit.search_origin = 0 : i64} : (memref<16xf32>, memref<16xf32>, memref<16xf32>) -> (memref<16xf32>) {
    ^bb0(%arg3: memref<16xf32>, %arg4: memref<16xf32>, %arg5: memref<16xf32>):
      affine.for %arg6 = 0 to 16 {
        %0 = affine.load %arg3[%arg6] : memref<16xf32>
        %1 = affine.load %arg4[%arg6] : memref<16xf32>
        %2 = arith.addf %0, %1 : f32
        affine.store %2, %arg5[%arg6] : memref<16xf32>
      }
      taskflow.yield done_writes(%arg5 : memref<16xf32>)
    }
    %done_writes_1 = taskflow.task @scale will_reads(%done_writes : memref<16xf32>) will_writes(%alloc_0 : memref<16xf32>) [original_read_memrefs(%done_writes : memref<16xf32>), original_write_memrefs(%alloc_0 : memref<16xf32>)] {orbit.search_origin = 1 : i64} : (memref<16xf32>, memref<16xf32>) -> (memref<16xf32>) {
    ^bb0(%arg3: memref<16xf32>, %arg4: memref<16xf32>):
      %cst = arith.constant 2.000000e+00 : f32
      affine.for %arg5 = 0 to 16 {
        %0 = affine.load %arg3[%arg5] : memref<16xf32>
        %1 = arith.mulf %0, %cst : f32
        affine.store %1, %arg4[%arg5] : memref<16xf32>
      }
      taskflow.yield done_writes(%arg4 : memref<16xf32>)
    }
    %done_writes_2 = taskflow.task @finish will_reads(%done_writes_1, %arg1 : memref<16xf32>, memref<16xf32>) will_writes(%arg2 : memref<16xf32>) [original_read_memrefs(%done_writes_1, %arg1 : memref<16xf32>, memref<16xf32>), original_write_memrefs(%arg2 : memref<16xf32>)] {orbit.search_origin = 2 : i64} : (memref<16xf32>, memref<16xf32>, memref<16xf32>) -> (memref<16xf32>) {
    ^bb0(%arg3: memref<16xf32>, %arg4: memref<16xf32>, %arg5: memref<16xf32>):
      affine.for %arg6 = 0 to 16 {
        %0 = affine.load %arg3[%arg6] : memref<16xf32>
        %1 = affine.load %arg4[%arg6] : memref<16xf32>
        %2 = arith.addf %0, %1 : f32
        affine.store %2, %arg5[%arg6] : memref<16xf32>
      }
      taskflow.yield done_writes(%arg5 : memref<16xf32>)
    }
    memref.dealloc %alloc_0 : memref<16xf32>
    memref.dealloc %alloc : memref<16xf32>
    return
  }
}
