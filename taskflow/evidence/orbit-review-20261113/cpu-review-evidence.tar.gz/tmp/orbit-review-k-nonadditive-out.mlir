module {
  func.func @nonadditive(%arg0: memref<2x2xi32> {amoeba.noalias}, %arg1: memref<2x2xi32> {amoeba.noalias}, %arg2: memref<2x2xi32> {amoeba.noalias}, %arg3: memref<2x2xi32> {amoeba.noalias}, %arg4: memref<2x2xi32> {amoeba.noalias}, %arg5: memref<2x2xi32> {amoeba.noalias}) attributes {amoeba.semantic.k_policy = "parallel", amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1"} {
    %alloc = memref.alloc() {amoeba.semantic.logical_k_block = 0 : i64, amoeba.semantic.private_partial} : memref<2x2xi32>
    %done_writes = taskflow.task @partial_k.0 will_reads(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>) will_writes(%alloc : memref<2x2xi32>) [original_read_memrefs(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>), original_write_memrefs(%alloc : memref<2x2xi32>)] {amoeba.semantic.K_range = array<i64: 0, 1>, amoeba.semantic.M_range = array<i64: 0, 2>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.incoming_edges = [], amoeba.semantic.k_block_count = 2 : i64, amoeba.semantic.k_block_index = 0 : i64, amoeba.semantic.k_policy = "parallel", amoeba.semantic.k_tiled, amoeba.semantic.logical_k_block = 0 : i64, amoeba.semantic.output_visibility = "private_partial", amoeba.semantic.partial_buffer = "partial_k.0", amoeba.semantic.private_partial, amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "gemm_producer", amoeba.semantic.task_role = "producer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["private_partial", "private_partial"], amoeba.tiling.input_region_uppers = [array<i64: 2, 1>, array<i64: 1, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]} : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
    ^bb0(%arg6: memref<2x2xi32>, %arg7: memref<2x2xi32>, %arg8: memref<2x2xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %0 = taskflow.counter from %c0 to %c2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
      %1 = taskflow.counter parent(%0 : index) from %c0 to %c2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
      neura.kernel inputs(%arg6, %arg7, %arg8 : memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) attributes {accelerator = "neura"} {
      ^bb0(%arg9: memref<2x2xi32>, %arg10: memref<2x2xi32>, %arg11: memref<2x2xi32>):
        %c0_4 = arith.constant 0 : index
        %c1_5 = arith.constant 1 : index
        %c1_6 = arith.constant 1 : index
        %c0_i32 = arith.constant 0 : i32
        %c0_7 = arith.constant 0 : index
        %c1_8 = arith.constant 1 : index
        %c2_9 = arith.constant 2 : index
        %2 = neura.counter from %c0_7 : index to %c2_9 : index step %c1_8 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
        %3 = neura.counter from %c0_7 : index to %c2_9 : index step %c1_8 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
        %4 = scf.for %arg12 = %c0_4 to %c1_5 step %c1_6 iter_args(%arg13 = %c0_i32) -> (i32) {
          %5 = memref.load %arg9[%2, %arg12] : memref<2x2xi32>
          %6 = memref.load %arg10[%arg12, %3] : memref<2x2xi32>
          %7 = arith.muli %5, %6 : i32
          %8 = arith.muli %arg13, %7 : i32
          scf.yield %8 : i32
        }
        memref.store %4, %arg11[%2, %3] : memref<2x2xi32>
        neura.yield
      }
      taskflow.yield done_writes(%arg8 : memref<2x2xi32>)
    }
    %alloc_0 = memref.alloc() {amoeba.semantic.logical_k_block = 1 : i64, amoeba.semantic.private_partial} : memref<2x2xi32>
    %done_writes_1 = taskflow.task @partial_k.1 will_reads(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>) will_writes(%alloc_0 : memref<2x2xi32>) [original_read_memrefs(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>), original_write_memrefs(%alloc_0 : memref<2x2xi32>)] {amoeba.semantic.K_range = array<i64: 1, 2>, amoeba.semantic.M_range = array<i64: 0, 2>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.incoming_edges = [], amoeba.semantic.k_block_count = 2 : i64, amoeba.semantic.k_block_index = 1 : i64, amoeba.semantic.k_policy = "parallel", amoeba.semantic.k_tiled, amoeba.semantic.logical_k_block = 1 : i64, amoeba.semantic.output_visibility = "private_partial", amoeba.semantic.partial_buffer = "partial_k.1", amoeba.semantic.private_partial, amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "gemm_producer", amoeba.semantic.task_role = "producer", amoeba.tiling.input_region_lowers = [array<i64: 0, 1>, array<i64: 1, 0>], amoeba.tiling.input_region_reasons = ["private_partial", "private_partial"], amoeba.tiling.input_region_uppers = [array<i64: 2, 2>, array<i64: 2, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]} : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
    ^bb0(%arg6: memref<2x2xi32>, %arg7: memref<2x2xi32>, %arg8: memref<2x2xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %0 = taskflow.counter from %c0 to %c2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
      %1 = taskflow.counter parent(%0 : index) from %c0 to %c2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
      neura.kernel inputs(%arg6, %arg7, %arg8 : memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) attributes {accelerator = "neura"} {
      ^bb0(%arg9: memref<2x2xi32>, %arg10: memref<2x2xi32>, %arg11: memref<2x2xi32>):
        %c1_4 = arith.constant 1 : index
        %c2_5 = arith.constant 2 : index
        %c1_6 = arith.constant 1 : index
        %c0_i32 = arith.constant 0 : i32
        %c0_7 = arith.constant 0 : index
        %c1_8 = arith.constant 1 : index
        %c2_9 = arith.constant 2 : index
        %2 = neura.counter from %c0_7 : index to %c2_9 : index step %c1_8 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
        %3 = neura.counter from %c0_7 : index to %c2_9 : index step %c1_8 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
        %4 = scf.for %arg12 = %c1_4 to %c2_5 step %c1_6 iter_args(%arg13 = %c0_i32) -> (i32) {
          %5 = memref.load %arg9[%2, %arg12] : memref<2x2xi32>
          %6 = memref.load %arg10[%arg12, %3] : memref<2x2xi32>
          %7 = arith.muli %5, %6 : i32
          %8 = arith.muli %arg13, %7 : i32
          scf.yield %8 : i32
        }
        memref.store %4, %arg11[%2, %3] : memref<2x2xi32>
        neura.yield
      }
      taskflow.yield done_writes(%arg8 : memref<2x2xi32>)
    }
    %done_writes_2 = taskflow.task @reduction.final will_reads(%arg2, %done_writes, %done_writes_1 : memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) will_writes(%arg3 : memref<2x2xi32>) [original_read_memrefs(%arg2, %alloc, %alloc_0 : memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>), original_write_memrefs(%arg3 : memref<2x2xi32>)] {amoeba.semantic.K_range = array<i64: 0, 2>, amoeba.semantic.M_range = array<i64: 0, 2>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.incoming_edges = ["partial_k.0|partial_reduction|tile_local", "partial_k.1|partial_reduction|tile_local"], amoeba.semantic.k_policy = "parallel", amoeba.semantic.numeric_reduction, amoeba.semantic.output_visibility = "global_materialized", amoeba.semantic.reduction_final, amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "reduction", amoeba.semantic.task_role = "reduction", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["numeric_reduction", "numeric_reduction", "numeric_reduction"], amoeba.tiling.input_region_uppers = [array<i64: 2, 2>, array<i64: 2, 2>, array<i64: 2, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]} : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
    ^bb0(%arg6: memref<2x2xi32>, %arg7: memref<2x2xi32>, %arg8: memref<2x2xi32>, %arg9: memref<2x2xi32>):
      %c0 = arith.constant 0 : index
      %c2 = arith.constant 2 : index
      %c1 = arith.constant 1 : index
      %0 = taskflow.counter from %c0 to %c2 step %c1 : index
      %c0_4 = arith.constant 0 : index
      %c2_5 = arith.constant 2 : index
      %c1_6 = arith.constant 1 : index
      %1 = taskflow.counter parent(%0 : index) from %c0_4 to %c2_5 step %c1_6 : index
      neura.kernel inputs(%arg6, %arg7, %arg8, %arg9 : memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) {
      ^bb0(%arg10: memref<2x2xi32>, %arg11: memref<2x2xi32>, %arg12: memref<2x2xi32>, %arg13: memref<2x2xi32>):
        %c0_7 = arith.constant 0 : index
        %c2_8 = arith.constant 2 : index
        %c1_9 = arith.constant 1 : index
        %2 = neura.counter from %c0_7 : index to %c2_8 : index step %c1_9 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
        %c0_10 = arith.constant 0 : index
        %c2_11 = arith.constant 2 : index
        %c1_12 = arith.constant 1 : index
        %3 = neura.counter from %c0_10 : index to %c2_11 : index step %c1_12 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
        %4 = memref.load %arg10[%2, %3] : memref<2x2xi32>
        %5 = memref.load %arg11[%2, %3] : memref<2x2xi32>
        %6 = arith.addi %4, %5 : i32
        %7 = memref.load %arg12[%2, %3] : memref<2x2xi32>
        %8 = arith.addi %6, %7 : i32
        memref.store %8, %arg13[%2, %3] : memref<2x2xi32>
        neura.yield
      }
      taskflow.yield done_writes(%arg9 : memref<2x2xi32>)
    }
    %done_writes_3 = taskflow.task @consumer will_reads(%done_writes_2, %arg4 : memref<2x2xi32>, memref<2x2xi32>) will_writes(%arg5 : memref<2x2xi32>) [original_read_memrefs(%arg3, %arg4 : memref<2x2xi32>, memref<2x2xi32>), original_write_memrefs(%arg5 : memref<2x2xi32>)] {amoeba.semantic.K_range = array<i64: 0, 2>, amoeba.semantic.M_range = array<i64: 0, 2>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.incoming_edges = ["reduction.final|producer_consumer|tile_local"], amoeba.semantic.k_policy = "parallel", amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "elementwise_consumer", amoeba.semantic.task_role = "consumer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["consumer_tile", "consumer_tile"], amoeba.tiling.input_region_uppers = [array<i64: 2, 2>, array<i64: 2, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]} : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>) {
    ^bb0(%arg6: memref<2x2xi32>, %arg7: memref<2x2xi32>, %arg8: memref<2x2xi32>):
      memref.copy %arg6, %arg8 : memref<2x2xi32> to memref<2x2xi32>
      taskflow.yield done_writes(%arg8 : memref<2x2xi32>)
    }
    return
  }
}

