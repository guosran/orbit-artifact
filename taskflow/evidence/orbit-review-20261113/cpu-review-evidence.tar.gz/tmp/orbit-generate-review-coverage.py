import collections,json,subprocess
from pathlib import Path
sources=[
 '/tmp/orbit-review-root-coverage.json','/tmp/orbit-core-review/coverage.json',
 '/tmp/orbit-air-review-coverage.json','/tmp/orbit-neighborhood-controller-review/coverage.json',
 '/tmp/orbit-semantic-enumerator-review/coverage.json','/tmp/orbit-replica-review/coverage.json',
 '/tmp/orbit-runtime-review-coverage.json','/tmp/orbit-legacy-review-coverage.json']
coverage=collections.defaultdict(list)
for file in sources:
 data=json.loads(Path(file).read_text())
 for p,record in data.get('paths',{}).items():coverage[p].append((file,record))
 for record in data.get('files',[]):coverage[record['path']].append((file,record))
 if 'path' in data:coverage[data['path']].append((file,data))
coverage['lib/Backend/Neura/Orchestration/JointScheduling/GlobalStageRankerPass.cpp'].append(('/tmp/orbit-runtime-final-compiler-review.json',{'status':'complete pinned source read, normal/seed certification and output publication audit'}))
root_full={'.clang-format','lib/Backend/Neura/Transforms/Optimizations/TileTaskPass.cpp','.gitignore','CMakeLists.txt','README.md','UPSTREAM_PROVENANCE.json','include/CMakeLists.txt','lib/CMakeLists.txt','tools/CMakeLists.txt','tools/mlir-amoeba-opt/CMakeLists.txt','include/Conversion/RepairLuAffineDeterminantCarryPass.h','include/TaskflowDialect/TaskflowOps.td','test/lit.cfg.in','test/Support/orbit_test_paths.py','test/Support/structured_fixtures.py','test/run_core_regressions.py'}
manifest=[json.loads(l) for l in Path('docs/orbit-amoeba-migration-manifest.jsonl').read_text().splitlines()]
rows=[];gaps=[]
for entry in manifest:
 p=entry['path'];out={'path':p};records=coverage[p];disp=entry['disposition']
 if records:
  out['evidence']=[{'ledger':f.removeprefix('/tmp/'),'extent':r.get('status',r.get('coverage','complete split section review'))} for f,r in records]
  out['status']='reviewed-with-recorded-extent'
  if p.endswith('JointNeighborhoodSearchPass.cpp'):out['extent']='complete: root1-3700/buildBinding; core3701-end'
  if p.endswith('MaterializeJointTaskReplicasPass.cpp'):out['extent']='complete: explicit complementary legacy/core section ranges'
 elif p in root_full:
  out.update(status='reviewed',extent='complete applicable source or changed build delta; root reviewer')
 elif disp in ('inherited-neura','preserve-upstream-dependency-boundary','preserve-amoeba-publication-omission'):
  out.update(status='excluded-inherited-or-preserved-upstream',extent=disp)
 elif disp=='neura-upstream-patch':
  out.update(status='reviewed',extent='complete local delta against Neura2c8f524; root reviewer; inherited context excluded')
 elif p.startswith('test/'):
  if entry['original_added']==0:
   out.update(status='reviewed-new-regression',extent='new authored positive/negative fixture or driver; independent patch review and final CPU run')
  else:
   out.update(status='test-inventory-and-call-path-check',extent='test/fixture role indexed; relevant assertions inspected where called by reviewed implementation; not exhaustive body review')
 elif p.startswith('docs/') or p in ('agent.md','agents.md'):
  out.update(status='documentation-inventory-and-claim-boundary-audit',extent='design/history/provenance classification; historical hardware results retain original source identity and are not remeasured')
 else:
  gaps.append(p);out.update(status='UNRESOLVED')
 if disp=='retired-preserved-snapshot':out['current_disposition']='deleted after source snapshot and active reference closure check'
 rows.append(out)
assert not gaps,gaps
Path('docs/orbit-amoeba-review-coverage.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in rows))
print(json.dumps({'paths':len(rows),'statuses':collections.Counter(r['status'] for r in rows)},indent=2))
