module {
  func.func @gcn_memory_feedback_lifetime(%arg0: memref<1x1x4xi32>, %arg1: memref<1x1x4xi32>, %arg2: memref<1x1x4xi32>) -> memref<1x1x4xi32> attributes {amoeba.semantic.k_policy = "sequential", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1"} {
    %c4 = arith.constant 4 : index
    %c0_i32 = arith.constant 0 : i32
    %done_reads, %done_writes = taskflow.task @Task_16.k.0 will_reads(%arg0, %arg1, %arg2 : memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>) will_writes(%arg2 : memref<1x1x4xi32>) value_inputs(%c4, %c0_i32 : index, i32) [original_read_memrefs(%arg0, %arg1, %arg2 : memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>), original_write_memrefs(%arg2 : memref<1x1x4xi32>)] {amoeba.semantic.K_range = array<i64: 0, 2>, amoeba.semantic.M_range = array<i64: 0, 1>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.final_C_ownership = "state_carry", amoeba.semantic.initial_C_ownership = "initial_C_once", amoeba.semantic.k_block_count = 2 : i64, amoeba.semantic.k_block_index = 0 : i64, amoeba.semantic.k_parallel_legal = false, amoeba.semantic.k_policy = "sequential", amoeba.semantic.k_source = "memory_feedback", amoeba.semantic.k_tiled, amoeba.semantic.output_visibility = "global_materialized", amoeba.semantic.reduction_topology = "none", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "memory_feedback_producer", amoeba.semantic.task_role = "producer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0, 0>, array<i64: 0, 0, 0>, array<i64: 0, 0, 0>], amoeba.tiling.input_region_reasons = ["memory_feedback", "memory_feedback", "memory_feedback"], amoeba.tiling.input_region_uppers = [array<i64: 1, 1, 4>, array<i64: 1, 1, 4>, array<i64: 1, 1, 4>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 1, 1, 4>], amoeba.tiling.parent_task = "Task_16"} : (memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>, index, i32) -> (memref<1x1x4xi32>, memref<1x1x4xi32>) {
    ^bb0(%arg3: memref<1x1x4xi32>, %arg4: memref<1x1x4xi32>, %arg5: memref<1x1x4xi32>, %arg6: memref<1x1x4xi32>, %arg7: index, %arg8: i32):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %0 = taskflow.counter from %c0 to %c1 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
      %1 = taskflow.counter parent(%0 : index) from %c0 to %c2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "relay", counter_id = 1 : i32} : index
      %c0_3 = arith.constant 0 : index
      %c2_4 = arith.constant 2 : index
      %2 = taskflow.counter parent(%1 : index) from %c0_3 to %c2_4 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 2 : i32} : index
      neura.kernel inputs(%arg8, %arg6, %arg3, %arg4, %arg7 : i32, memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>, index) attributes {accelerator = "neura", dataflow_mode = "predicate"} {
      ^bb0(%arg9: !neura.data<i32, i1>, %arg10: !neura.data<memref<1x1x4xi32>, i1>, %arg11: !neura.data<memref<1x1x4xi32>, i1>, %arg12: !neura.data<memref<1x1x4xi32>, i1>, %arg13: !neura.data<index, i1>):
        %3 = "neura.constant"() <{value = 0 : index}> : () -> !neura.data<index, i1>
        %4 = neura.counter attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32, lower_bound_value = 0 : index, step_value = 1 : index, upper_bound_value = 1 : index} -> !neura.data<index, i1>
        %5 = neura.counter attributes {counter_dynamism = "constant_bound", counter_hierarchy = "relay", counter_id = 1 : i32, lower_bound_value = 0 : index, step_value = 1 : index, upper_bound_value = 2 : index} -> !neura.data<index, i1>
        %c0_5 = arith.constant 0 : index
        %c2_6 = arith.constant 2 : index
        %6 = neura.counter from %c0_5 : index to %c2_6 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 2 : i32, lower_bound_value = 0 : index, step_value = 1 : index, upper_bound_value = 2 : index} -> !neura.data<index, i1>
        %7 = neura.load_indexed [%3, %4, %6 : !neura.data<index, i1>, !neura.data<index, i1>, !neura.data<index, i1>]  {lhs_value = "%input2"} : !neura.data<i32, i1>
        %8 = neura.load_indexed [%3, %4, %6 : !neura.data<index, i1>, !neura.data<index, i1>, !neura.data<index, i1>]  {lhs_value = "%input3"} : !neura.data<i32, i1>
        %9 = "neura.mul"(%7, %8) : (!neura.data<i32, i1>, !neura.data<i32, i1>) -> !neura.data<i32, i1>
        %10 = neura.load_indexed [%3, %4, %5 : !neura.data<index, i1>, !neura.data<index, i1>, !neura.data<index, i1>]  {lhs_value = "%input1"} : !neura.data<i32, i1>
        %11 = "neura.add"(%10, %9) : (!neura.data<i32, i1>, !neura.data<i32, i1>) -> !neura.data<i32, i1>
        neura.store_indexed %11 to [%3, %4, %5 : !neura.data<index, i1>, !neura.data<index, i1>, !neura.data<index, i1>]  {rhs_value = "%input1"} : !neura.data<i32, i1>
        neura.yield {yield_type = "void"}
      }
      taskflow.yield done_reads(%arg4 : memref<1x1x4xi32>) done_writes(%arg6 : memref<1x1x4xi32>)
    }
    %done_reads_0, %done_writes_1 = taskflow.task @Task_16.k.1 will_reads(%arg0, %arg1, %done_writes : memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>) will_writes(%arg2 : memref<1x1x4xi32>) value_inputs(%c4, %c0_i32 : index, i32) [original_read_memrefs(%arg0, %arg1, %arg2 : memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>), original_write_memrefs(%arg2 : memref<1x1x4xi32>)] {amoeba.semantic.K_range = array<i64: 2, 4>, amoeba.semantic.M_range = array<i64: 0, 1>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.final_C_ownership = "external_final_C", amoeba.semantic.initial_C_ownership = "state_carry", amoeba.semantic.k_block_count = 2 : i64, amoeba.semantic.k_block_index = 1 : i64, amoeba.semantic.k_parallel_legal = false, amoeba.semantic.k_policy = "sequential", amoeba.semantic.k_source = "memory_feedback", amoeba.semantic.k_tiled, amoeba.semantic.output_visibility = "global_materialized", amoeba.semantic.reduction_topology = "none", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "memory_feedback_producer", amoeba.semantic.task_role = "producer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0, 0>, array<i64: 0, 0, 0>, array<i64: 0, 0, 0>], amoeba.tiling.input_region_reasons = ["memory_feedback", "memory_feedback", "memory_feedback"], amoeba.tiling.input_region_uppers = [array<i64: 1, 1, 4>, array<i64: 1, 1, 4>, array<i64: 1, 1, 4>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 1, 1, 4>], amoeba.tiling.parent_task = "Task_16"} : (memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>, index, i32) -> (memref<1x1x4xi32>, memref<1x1x4xi32>) {
    ^bb0(%arg3: memref<1x1x4xi32>, %arg4: memref<1x1x4xi32>, %arg5: memref<1x1x4xi32>, %arg6: memref<1x1x4xi32>, %arg7: index, %arg8: i32):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %0 = taskflow.counter from %c0 to %c1 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
      %1 = taskflow.counter parent(%0 : index) from %c0 to %c2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "relay", counter_id = 1 : i32} : index
      %c2_3 = arith.constant 2 : index
      %c4_4 = arith.constant 4 : index
      %2 = taskflow.counter parent(%1 : index) from %c2_3 to %c4_4 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 2 : i32} : index
      neura.kernel inputs(%arg8, %arg6, %arg3, %arg4, %arg7 : i32, memref<1x1x4xi32>, memref<1x1x4xi32>, memref<1x1x4xi32>, index) attributes {accelerator = "neura", dataflow_mode = "predicate"} {
      ^bb0(%arg9: !neura.data<i32, i1>, %arg10: !neura.data<memref<1x1x4xi32>, i1>, %arg11: !neura.data<memref<1x1x4xi32>, i1>, %arg12: !neura.data<memref<1x1x4xi32>, i1>, %arg13: !neura.data<index, i1>):
        %3 = "neura.constant"() <{value = 0 : index}> : () -> !neura.data<index, i1>
        %4 = neura.counter attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32, lower_bound_value = 0 : index, step_value = 1 : index, upper_bound_value = 1 : index} -> !neura.data<index, i1>
        %5 = neura.counter attributes {counter_dynamism = "constant_bound", counter_hierarchy = "relay", counter_id = 1 : i32, lower_bound_value = 0 : index, step_value = 1 : index, upper_bound_value = 2 : index} -> !neura.data<index, i1>
        %c2_5 = arith.constant 2 : index
        %c4_6 = arith.constant 4 : index
        %6 = neura.counter from %c2_5 : index to %c4_6 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 2 : i32, lower_bound_value = 2 : index, step_value = 1 : index, upper_bound_value = 4 : index} -> !neura.data<index, i1>
        %7 = neura.load_indexed [%3, %4, %6 : !neura.data<index, i1>, !neura.data<index, i1>, !neura.data<index, i1>]  {lhs_value = "%input2"} : !neura.data<i32, i1>
        %8 = neura.load_indexed [%3, %4, %6 : !neura.data<index, i1>, !neura.data<index, i1>, !neura.data<index, i1>]  {lhs_value = "%input3"} : !neura.data<i32, i1>
        %9 = "neura.mul"(%7, %8) : (!neura.data<i32, i1>, !neura.data<i32, i1>) -> !neura.data<i32, i1>
        %10 = neura.load_indexed [%3, %4, %5 : !neura.data<index, i1>, !neura.data<index, i1>, !neura.data<index, i1>]  {lhs_value = "%input1"} : !neura.data<i32, i1>
        %11 = "neura.add"(%10, %9) : (!neura.data<i32, i1>, !neura.data<i32, i1>) -> !neura.data<i32, i1>
        neura.store_indexed %11 to [%3, %4, %5 : !neura.data<index, i1>, !neura.data<index, i1>, !neura.data<index, i1>]  {rhs_value = "%input1"} : !neura.data<i32, i1>
        neura.yield {yield_type = "void"}
      }
      taskflow.yield done_reads(%arg4 : memref<1x1x4xi32>) done_writes(%arg6 : memref<1x1x4xi32>)
    }
    %done_writes_2 = taskflow.task @Task_19 will_reads(%done_writes_1 : memref<1x1x4xi32>) will_writes(%done_reads_0 : memref<1x1x4xi32>) [original_read_memrefs(%arg2 : memref<1x1x4xi32>), original_write_memrefs(%arg1 : memref<1x1x4xi32>)] : (memref<1x1x4xi32>, memref<1x1x4xi32>) -> (memref<1x1x4xi32>) {
    ^bb0(%arg3: memref<1x1x4xi32>, %arg4: memref<1x1x4xi32>):
      taskflow.yield done_writes(%arg4 : memref<1x1x4xi32>)
    }
    return %done_writes_2 : memref<1x1x4xi32>
  }
}

