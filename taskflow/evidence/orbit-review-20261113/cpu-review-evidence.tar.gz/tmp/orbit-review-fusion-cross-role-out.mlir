module {
  func.func @fusion_alias(%arg0: memref<2x2xi32> {amoeba.noalias}, %arg1: memref<2x2xi32> {amoeba.noalias}) {
    %done_writes:2 = taskflow.task @producer.fuse.consumer will_reads(%arg1 : memref<2x2xi32>) will_writes(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>) [original_read_memrefs(%arg1 : memref<2x2xi32>), original_write_memrefs(%arg0, %arg1 : memref<2x2xi32>, memref<2x2xi32>)] {amoeba.neura.fusion.eliminated_loads = 1 : i64, amoeba.neura.fusion.eliminated_stores = 0 : i64, amoeba.neura.fusion.mode = "retained", amoeba.neura.joint_rewrite = "post-neura-producer-consumer-retained"} : (memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) -> (memref<2x2xi32>, memref<2x2xi32>) {
    ^bb0(%arg2: memref<2x2xi32>, %arg3: memref<2x2xi32>, %arg4: memref<2x2xi32>):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c2 = arith.constant 2 : index
      %0 = taskflow.counter from %c0 to %c2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} : index
      %1 = taskflow.counter parent(%0 : index) from %c0 to %c2 step %c1 attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} : index
      neura.kernel inputs(%arg3, %arg2, %arg4 : memref<2x2xi32>, memref<2x2xi32>, memref<2x2xi32>) attributes {accelerator = "neura"} {
      ^bb0(%arg5: memref<2x2xi32>, %arg6: memref<2x2xi32>, %arg7: memref<2x2xi32>):
        %c0_0 = arith.constant 0 : index
        %c1_1 = arith.constant 1 : index
        %c2_2 = arith.constant 2 : index
        %2 = neura.counter from %c0_0 : index to %c2_2 : index step %c1_1 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "root", counter_id = 0 : i32} -> index
        %3 = neura.counter from %c0_0 : index to %c2_2 : index step %c1_1 : index attributes {counter_dynamism = "constant_bound", counter_hierarchy = "leaf", counter_id = 1 : i32} -> index
        %4 = memref.load %arg6[%2, %3] : memref<2x2xi32>
        memref.store %4, %arg5[%2, %3] : memref<2x2xi32>
        %c0_3 = arith.constant 0 : index
        %c1_4 = arith.constant 1 : index
        %c2_5 = arith.constant 2 : index
        memref.store %4, %arg7[%3, %2] : memref<2x2xi32>
        neura.yield
      }
      taskflow.yield done_writes(%arg3, %arg4 : memref<2x2xi32>, memref<2x2xi32>)
    }
    return
  }
}

