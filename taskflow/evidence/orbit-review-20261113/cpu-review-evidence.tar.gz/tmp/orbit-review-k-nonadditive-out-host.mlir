module {
  func.func @nonadditive(%arg0: memref<2x2xi32> {amoeba.noalias}, %arg1: memref<2x2xi32> {amoeba.noalias}, %arg2: memref<2x2xi32> {amoeba.noalias}, %arg3: memref<2x2xi32> {amoeba.noalias}, %arg4: memref<2x2xi32> {amoeba.noalias}, %arg5: memref<2x2xi32> {amoeba.noalias}) attributes {amoeba.semantic.k_policy = "parallel", amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1"} {
    %alloc = memref.alloc() {amoeba.semantic.logical_k_block = 0 : i64, amoeba.semantic.private_partial} : memref<2x2xi32>
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0_0 = arith.constant 0 : index
    %c1_1 = arith.constant 1 : index
    %c1_2 = arith.constant 1 : index
    %c0_i32 = arith.constant 0 : i32
    %c0_3 = arith.constant 0 : index
    %c1_4 = arith.constant 1 : index
    %c2_5 = arith.constant 2 : index
    scf.for %arg6 = %c0_3 to %c2_5 step %c1_4 {
      scf.for %arg7 = %c0_3 to %c2_5 step %c1_4 {
        %0 = scf.for %arg8 = %c0_0 to %c1_1 step %c1_2 iter_args(%arg9 = %c0_i32) -> (i32) {
          %1 = memref.load %arg0[%arg6, %arg8] : memref<2x2xi32>
          %2 = memref.load %arg1[%arg8, %arg7] : memref<2x2xi32>
          %3 = arith.muli %1, %2 : i32
          %4 = arith.muli %arg9, %3 : i32
          scf.yield %4 : i32
        }
        memref.store %0, %alloc[%arg6, %arg7] : memref<2x2xi32>
      }
    } {amoeba.host.task_completion, amoeba.host.task_name = "partial_k.0", amoeba.semantic.K_range = array<i64: 0, 1>, amoeba.semantic.M_range = array<i64: 0, 2>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.incoming_edges = [], amoeba.semantic.k_block_count = 2 : i64, amoeba.semantic.k_block_index = 0 : i64, amoeba.semantic.k_policy = "parallel", amoeba.semantic.k_tiled, amoeba.semantic.logical_k_block = 0 : i64, amoeba.semantic.output_visibility = "private_partial", amoeba.semantic.partial_buffer = "partial_k.0", amoeba.semantic.private_partial, amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "gemm_producer", amoeba.semantic.task_role = "producer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["private_partial", "private_partial"], amoeba.tiling.input_region_uppers = [array<i64: 2, 1>, array<i64: 1, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]}
    %alloc_6 = memref.alloc() {amoeba.semantic.logical_k_block = 1 : i64, amoeba.semantic.private_partial} : memref<2x2xi32>
    %c0_7 = arith.constant 0 : index
    %c1_8 = arith.constant 1 : index
    %c2_9 = arith.constant 2 : index
    %c1_10 = arith.constant 1 : index
    %c2_11 = arith.constant 2 : index
    %c1_12 = arith.constant 1 : index
    %c0_i32_13 = arith.constant 0 : i32
    %c0_14 = arith.constant 0 : index
    %c1_15 = arith.constant 1 : index
    %c2_16 = arith.constant 2 : index
    scf.for %arg6 = %c0_14 to %c2_16 step %c1_15 {
      scf.for %arg7 = %c0_14 to %c2_16 step %c1_15 {
        %0 = scf.for %arg8 = %c1_10 to %c2_11 step %c1_12 iter_args(%arg9 = %c0_i32_13) -> (i32) {
          %1 = memref.load %arg0[%arg6, %arg8] : memref<2x2xi32>
          %2 = memref.load %arg1[%arg8, %arg7] : memref<2x2xi32>
          %3 = arith.muli %1, %2 : i32
          %4 = arith.muli %arg9, %3 : i32
          scf.yield %4 : i32
        }
        memref.store %0, %alloc_6[%arg6, %arg7] : memref<2x2xi32>
      }
    } {amoeba.host.task_completion, amoeba.host.task_name = "partial_k.1", amoeba.semantic.K_range = array<i64: 1, 2>, amoeba.semantic.M_range = array<i64: 0, 2>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.incoming_edges = [], amoeba.semantic.k_block_count = 2 : i64, amoeba.semantic.k_block_index = 1 : i64, amoeba.semantic.k_policy = "parallel", amoeba.semantic.k_tiled, amoeba.semantic.logical_k_block = 1 : i64, amoeba.semantic.output_visibility = "private_partial", amoeba.semantic.partial_buffer = "partial_k.1", amoeba.semantic.private_partial, amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "gemm_producer", amoeba.semantic.task_role = "producer", amoeba.tiling.input_region_lowers = [array<i64: 0, 1>, array<i64: 1, 0>], amoeba.tiling.input_region_reasons = ["private_partial", "private_partial"], amoeba.tiling.input_region_uppers = [array<i64: 2, 2>, array<i64: 2, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]}
    %c0_17 = arith.constant 0 : index
    %c2_18 = arith.constant 2 : index
    %c1_19 = arith.constant 1 : index
    %c0_20 = arith.constant 0 : index
    %c2_21 = arith.constant 2 : index
    %c1_22 = arith.constant 1 : index
    %c0_23 = arith.constant 0 : index
    %c2_24 = arith.constant 2 : index
    %c1_25 = arith.constant 1 : index
    %c0_26 = arith.constant 0 : index
    %c2_27 = arith.constant 2 : index
    %c1_28 = arith.constant 1 : index
    scf.for %arg6 = %c0_23 to %c2_24 step %c1_25 {
      scf.for %arg7 = %c0_26 to %c2_27 step %c1_28 {
        %0 = memref.load %arg2[%arg6, %arg7] : memref<2x2xi32>
        %1 = memref.load %alloc[%arg6, %arg7] : memref<2x2xi32>
        %2 = arith.addi %0, %1 : i32
        %3 = memref.load %alloc_6[%arg6, %arg7] : memref<2x2xi32>
        %4 = arith.addi %2, %3 : i32
        memref.store %4, %arg3[%arg6, %arg7] : memref<2x2xi32>
      }
    } {amoeba.host.task_completion, amoeba.host.task_name = "reduction.final", amoeba.semantic.K_range = array<i64: 0, 2>, amoeba.semantic.M_range = array<i64: 0, 2>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.incoming_edges = ["partial_k.0|partial_reduction|tile_local", "partial_k.1|partial_reduction|tile_local"], amoeba.semantic.k_policy = "parallel", amoeba.semantic.numeric_reduction, amoeba.semantic.output_visibility = "global_materialized", amoeba.semantic.reduction_final, amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "reduction", amoeba.semantic.task_role = "reduction", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["numeric_reduction", "numeric_reduction", "numeric_reduction"], amoeba.tiling.input_region_uppers = [array<i64: 2, 2>, array<i64: 2, 2>, array<i64: 2, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]}
    memref.copy %arg3, %arg5 {amoeba.host.task_completion, amoeba.host.task_name = "consumer", amoeba.semantic.K_range = array<i64: 0, 2>, amoeba.semantic.M_range = array<i64: 0, 2>, amoeba.semantic.N_range = array<i64: 0, 2>, amoeba.semantic.incoming_edges = ["reduction.final|producer_consumer|tile_local"], amoeba.semantic.k_policy = "parallel", amoeba.semantic.reduction_topology = "linear", amoeba.semantic.rewrite_schema = "orbit-joint-semantic-rewrite-v1", amoeba.semantic.schema = "orbit-joint-taskflow-materialization-v1", amoeba.semantic.task_kind = "elementwise_consumer", amoeba.semantic.task_role = "consumer", amoeba.tiling.input_region_lowers = [array<i64: 0, 0>, array<i64: 0, 0>], amoeba.tiling.input_region_reasons = ["consumer_tile", "consumer_tile"], amoeba.tiling.input_region_uppers = [array<i64: 2, 2>, array<i64: 2, 2>], amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]} : memref<2x2xi32> to memref<2x2xi32>
    return
  }
}

