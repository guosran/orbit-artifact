module {
  func.func @phi3(%arg0: memref<1xi32>) {
    return
  }
}

