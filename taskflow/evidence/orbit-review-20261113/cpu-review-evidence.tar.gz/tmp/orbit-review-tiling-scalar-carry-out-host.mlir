module {
  func.func @inplace_alias(%arg0: memref<2x2xi32> {amoeba.noalias}, %arg1: memref<2x2xi32> {amoeba.noalias}) attributes {amoeba.neura.joint_rewrite = "post-neura-mn-tiling"} {
    %c0 = arith.constant 0 : index
    %c1 = arith.constant 1 : index
    %c2 = arith.constant 2 : index
    %c0_i32 = arith.constant 0 : i32
    %c0_0 = arith.constant 0 : index
    %c2_1 = arith.constant 2 : index
    %c0_2 = arith.constant 0 : index
    %c1_3 = arith.constant 1 : index
    %c0_4 = arith.constant 0 : index
    %c1_5 = arith.constant 1 : index
    %c2_6 = arith.constant 2 : index
    %c0_7 = arith.constant 0 : index
    %c2_8 = arith.constant 2 : index
    %c0_9 = arith.constant 0 : index
    %c1_10 = arith.constant 1 : index
    scf.for %arg2 = %c0_7 to %c2_8 step %c1_5 {
      %0 = scf.for %arg3 = %c0_9 to %c1_10 step %c1_5 iter_args(%arg4 = %c0_i32) -> (i32) {
        %1 = memref.load %arg1[%arg3, %arg2] : memref<2x2xi32>
        %2 = arith.addi %arg4, %1 : i32
        memref.store %2, %arg0[%arg2, %arg3] : memref<2x2xi32>
        scf.yield %2 : i32
      }
    } {amoeba.host.task_completion, amoeba.host.task_name = "update.tile.1.0", amoeba.tiling.output_region_lowers = [array<i64: 0, 0>], amoeba.tiling.output_region_uppers = [array<i64: 2, 1>]}
    %c0_11 = arith.constant 0 : index
    %c1_12 = arith.constant 1 : index
    %c2_13 = arith.constant 2 : index
    %c0_i32_14 = arith.constant 0 : i32
    %c0_15 = arith.constant 0 : index
    %c2_16 = arith.constant 2 : index
    %c1_17 = arith.constant 1 : index
    %c2_18 = arith.constant 2 : index
    %c0_19 = arith.constant 0 : index
    %c1_20 = arith.constant 1 : index
    %c2_21 = arith.constant 2 : index
    %c0_22 = arith.constant 0 : index
    %c2_23 = arith.constant 2 : index
    %c1_24 = arith.constant 1 : index
    %c2_25 = arith.constant 2 : index
    scf.for %arg2 = %c0_22 to %c2_23 step %c1_20 {
      %0 = scf.for %arg3 = %c1_24 to %c2_25 step %c1_20 iter_args(%arg4 = %c0_i32_14) -> (i32) {
        %1 = memref.load %arg1[%arg3, %arg2] : memref<2x2xi32>
        %2 = arith.addi %arg4, %1 : i32
        memref.store %2, %arg0[%arg2, %arg3] : memref<2x2xi32>
        scf.yield %2 : i32
      }
    } {amoeba.host.task_completion, amoeba.host.task_name = "update.tile.1.1", amoeba.tiling.output_region_lowers = [array<i64: 0, 1>], amoeba.tiling.output_region_uppers = [array<i64: 2, 2>]}
    return
  }
}

