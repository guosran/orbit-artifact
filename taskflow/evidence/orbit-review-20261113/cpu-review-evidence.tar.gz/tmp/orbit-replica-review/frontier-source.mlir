module { func.func @frontier(%a: memref<4xi32>) {
%p = taskflow.task @p  will_writes(%a : memref<4xi32>) [original_write_memrefs(%a : memref<4xi32>)] {amoeba.tiling.output_region_lowers = [array<i64: 0>], amoeba.tiling.output_region_uppers = [array<i64: 1>]} : (memref<4xi32>) -> memref<4xi32> {
^bb0(%write: memref<4xi32>):
%value = arith.constant 7 : i32
%w = arith.constant 0 : index
memref.store %value, %write[%w] : memref<4xi32>
taskflow.yield done_writes(%write : memref<4xi32>)
}
%q = taskflow.task @q  will_writes(%a : memref<4xi32>) [original_write_memrefs(%a : memref<4xi32>)] {amoeba.tiling.output_region_lowers = [array<i64: 1>], amoeba.tiling.output_region_uppers = [array<i64: 2>]} : (memref<4xi32>) -> memref<4xi32> {
^bb0(%write: memref<4xi32>):
%value = arith.constant 7 : i32
%w = arith.constant 1 : index
memref.store %value, %write[%w] : memref<4xi32>
taskflow.yield done_writes(%write : memref<4xi32>)
}
%r = taskflow.task @r will_reads(%a : memref<4xi32>)  [original_read_memrefs(%a : memref<4xi32>)] {amoeba.tiling.input_region_lowers = [array<i64: 0>], amoeba.tiling.input_region_uppers = [array<i64: 1>], amoeba.tiling.input_region_reasons = ["direct"]} : (memref<4xi32>) -> memref<4xi32> {
^bb0(%read: memref<4xi32>):
%r = arith.constant 0 : index
%value = memref.load %read[%r] : memref<4xi32>
taskflow.yield done_reads(%read : memref<4xi32>)
}
return
}}