// Exercised by ../rewrite-legality-regressions.py.
module {
 func.func @_Z10radar_func_review(%in: memref<32x256xi32> {amoeba.noalias}, %out0: memref<32x256xi32> {amoeba.noalias}, %out1: memref<32x256xi32> {amoeba.noalias}, %sink: memref<32x256xi32> {amoeba.noalias}) {
 %done:2 = taskflow.task @Task_2 will_reads(%in : memref<32x256xi32>) will_writes(%out0, %out1 : memref<32x256xi32>, memref<32x256xi32>) [original_read_memrefs(%in : memref<32x256xi32>), original_write_memrefs(%out0, %out1 : memref<32x256xi32>, memref<32x256xi32>)] : (memref<32x256xi32>, memref<32x256xi32>, memref<32x256xi32>) -> (memref<32x256xi32>, memref<32x256xi32>) {
 ^bb0(%r: memref<32x256xi32>, %w0: memref<32x256xi32>, %w1: memref<32x256xi32>):
 %z = arith.constant 0 : index
 %o = arith.constant 1 : index
 %range = arith.constant 64 : index
 %chirp = arith.constant 32 : index
 %m = taskflow.counter from %z to %range step %o attributes {counter_id = 0 : i32} : index
 %n = taskflow.counter parent(%m : index) from %z to %chirp step %o attributes {counter_id = 1 : i32} : index
 neura.kernel inputs(%r, %w0, %w1 : memref<32x256xi32>, memref<32x256xi32>, memref<32x256xi32>) attributes {accelerator="neura"} {
 ^bb0(%kr: memref<32x256xi32>, %kw0: memref<32x256xi32>, %kw1: memref<32x256xi32>):
 %i = neura.counter attributes {counter_id=0:i32, lower_bound_value=0:index, upper_bound_value=64:index, step_value=1:index} -> !neura.data<index,i1>
 %j = neura.counter attributes {counter_id=1:i32, lower_bound_value=0:index, upper_bound_value=32:index, step_value=1:index} -> !neura.data<index,i1>
 %v = neura.load_indexed [%j,%i : !neura.data<index,i1>, !neura.data<index,i1>] {lhs_value="%input0"} : !neura.data<i32,i1>
 %inc = "neura.add"(%v) {rhs_value = 1 : i32} : (!neura.data<i32,i1>) -> !neura.data<i32,i1>
 neura.store_indexed %inc to [%j,%i : !neura.data<index,i1>, !neura.data<index,i1>] {rhs_value="%input1"} : !neura.data<i32,i1>
 neura.store_indexed %v to [%j,%i : !neura.data<index,i1>, !neura.data<index,i1>] {rhs_value="%input2"} : !neura.data<i32,i1>
 neura.yield {yield_type="void"}
 }
 taskflow.yield done_writes(%w1,%w0 : memref<32x256xi32>,memref<32x256xi32>)
 }
 %tail = taskflow.task @Task_4 will_reads(%done#0,%done#1 : memref<32x256xi32>,memref<32x256xi32>) will_writes(%sink : memref<32x256xi32>) [original_read_memrefs(%out0,%out1 : memref<32x256xi32>,memref<32x256xi32>),original_write_memrefs(%sink : memref<32x256xi32>)] : (memref<32x256xi32>,memref<32x256xi32>,memref<32x256xi32>)->memref<32x256xi32> {
 ^bb0(%a:memref<32x256xi32>,%b:memref<32x256xi32>,%c:memref<32x256xi32>):
 memref.copy %a,%c : memref<32x256xi32> to memref<32x256xi32>
 taskflow.yield done_writes(%c:memref<32x256xi32>)
 }
 return
 }
}
