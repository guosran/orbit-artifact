module {
  func.func @target(%arg0: index, %arg1: memref<4xi32> {amoeba.logical_transfer_shape = array<i64: 4>, amoeba.noalias}, %arg2: memref<4xi32> {amoeba.logical_transfer_shape = array<i64: 4>, amoeba.noalias}) attributes {amoeba.input0_caller_evidence_path = "/tmp/orbit-review-caller-indirect.mlir", amoeba.input0_caller_function = "main", amoeba.input0_caller_noalias_proof_mode = "in-module-caller", amoeba.input0_caller_noalias_proven, amoeba.input0_caller_static_bound = 4 : i64} {
    return
  }
  func.func @main() {
    %c4 = arith.constant 4 : index
    %alloc = memref.alloc() : memref<4xi32>
    %alloc_0 = memref.alloc() : memref<4xi32>
    call @target(%c4, %alloc, %alloc_0) : (index, memref<4xi32>, memref<4xi32>) -> ()
    call @other() : () -> ()
    return
  }
  func.func private @other() {
    %c4 = arith.constant 4 : index
    %alloc = memref.alloc() : memref<4xi32>
    %f = constant @target : (index, memref<4xi32>, memref<4xi32>) -> ()
    call_indirect %f(%c4, %alloc, %alloc) : (index, memref<4xi32>, memref<4xi32>) -> ()
    return
  }
}

