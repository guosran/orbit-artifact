module {
  func.func @dynamic_epilogue(%n: index, %out: memref<1xi32>) {
    %one = arith.constant 1 : i32
    affine.for %i = 0 to 1 {
      affine.for %j = 0 to %n {
      }
      affine.store %one, %out[0] : memref<1xi32>
    }
    return
  }
}
