module {
  func.func @prefix_sum(%arg0: memref<4xi32> {amoeba.noalias}, %arg1: memref<4xi32> {amoeba.noalias}) -> memref<4xi32> attributes {amoeba.replica.count = 2 : i64, amoeba.replica.materialized_task = "prefix", amoeba.replica.shard_axis = 0 : i64, amoeba.replica.shard_trip_count = 2 : i64, amoeba.replica.total_trip_count = 4 : i64} {
    %c0_i32 = arith.constant 0 : i32
    %done_writes = taskflow.task @prefix.replica.0 will_reads(%arg0 : memref<4xi32>) will_writes(%arg1 : memref<4xi32>) value_inputs(%c0_i32 : i32) [original_read_memrefs(%arg0 : memref<4xi32>), original_write_memrefs(%arg1 : memref<4xi32>)] {amoeba.replica.count = 2 : i64, amoeba.replica.id = 0 : i64, amoeba.replica.parent_task = "prefix", amoeba.replica.shard_axis = 0 : i64, amoeba.replica.shard_lower = 0 : i64, amoeba.replica.shard_trip_count = 2 : i64, amoeba.replica.shard_upper = 2 : i64, amoeba.replica.total_trip_count = 4 : i64, amoeba.tiling.output_region_lowers = [array<i64: 0>], amoeba.tiling.output_region_uppers = [array<i64: 2>], trip_count = 2 : i64} : (memref<4xi32>, memref<4xi32>, i32) -> (memref<4xi32>) {
    ^bb0(%arg2: memref<4xi32>, %arg3: memref<4xi32>, %arg4: i32):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c4 = arith.constant 4 : index
      %c0_1 = arith.constant 0 : index
      %c2 = arith.constant 2 : index
      %1 = taskflow.counter from %c0_1 to %c2 step %c1 : index
      %2 = "taskflow.hyperblock"(%1, %arg4) <{operandSegmentSizes = array<i32: 1, 1>}> ({
      ^bb0(%arg5: index, %arg6: i32):
        %3 = memref.load %arg2[%arg5] : memref<4xi32>
        %4 = arith.addi %arg6, %3 : i32
        memref.store %4, %arg3[%arg5] : memref<4xi32>
        taskflow.hyperblock.yield iter_args_next(%4 : i32) results(%4 : i32)
      }) : (index, i32) -> i32
      taskflow.yield done_writes(%arg3 : memref<4xi32>)
    }
    %done_writes_0 = taskflow.task @prefix.replica.1 will_reads(%arg0 : memref<4xi32>) will_writes(%arg1 : memref<4xi32>) value_inputs(%c0_i32 : i32) [original_read_memrefs(%arg0 : memref<4xi32>), original_write_memrefs(%arg1 : memref<4xi32>)] {amoeba.replica.count = 2 : i64, amoeba.replica.id = 1 : i64, amoeba.replica.parent_task = "prefix", amoeba.replica.shard_axis = 0 : i64, amoeba.replica.shard_lower = 2 : i64, amoeba.replica.shard_trip_count = 2 : i64, amoeba.replica.shard_upper = 4 : i64, amoeba.replica.total_trip_count = 4 : i64, amoeba.tiling.output_region_lowers = [array<i64: 2>], amoeba.tiling.output_region_uppers = [array<i64: 4>], trip_count = 2 : i64} : (memref<4xi32>, memref<4xi32>, i32) -> (memref<4xi32>) {
    ^bb0(%arg2: memref<4xi32>, %arg3: memref<4xi32>, %arg4: i32):
      %c0 = arith.constant 0 : index
      %c1 = arith.constant 1 : index
      %c4 = arith.constant 4 : index
      %c2 = arith.constant 2 : index
      %c4_1 = arith.constant 4 : index
      %1 = taskflow.counter from %c2 to %c4_1 step %c1 : index
      %2 = "taskflow.hyperblock"(%1, %arg4) <{operandSegmentSizes = array<i32: 1, 1>}> ({
      ^bb0(%arg5: index, %arg6: i32):
        %3 = memref.load %arg2[%arg5] : memref<4xi32>
        %4 = arith.addi %arg6, %3 : i32
        memref.store %4, %arg3[%arg5] : memref<4xi32>
        taskflow.hyperblock.yield iter_args_next(%4 : i32) results(%4 : i32)
      }) : (index, i32) -> i32
      taskflow.yield done_writes(%arg3 : memref<4xi32>)
    }
    %0 = taskflow.join states(%done_writes, %done_writes_0) base(%arg1) axis(0) region([0], [4]) {amoeba.replica.completion_only, amoeba.semantic.completion_only} : memref<4xi32>
    return %0 : memref<4xi32>
  }
}

