module {
  func.func @ray_reduction(%arg0: index, %arg1: memref<2xi32> {amoeba.logical_transfer_shape = array<i64: 2>, amoeba.noalias}, %arg2: memref<2x8xi32> {amoeba.logical_transfer_shape = array<i64: 2, 8>, amoeba.noalias}, %arg3: memref<2xi32> {amoeba.logical_transfer_shape = array<i64: 2>, amoeba.noalias}, %arg4: memref<2xi32> {amoeba.logical_transfer_shape = array<i64: 2>, amoeba.noalias}, %arg5: i32, %arg6: i32, %arg7: i32) attributes {amoeba.input0_caller_evidence_path = "caller-evidence.json", amoeba.input0_caller_noalias_proof_mode = "prepared-external-caller", amoeba.input0_caller_noalias_proven, amoeba.input0_caller_prepared_input_path = "prepared.mlir", amoeba.input0_caller_static_bound = 2 : i64, amoeba.static_bound.arg.0 = 2 : i64} {
    %alloc = memref.alloc() : memref<2xi32>
    %alloc_0 = memref.alloc() : memref<2xi32>
    %done_writes:2 = taskflow.task @Task_13.fission.0 will_reads(%arg1, %arg2 : memref<2xi32>, memref<2x8xi32>) will_writes(%alloc, %alloc_0 : memref<2xi32>, memref<2xi32>) value_inputs(%arg0, %arg5, %arg6, %arg7 : index, i32, i32, i32) [original_read_memrefs(%arg1, %arg2 : memref<2xi32>, memref<2x8xi32>), original_write_memrefs(%alloc, %alloc_0 : memref<2xi32>, memref<2xi32>)] {amoeba.fission.lane_interval = array<i64: 0, 4>, amoeba.fission.parent_source_work_count = 16 : i64, amoeba.fission.schema = "ray-carried-min-index-fission-v1", amoeba.fission.source_task = "Task_13", amoeba.fission.stage = 0 : i64, amoeba.fission.stage_source_work_count = 8 : i64, amoeba.fission.state_link = "taskflow-raw:row-index,row-best"} : (memref<2xi32>, memref<2x8xi32>, memref<2xi32>, memref<2xi32>, index, i32, i32, i32) -> (memref<2xi32>, memref<2xi32>) {
    ^bb0(%arg8: memref<2xi32>, %arg9: memref<2x8xi32>, %arg10: memref<2xi32>, %arg11: memref<2xi32>, %arg12: index, %arg13: i32, %arg14: i32, %arg15: i32):
      affine.for %arg16 = 0 to %arg12 {
        %0 = affine.load %arg8[%arg16] : memref<2xi32>
        %1 = arith.cmpi sgt, %0, %arg13 : i32
        %2 = arith.select %1, %0, %arg14 : i32
        %3:2 = affine.for %arg17 = 0 to 4 iter_args(%arg18 = %2, %arg19 = %arg15) -> (i32, i32) {
          %4 = arith.index_cast %arg17 : index to i32
          %5 = affine.load %arg9[%arg16, %arg17] : memref<2x8xi32>
          %6 = arith.cmpi sgt, %5, %arg13 : i32
          %7:2 = scf.if %6 -> (i32, i32) {
            %8 = arith.cmpi slt, %5, %arg18 : i32
            %9 = arith.select %8, %5, %arg18 : i32
            %10 = arith.select %8, %4, %arg19 : i32
            scf.yield %9, %10 : i32, i32
          } else {
            scf.yield %arg18, %arg19 : i32, i32
          }
          affine.yield %7#0, %7#1 : i32, i32
        }
        affine.store %3#1, %arg10[-%arg16 + 1] : memref<2xi32>
        affine.store %3#0, %arg11[-%arg16 + 1] : memref<2xi32>
      }
      taskflow.yield done_writes(%arg10, %arg11 : memref<2xi32>, memref<2xi32>)
    }
    %done_writes_1:2 = taskflow.task @Task_13 will_reads(%done_writes#0, %done_writes#1, %arg2 : memref<2xi32>, memref<2xi32>, memref<2x8xi32>) will_writes(%arg3, %arg4 : memref<2xi32>, memref<2xi32>) value_inputs(%arg0, %arg5, %arg6, %arg7 : index, i32, i32, i32) [original_read_memrefs(%alloc, %alloc_0, %arg2 : memref<2xi32>, memref<2xi32>, memref<2x8xi32>), original_write_memrefs(%arg3, %arg4 : memref<2xi32>, memref<2xi32>)] {amoeba.fission.lane_interval = array<i64: 4, 8>, amoeba.fission.parent_source_work_count = 16 : i64, amoeba.fission.schema = "ray-carried-min-index-fission-v1", amoeba.fission.source_task = "Task_13", amoeba.fission.stage = 1 : i64, amoeba.fission.stage_source_work_count = 8 : i64, amoeba.fission.state_link = "taskflow-raw:row-index,row-best"} : (memref<2xi32>, memref<2xi32>, memref<2x8xi32>, memref<2xi32>, memref<2xi32>, index, i32, i32, i32) -> (memref<2xi32>, memref<2xi32>) {
    ^bb0(%arg8: memref<2xi32>, %arg9: memref<2xi32>, %arg10: memref<2x8xi32>, %arg11: memref<2xi32>, %arg12: memref<2xi32>, %arg13: index, %arg14: i32, %arg15: i32, %arg16: i32):
      affine.for %arg17 = 0 to %arg13 {
        %0 = affine.load %arg9[%arg17] : memref<2xi32>
        %1 = affine.load %arg8[%arg17] : memref<2xi32>
        %2:2 = affine.for %arg18 = 4 to 8 iter_args(%arg19 = %0, %arg20 = %1) -> (i32, i32) {
          %3 = arith.index_cast %arg18 : index to i32
          %4 = affine.load %arg10[%arg17, %arg18] : memref<2x8xi32>
          %5 = arith.cmpi sgt, %4, %arg14 : i32
          %6:2 = scf.if %5 -> (i32, i32) {
            %7 = arith.cmpi slt, %4, %arg19 : i32
            %8 = arith.select %7, %4, %arg19 : i32
            %9 = arith.select %7, %3, %arg20 : i32
            scf.yield %8, %9 : i32, i32
          } else {
            scf.yield %arg19, %arg20 : i32, i32
          }
          affine.yield %6#0, %6#1 : i32, i32
        }
        affine.store %2#1, %arg11[-%arg17 + 1] : memref<2xi32>
        affine.store %2#0, %arg12[-%arg17 + 1] : memref<2xi32>
      }
      taskflow.yield done_writes(%arg11, %arg12 : memref<2xi32>, memref<2xi32>)
    }
    return
  }
}

