# Public joint search: executable and proof scope (v32)

`runProgramAllSearch` composes public choices in one C++ finite domain. `searchProgramSpace` uses CP-SAT selectors, compatibility tables and forbidden checked tuples; its proposal objective is local-choice coverage. Complete source/native/graph checking and full cost evaluation run in the C++ callback. There is no Python optimizer and no pre-priced complete-plan catalogue. This is branch-and-check, not a single CP makespan formulation over every public abstraction. It proves a finite-domain optimum only after exhaustion with all feasibility and feasible costs known. The separate `ProgramJointDomain` CP/SCIP makespan models cover their explicitly supported local-mode domain; they do not automatically provide that proof for `ProgramAllSearch`.

## Correctness repair and regression

The public target tables previously applied NPU resource/memory/count/shape/route compatibility even when a task selected CPU. CPU child construction deliberately ignores these NPU-only bindings. Thus an inactive incompatible NPU binding could reject the all-zero CPU baseline before materialization (`INVALID_INPUT`), despite a valid CPU execution.

The repaired tables include the actual device-property writer and admit every relation for CPU choices. NPU choices retain the original checks. Looking up the property writer also handles custom dimension IDs. The end-to-end `program-all-inactive-bindings.cpp` contract uses real checked source/CPU child graphs, an intentionally excessive NPU resource count, a mismatched shape and an unbound NPU route. Both standard and custom device IDs must preserve the CPU candidate and exclude the active incompatible NPU choice. The test uses an explicitly assumed seven-unit complete-cost oracle; it makes no hardware calibration claim. The custom writer also changes a different task to NPU: a choice that does not write the current task must leave that task's CPU default inactive. The unified ON build passes eight checks, and the existing combined search contract passes 36 checks.

## Selected-native policy inheritance repair (r12)

A null `copies.retention` binding now inherits the data policy of the selected
canonical native mapping. Previously a selected whole-program/retained mapping
could retain the old phase-local public default, trigger an unnecessary
whole-task rebind, and fail the unchanged native execution-group witness check.
Explicit public policies still override inheritance and must pass the same
checks; incompatible refinements remain unknown. Native-public frozen replay
uses the same initialization rule before explicit policy decoding.

The ON/OFF combined contract passes 46/37 checks, including independent native
graph identity comparison for null and explicit retained choices and rejection
of the incompatible explicit phase-local choice. Public frozen replay passes
ten cases, including the complete whole-program graph and timing identity. A
real MLP2 selected whole-program graph independently re-exports with the same
parent and child IDs as the earlier direct export; this repairs materialization,
not the cost coverage or hardware-optimality boundary.

This does **not** add reduction-aware tile-major grouping. First-layer
matmul/initializer/rounding retention and two such scopes in the MLP still hit
`instance ordering has unproven cross-tile dependence`. The grouping code also
has pointwise-only read/write, initializer/retention, writer-count and matching
instance-domain requirements. Those proofs must be extended together before
such a binding can be called executable. The probes correctly return UNKNOWN,
not source-wide mathematical infeasibility; their predicted three/two physical
configuration counts are not established. Whole-program residency and legal
existing ungrouped tiled paths remain separate supported realizations.

## Existing dimensions and their current execution boundary

| Choice family | Generated/materialized today | Boundary that prevents an unrestricted optimum claim |
|---|---|---|
| Source fission / initialization | Existing legality-aware source actions, one Boolean each | These are registered transforms, not all possible legal source partitions or transformations. Source-changing choices also need matching cost calibration. |
| M/N/K tiling | Native phase adapter; current/full, approximately half, and one by default, or explicit positive tile domains | The automatic list is representative rather than all integer tilings. Source-instance limits can return unknown. Whole-task adapter cannot consume native tiles. |
| Fusion / residency / traversal | `discoverGenericMappingChoices` and `ProgramMappingChoice` | The catalogue proposes local source-derived scopes and extensions of existing groups, not every disjoint grouping. Tile-major scoped retention is pointwise-only; matrix/reduction + initializer/bridge groups need additional proofs and remain unknown. Explicit domains define the proof scope. |
| Implementation | Module policy plus strict per-original-task native kind/lanes choices; lineage expansion and regional index projection | Typed local overrides are independently checked and realized in graph/AIR. CPU selectors are inactive; generated fills remain scalar. Matrix requires the explicit BF16 source numerical contract and supported tiles. Mixed local assignments need implementation-resolved work calibration; missing coverage remains unknown. |
| Partition / replicas | Checked source-axis templates | Complete host slicing, assembly and invocation control are unpriced in the noncombined branch; the combined CPU/NPU builder explicitly returns unknown for partition refinement. Partition alone implies no concurrent execution. |
| Retention / regions / slots | Public copy policies, exact region graph and slot aliases | Native regions/dependencies are derived; a graph-only rebind need not have a physical native witness. Direct AIR uses packed nonoverlapping static slices, not arbitrary lifetime packing. |
| Resource / memory / count / shape | Public placement bindings and compatibility tables | Legal abstract capacity/geometry is not itself proof of a physical implementation. A backend must reject unsupported geometry rather than silently emit one core. |
| Routes | Public source-copy paths, including multiple hops | Direct public AIR currently accepts one selected host/core path. Other paths require an emitter and matching runtime cost, and remain unknown otherwise. |
| Temporal priority | Public schedule priority permutations | The current serial CPU/NPU executor preserves region order; CPU children require source order and native children require their checked native order. Unsupported reorderings return unknown. |
| Device / region cuts | Source-lineage CPU/NPU assignment, implied boundaries and same-device cuts | One serial executor composes real child plans. This is not concurrent CPU/NPU overlap or arbitrary asynchronous invocation. Cross-boundary native residency groups return unknown. |
| Layout / dtype | Fixed source contract | The generic row-major/source-dtype path is fixed, not searched. Registered matrix layout staging is an implementation refinement with explicit scratch/ABI evidence. |

The combined evaluator now exports the selected children, checks physical ABI graph identity, extracts C++ features and prices disjoint reset/region/control/copy phases under an exact execution-contract identity. Missing calibration, unsupported export, out-of-range features or foreign receipts remain unknown. A successful graph-only evaluation does not establish hardware correctness; the public report correctly keeps `physical_realization_checked=false`.

## Priorities for a credible all-dimension benchmark

1. **Preserve physical meaning before adding domain size.** The reviewed checkpoint has added explicit placement and instance count/shape guards to `lowerProgramGraphToAIR`: the direct backend accepts one unit with no shape or `{1}` and rejects unsupported geometry. This closes the earlier risk of emitting one physical core for a multi-unit request; it does not implement general geometry. Likewise exact DDR feedback/dependency realization must pass independent runtime checks before its price is trusted.
2. **Use an explicit, frozen finite domain with no unknown tuple.** A small complete benchmark can vary real source/tiling/implementation/retention/device/cut choices together only where every admitted combination has a checked selected child and a calibrated complete-call cost. Unsupported priorities, host partitioning and multihop/cross-core refinements must remain explicit gaps rather than silently become fixed defaults. If any retained tuple is unknown, exhaustion proves coverage, not an optimum.
3. **Separate candidate generation completeness from abstract completeness.** Automatic tiles are a short list, grouping is a bounded source-derived catalogue, priorities/routes have caps, and layouts and the registered implementation catalogue are not general. `domain_generation_complete` only describes the emitted finite generation, not all legal values of the public abstraction. Preserve the declared domain and evaluator hashes in comparisons.
4. **Build physical adapters for the remaining meaningful choices.** Host partition assembly with complete costs, source-backed schedule reordering, explicit inter-core synchronization/multihop paths and calibrated complete-call costs for mixed per-task implementations are actual additional work. More coverage proposals cannot fill those implementation gaps.
5. **Use solver proofs honestly.** A 600-second branch-and-check run with an incumbent and unknown/unvisited tuples is a budgeted result. To obtain a global cost lower bound before exhaustive callbacks, the complete evaluator needs a proven decomposition or an equivalent direct scheduling model; a coverage penalty is not that lower bound. Compare CP and ORBIT beam on identical finite choices, identical evaluator identity and complete runtime boundary.

This audit reads `ProgramAllSearch.cpp`, `ProgramSearch.cpp`, `GenericMapping.cpp`, `ProgramAllHeterogeneousCost.cpp`, `ProgramGraphAIR.cpp` and `ProgramMatrixAIR.cpp`. It does not change the NPU architecture abstraction, frozen models or prior hardware evidence.

CPU-inactive dimensions can produce many assignments for one executable plan. The current semantic cache still includes their NPU placement/route bindings. A future active-binding projection or explicitly canonical inactive domain can reduce repeated work, but must preserve exact source/selected-graph/runtime identity and report the equivalence reduction. Removing tuples silently would change a finite-domain proof.
